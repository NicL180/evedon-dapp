import ScriptSigClient from './ScriptSigClient';

export default function SigScriptPage() {
  return (
    <main>
      <ScriptSigClient />
    </main>
  );
}
