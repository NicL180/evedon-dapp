import SendClient from './SendClient';

export default function SendPage() {
  return (
    <main>
      <SendClient />
    </main>
  );
}
