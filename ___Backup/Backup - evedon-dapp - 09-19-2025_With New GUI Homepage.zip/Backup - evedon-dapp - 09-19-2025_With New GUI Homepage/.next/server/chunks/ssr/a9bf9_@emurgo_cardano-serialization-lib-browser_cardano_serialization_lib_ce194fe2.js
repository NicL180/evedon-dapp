module.exports = [
"[project]/node_modules/@emurgo/cardano-serialization-lib-browser/cardano_serialization_lib.js [app-ssr] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/a9bf9_@emurgo_cardano-serialization-lib-browser_cardano_serialization_lib_bg_f862c9d6.js",
  "server/chunks/ssr/e57c3_cardano-serialization-lib-browser_cardano_serialization_lib_bg_wasm_1b242943._.js",
  "server/chunks/ssr/node_modules_@emurgo_cardano-serialization-lib-browser_60e7b96c._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@emurgo/cardano-serialization-lib-browser/cardano_serialization_lib.js [app-ssr] (ecmascript)");
    });
});
}),
];