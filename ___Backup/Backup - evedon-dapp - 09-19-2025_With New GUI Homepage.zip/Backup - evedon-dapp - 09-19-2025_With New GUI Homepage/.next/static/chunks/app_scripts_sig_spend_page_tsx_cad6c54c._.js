(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a9bf9_@emurgo_cardano-serialization-lib-browser_cardano_serialization_lib_a43172b1.js",
  "static/chunks/app_scripts_sig_spend_SpendSigClient_tsx_ad045280._.js"
],
    source: "dynamic"
});
