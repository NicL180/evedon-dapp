(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/0a71f_next_dist_compiled_next-devtools_index_16eb6b68.js",
  "static/chunks/0a71f_next_dist_compiled_924b2626._.js",
  "static/chunks/0a71f_next_dist_shared_lib_c103f61e._.js",
  "static/chunks/0a71f_next_dist_client_1a0d012b._.js",
  "static/chunks/0a71f_next_dist_6194908a._.js",
  "static/chunks/0a71f_next_error_b2ae5835.js",
  "static/chunks/[next]_entry_page-loader_ts_881c6cf7._.js",
  "static/chunks/0a71f_react-dom_dc09598f._.js",
  "static/chunks/0a71f_7bdde203._.js",
  "static/chunks/[root-of-the-server]__22935c13._.js"
],
    source: "entry"
});
