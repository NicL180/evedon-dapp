(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a9bf9_@emurgo_cardano-serialization-lib-browser_cardano_serialization_lib_153fc6f4.js",
  "static/chunks/app_send_SendClient_tsx_3242780e._.js"
],
    source: "dynamic"
});
