(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/analytics.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Analytics
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
'use client';
;
;
function Analytics() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Analytics.useEffect": ()=>{
            const GA_ID = ("TURBOPACK compile-time value", "G-12QDBHNG0T") || 'G-12QDBHNG0T';
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            const q = searchParams === null || searchParams === void 0 ? void 0 : searchParams.toString();
            const url = q ? "".concat(pathname, "?").concat(q) : pathname;
            if (typeof window.gtag === 'function') {
                window.gtag('config', GA_ID, {
                    page_path: url
                });
            }
        }
    }["Analytics.useEffect"], [
        pathname,
        searchParams
    ]);
    return null;
}
_s(Analytics, "h6p6PpCFmP4Mu5bIMduBzSZThBE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = Analytics;
var _c;
__turbopack_context__.k.register(_c, "Analytics");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/providers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/react/dist/index.js [app-client] (ecmascript)");
'use client';
;
;
function Providers(param) {
    let { children } = param;
    // MeshProvider gives us the wallet context for useWallet/useAddress/etc.
    // No extra config required; network comes from the user’s wallet (Lace).
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeshProvider"], {
        children: children
    }, void 0, false, {
        fileName: "[project]/app/providers.tsx",
        lineNumber: 8,
        columnNumber: 10
    }, this);
}
_c = Providers;
var _c;
__turbopack_context__.k.register(_c, "Providers");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/WalletMenu.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WalletMenu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/react/dist/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const CANDIDATES = [
    {
        id: 'lace',
        label: 'Lace'
    },
    {
        id: 'nami',
        label: 'Nami'
    },
    {
        id: 'eternl',
        label: 'Eternl'
    },
    {
        id: 'flint',
        label: 'Flint'
    },
    {
        id: 'gerowallet',
        label: 'GeroWallet'
    }
];
const hex2bytes = (hex)=>Uint8Array.from((hex.replace(/^0x/, '').match(/.{1,2}/g) || []).map((b)=>parseInt(b, 16)));
function formatAda(v) {
    if (v == null) return null;
    const n = typeof v === 'string' ? Number(v) : v;
    if (!Number.isFinite(n)) return null;
    return (n / 1_000_000).toFixed(6);
}
function networkName(id) {
    if (id === 1) return 'Mainnet';
    if (id === 0) return 'Testnet';
    return String(id !== null && id !== void 0 ? id : '—');
}
function WalletMenu() {
    _s();
    const { connected, name, connect, disconnect } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWallet"])();
    const hookAddress = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAddress"])(); // may be null with wallet privacy
    const netId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNetwork"])();
    const lovelace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLovelace"])();
    const ada = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "WalletMenu.useMemo[ada]": ()=>formatAda(lovelace)
    }["WalletMenu.useMemo[ada]"], [
        lovelace
    ]);
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [installed, setInstalled] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [showAddress, setShowAddress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [fallbackAddr, setFallbackAddr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const menuRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Scan for injected wallets (immediately + delayed polls for late injection)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WalletMenu.useEffect": ()=>{
            const scan = {
                "WalletMenu.useEffect.scan": ()=>{
                    const w = globalThis.cardano || {};
                    setInstalled(CANDIDATES.filter({
                        "WalletMenu.useEffect.scan": (c)=>!!w[c.id]
                    }["WalletMenu.useEffect.scan"]));
                }
            }["WalletMenu.useEffect.scan"];
            scan();
            const t1 = setTimeout(scan, 300);
            const t2 = setTimeout(scan, 1000);
            const t3 = setTimeout(scan, 2000);
            return ({
                "WalletMenu.useEffect": ()=>{
                    clearTimeout(t1);
                    clearTimeout(t2);
                    clearTimeout(t3);
                }
            })["WalletMenu.useEffect"];
        }
    }["WalletMenu.useEffect"], []);
    // Auto-reconnect if a wallet is already authorized (reduces "no wallets detected" confusion)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WalletMenu.useEffect": ()=>{
            const w = globalThis.cardano || {};
            ({
                "WalletMenu.useEffect": async ()=>{
                    try {
                        for (const id of CANDIDATES.map({
                            "WalletMenu.useEffect": (c)=>c.id
                        }["WalletMenu.useEffect"])){
                            var _w_id_isEnabled, _w_id;
                            if (await ((_w_id = w[id]) === null || _w_id === void 0 ? void 0 : (_w_id_isEnabled = _w_id.isEnabled) === null || _w_id_isEnabled === void 0 ? void 0 : _w_id_isEnabled.call(_w_id))) {
                                await connect(id);
                                break;
                            }
                        }
                    } catch (e) {}
                }
            })["WalletMenu.useEffect"]();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["WalletMenu.useEffect"], []);
    // Close dropdown on outside click / ESC
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WalletMenu.useEffect": ()=>{
            const onClick = {
                "WalletMenu.useEffect.onClick": (e)=>{
                    var _menuRef_current;
                    if (!((_menuRef_current = menuRef.current) === null || _menuRef_current === void 0 ? void 0 : _menuRef_current.contains(e.target))) setOpen(false);
                }
            }["WalletMenu.useEffect.onClick"];
            const onKey = {
                "WalletMenu.useEffect.onKey": (e)=>{
                    if (e.key === 'Escape') setOpen(false);
                }
            }["WalletMenu.useEffect.onKey"];
            document.addEventListener('click', onClick);
            document.addEventListener('keydown', onKey);
            return ({
                "WalletMenu.useEffect": ()=>{
                    document.removeEventListener('click', onClick);
                    document.removeEventListener('keydown', onKey);
                }
            })["WalletMenu.useEffect"];
        }
    }["WalletMenu.useEffect"], []);
    // Robust address fallback using CSL (if wallet privacy hides it from Mesh hook)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WalletMenu.useEffect": ()=>{
            let cancelled = false;
            async function deriveAddress() {
                setFallbackAddr(null);
                if (!connected || hookAddress) return;
                const w = globalThis.cardano || {};
                // find an enabled provider
                let providerId = null;
                for (const id of CANDIDATES.map({
                    "WalletMenu.useEffect.deriveAddress": (c)=>c.id
                }["WalletMenu.useEffect.deriveAddress"])){
                    try {
                        var _w_id_isEnabled, _w_id;
                        if (await ((_w_id = w[id]) === null || _w_id === void 0 ? void 0 : (_w_id_isEnabled = _w_id.isEnabled) === null || _w_id_isEnabled === void 0 ? void 0 : _w_id_isEnabled.call(_w_id))) {
                            providerId = id;
                            break;
                        }
                    } catch (e) {}
                }
                if (!providerId || !w[providerId]) return;
                try {
                    const api = await w[providerId].enable();
                    let hex = null;
                    try {
                        hex = await api.getChangeAddress();
                    } catch (e) {}
                    if (!hex) {
                        const used = await api.getUsedAddresses().catch({
                            "WalletMenu.useEffect.deriveAddress": ()=>[]
                        }["WalletMenu.useEffect.deriveAddress"]);
                        if (used === null || used === void 0 ? void 0 : used.length) hex = used[0];
                    }
                    if (!hex) return;
                    const CSL = await __turbopack_context__.A("[project]/node_modules/@emurgo/cardano-serialization-lib-browser/cardano_serialization_lib.js [app-client] (ecmascript, async loader)");
                    const bytes = hex2bytes(hex);
                    const prefix = await api.getNetworkId().catch({
                        "WalletMenu.useEffect.deriveAddress": ()=>netId
                    }["WalletMenu.useEffect.deriveAddress"]) === 1 ? 'addr' : 'addr_test';
                    const bech = CSL.Address.from_bytes(bytes).to_bech32(prefix);
                    if (!cancelled) setFallbackAddr(bech);
                } catch (e) {}
            }
            deriveAddress();
            return ({
                "WalletMenu.useEffect": ()=>{
                    cancelled = true;
                }
            })["WalletMenu.useEffect"];
        }
    }["WalletMenu.useEffect"], [
        connected,
        hookAddress,
        netId
    ]);
    var _ref;
    const displayAddress = (_ref = hookAddress !== null && hookAddress !== void 0 ? hookAddress : fallbackAddr) !== null && _ref !== void 0 ? _ref : null;
    const buttonLabel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "WalletMenu.useMemo[buttonLabel]": ()=>{
            if (!connected) return 'Connect Wallet';
            return name ? "Connected: ".concat(name) : 'Connected';
        }
    }["WalletMenu.useMemo[buttonLabel]"], [
        connected,
        name
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "wallet-menu",
        ref: menuRef,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                className: "wallet-menu__button",
                onClick: ()=>setOpen((v)=>!v),
                "aria-haspopup": "menu",
                "aria-expanded": open,
                children: [
                    buttonLabel,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "wallet-menu__chevron",
                        "aria-hidden": true,
                        children: "▾"
                    }, void 0, false, {
                        fileName: "[project]/app/components/WalletMenu.tsx",
                        lineNumber: 135,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/WalletMenu.tsx",
                lineNumber: 127,
                columnNumber: 7
            }, this),
            connected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "wallet-menu__address",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "wallet-menu__eye",
                        onClick: ()=>setShowAddress((v)=>!v),
                        title: showAddress ? 'Hide address' : 'Show address',
                        "aria-label": showAddress ? 'Hide wallet address' : 'Show wallet address',
                        children: showAddress ? '👁️' : '🙈'
                    }, void 0, false, {
                        fileName: "[project]/app/components/WalletMenu.tsx",
                        lineNumber: 141,
                        columnNumber: 11
                    }, this),
                    showAddress && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "wallet-menu__addr-text",
                                children: displayAddress !== null && displayAddress !== void 0 ? displayAddress : '—'
                            }, void 0, false, {
                                fileName: "[project]/app/components/WalletMenu.tsx",
                                lineNumber: 151,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "wallet-menu__copy",
                                onClick: ()=>displayAddress && navigator.clipboard.writeText(displayAddress),
                                title: "Copy address",
                                "aria-label": "Copy address",
                                children: "📋"
                            }, void 0, false, {
                                fileName: "[project]/app/components/WalletMenu.tsx",
                                lineNumber: 152,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/WalletMenu.tsx",
                lineNumber: 140,
                columnNumber: 9
            }, this),
            connected && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "wallet-menu__stats",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "wallet-menu__stat",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Network:"
                            }, void 0, false, {
                                fileName: "[project]/app/components/WalletMenu.tsx",
                                lineNumber: 168,
                                columnNumber: 46
                            }, this),
                            " ",
                            networkName(netId)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/WalletMenu.tsx",
                        lineNumber: 168,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "wallet-menu__stat",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Balance:"
                            }, void 0, false, {
                                fileName: "[project]/app/components/WalletMenu.tsx",
                                lineNumber: 169,
                                columnNumber: 46
                            }, this),
                            " ",
                            ada != null ? "".concat(ada, " ADA") : '—'
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/WalletMenu.tsx",
                        lineNumber: 169,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/WalletMenu.tsx",
                lineNumber: 167,
                columnNumber: 9
            }, this),
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "wallet-menu__dropdown",
                role: "menu",
                children: !connected ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: installed.length ? installed.map((w)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            role: "menuitem",
                            className: "wallet-menu__item",
                            onClick: async ()=>{
                                try {
                                    await connect(w.id);
                                    setOpen(false);
                                } catch (e) {
                                    console.error('Connect error', e);
                                }
                            },
                            children: w.label
                        }, w.id, false, {
                            fileName: "[project]/app/components/WalletMenu.tsx",
                            lineNumber: 180,
                            columnNumber: 19
                        }, this)) : // Hide this entire "no wallets" section once connected; only show when not connected
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "wallet-menu__empty",
                        children: [
                            "No wallets detected. Install Lace and refresh.",
                            ' ',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "https://lace.io",
                                target: "_blank",
                                rel: "noreferrer",
                                children: "Get Lace"
                            }, void 0, false, {
                                fileName: "[project]/app/components/WalletMenu.tsx",
                                lineNumber: 195,
                                columnNumber: 24
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/WalletMenu.tsx",
                        lineNumber: 193,
                        columnNumber: 17
                    }, this)
                }, void 0, false) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "wallet-menu__status",
                            children: [
                                "Connected: ",
                                name !== null && name !== void 0 ? name : 'Wallet'
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/WalletMenu.tsx",
                            lineNumber: 201,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            role: "menuitem",
                            className: "wallet-menu__item",
                            onClick: async ()=>{
                                try {
                                    await disconnect();
                                    setOpen(false);
                                    setShowAddress(false);
                                } catch (e) {
                                    console.error('Disconnect error', e);
                                }
                            },
                            children: "Disconnect"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WalletMenu.tsx",
                            lineNumber: 202,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "wallet-menu__sep"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WalletMenu.tsx",
                            lineNumber: 211,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "wallet-menu__subhead",
                            children: "Switch wallet"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WalletMenu.tsx",
                            lineNumber: 212,
                            columnNumber: 15
                        }, this),
                        installed.length ? installed.map((w)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                role: "menuitem",
                                className: "wallet-menu__item",
                                onClick: async ()=>{
                                    try {
                                        await connect(w.id);
                                        setOpen(false);
                                        setShowAddress(false);
                                    } catch (e) {
                                        console.error('Switch error', e);
                                    }
                                },
                                children: w.label
                            }, w.id, false, {
                                fileName: "[project]/app/components/WalletMenu.tsx",
                                lineNumber: 214,
                                columnNumber: 17
                            }, this)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "wallet-menu__empty",
                            children: "No other wallets detected"
                        }, void 0, false, {
                            fileName: "[project]/app/components/WalletMenu.tsx",
                            lineNumber: 224,
                            columnNumber: 20
                        }, this)
                    ]
                }, void 0, true)
            }, void 0, false, {
                fileName: "[project]/app/components/WalletMenu.tsx",
                lineNumber: 175,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/WalletMenu.tsx",
        lineNumber: 126,
        columnNumber: 5
    }, this);
}
_s(WalletMenu, "v9cUm+UECuJpzWOtlO5NFZvmnr4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWallet"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAddress"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNetwork"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLovelace"]
    ];
});
_c = WalletMenu;
var _c;
__turbopack_context__.k.register(_c, "WalletMenu");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_b8ab78f3._.js.map