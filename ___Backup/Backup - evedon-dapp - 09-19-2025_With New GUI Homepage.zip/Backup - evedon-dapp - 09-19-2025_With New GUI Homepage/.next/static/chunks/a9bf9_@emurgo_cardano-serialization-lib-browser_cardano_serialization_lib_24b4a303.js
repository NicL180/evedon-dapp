(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a9bf9_@emurgo_cardano-serialization-lib-browser_cardano_serialization_lib_bg_90d3be35.js",
  "static/chunks/e57c3_cardano-serialization-lib-browser_cardano_serialization_lib_bg_wasm_9a0ad83e._.js",
  "static/chunks/node_modules_@emurgo_cardano-serialization-lib-browser_ff7d437f._.js"
],
    source: "dynamic"
});
