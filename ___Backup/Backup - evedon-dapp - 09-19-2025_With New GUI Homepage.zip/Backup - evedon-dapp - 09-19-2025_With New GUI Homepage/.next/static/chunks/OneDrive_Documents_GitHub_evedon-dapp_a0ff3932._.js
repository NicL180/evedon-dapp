(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_cce7148c._.js",
  "static/chunks/0a71f_next_dist_compiled_react-dom_8fdc6038._.js",
  "static/chunks/0a71f_next_dist_compiled_next-devtools_index_18aa2701.js",
  "static/chunks/0a71f_next_dist_compiled_1940aad8._.js",
  "static/chunks/0a71f_next_dist_client_bc2b37a5._.js",
  "static/chunks/0a71f_next_dist_f560efaa._.js",
  "static/chunks/0a71f_@swc_helpers_cjs_c460c650._.js"
],
    source: "entry"
});
