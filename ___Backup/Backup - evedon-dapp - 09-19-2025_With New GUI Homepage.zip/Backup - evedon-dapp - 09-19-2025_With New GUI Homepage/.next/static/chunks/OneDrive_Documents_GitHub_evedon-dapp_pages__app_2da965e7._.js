(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/0a71f_next_dist_compiled_next-devtools_index_16eb6b68.js",
  "static/chunks/0a71f_next_dist_compiled_924b2626._.js",
  "static/chunks/0a71f_next_dist_shared_lib_2c7cec20._.js",
  "static/chunks/0a71f_next_dist_client_1a0d012b._.js",
  "static/chunks/0a71f_next_dist_65e05323._.js",
  "static/chunks/0a71f_next_app_04fe55ab.js",
  "static/chunks/[next]_entry_page-loader_ts_f9190fb5._.js",
  "static/chunks/0a71f_react-dom_dc09598f._.js",
  "static/chunks/0a71f_7bdde203._.js",
  "static/chunks/[root-of-the-server]__74bc20fb._.js"
],
    source: "entry"
});
