import SpendSigClient from './SpendSigClient';

export default function SpendSigPage() {
  return (
    <main>
      <SpendSigClient />
    </main>
  );
}
