export default function HomePage() {
  return (
    <main style={{ padding: '2rem', textAlign: 'center' }}>
      {/* Intentionally minimal — header + wallet menu come from layout.tsx */}
    </main>
  );
}
