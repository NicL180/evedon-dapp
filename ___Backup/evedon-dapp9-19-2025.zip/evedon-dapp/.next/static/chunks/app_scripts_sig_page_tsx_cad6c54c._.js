(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a9bf9_@emurgo_cardano-serialization-lib-browser_cardano_serialization_lib_3d7c1954.js",
  "static/chunks/app_scripts_sig_ScriptSigClient_tsx_02dc2cae._.js"
],
    source: "dynamic"
});
