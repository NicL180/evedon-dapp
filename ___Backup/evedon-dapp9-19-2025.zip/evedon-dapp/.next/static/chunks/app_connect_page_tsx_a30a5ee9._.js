(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_connect_connect_65f98ce2.css",
  "static/chunks/app_connect_ConnectClient_tsx_31cd0532._.js"
],
    source: "dynamic"
});
