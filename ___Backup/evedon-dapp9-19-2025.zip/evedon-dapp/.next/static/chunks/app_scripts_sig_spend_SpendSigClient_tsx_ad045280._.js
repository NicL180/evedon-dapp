(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/scripts/sig/spend/SpendSigClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SpendSigClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/react/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/core/dist/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$provider$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/provider/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$transaction$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/core/node_modules/@meshsdk/transaction/dist/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const hrp = (id)=>id === 1 ? 'addr' : 'addr_test';
const hex2bytes = (hex)=>Uint8Array.from((hex.replace(/^0x/, '').match(/.{1,2}/g) || []).map((b)=>parseInt(b, 16)));
const toHex = (u8)=>Array.from(u8).map((b)=>b.toString(16).padStart(2, '0')).join('');
const lovelaceOf = (u)=>{
    var _u_output_amount_find;
    var _u_output_amount_find_quantity;
    return Number((_u_output_amount_find_quantity = (_u_output_amount_find = u.output.amount.find((a)=>a.unit === 'lovelace')) === null || _u_output_amount_find === void 0 ? void 0 : _u_output_amount_find.quantity) !== null && _u_output_amount_find_quantity !== void 0 ? _u_output_amount_find_quantity : '0');
};
function SpendSigClient() {
    _s();
    const { connected, name, wallet } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWallet"])();
    const netId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNetwork"])();
    const [baseBech, setBaseBech] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [scriptAddr, setScriptAddr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [scriptCbor, setScriptCbor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [pubKeyHash, setPubKeyHash] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('');
    const [utxos, setUtxos] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selected, setSelected] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [withdrawAda, setWithdrawAda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('1.0');
    const [max50Ada, setMax50Ada] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [msg, setMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [txHash, setTxHash] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const explorerBase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SpendSigClient.useMemo[explorerBase]": ()=>netId === 1 ? 'https://cardanoscan.io' : 'https://preprod.cardanoscan.io'
    }["SpendSigClient.useMemo[explorerBase]"], [
        netId
    ]);
    const provider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SpendSigClient.useMemo[provider]": ()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$provider$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BlockfrostProvider"](("TURBOPACK compile-time value", "preprodQZsckZ9BaefNzLGS5k4NO8d2keCSNkea") || '')
    }["SpendSigClient.useMemo[provider]"], []);
    // 1) Recreate native script & addresses from wallet (single-sig)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SpendSigClient.useEffect": ()=>{
            let cancelled = false;
            ({
                "SpendSigClient.useEffect": async ()=>{
                    try {
                        if (!connected || !wallet) return;
                        const CSL = await __turbopack_context__.A("[project]/node_modules/@emurgo/cardano-serialization-lib-browser/cardano_serialization_lib.js [app-client] (ecmascript, async loader)");
                        // source a wallet address, normalize to bech32
                        let raw = null;
                        try {
                            raw = await wallet.getChangeAddress();
                        } catch (e) {}
                        if (!raw) {
                            const used = await wallet.getUsedAddresses().catch({
                                "SpendSigClient.useEffect": ()=>[]
                            }["SpendSigClient.useEffect"]);
                            if (used === null || used === void 0 ? void 0 : used.length) raw = used[0];
                        }
                        if (!raw) return;
                        const addr = typeof raw === 'string' && raw.startsWith('addr') ? CSL.Address.from_bech32(raw) : CSL.Address.from_bytes(hex2bytes(raw));
                        const bech = addr.to_bech32(hrp(netId));
                        if (cancelled) return;
                        setBaseBech(bech);
                        // payment credential → key hash
                        let cred = null;
                        const base = CSL.BaseAddress.from_address(addr);
                        if (base) cred = base.payment_cred();
                        if (!cred) {
                            const ent = CSL.EnterpriseAddress.from_address(addr);
                            if (ent) cred = ent.payment_cred();
                        }
                        if (!cred) {
                            const ptr = CSL.PointerAddress.from_address(addr);
                            if (ptr) cred = ptr.payment_cred();
                        }
                        const kh = cred.to_keyhash();
                        const pkhHex = toHex(kh.to_bytes());
                        setPubKeyHash(pkhHex);
                        // native script (signature)
                        const pub = CSL.ScriptPubkey.new(kh);
                        const ns = CSL.NativeScript.new_script_pubkey(pub);
                        setScriptCbor(toHex(ns.to_bytes()));
                        // script address (enterprise via Credential API)
                        const networkTag = netId === 1 ? 1 : 0;
                        const scrCred = CSL.Credential.from_scripthash(ns.hash());
                        const entAddr = CSL.EnterpriseAddress.new(networkTag, scrCred).to_address();
                        setScriptAddr(entAddr.to_bech32(hrp(netId)));
                    } catch (e) {
                        console.error('[spend] init', e);
                    }
                }
            })["SpendSigClient.useEffect"]();
            return ({
                "SpendSigClient.useEffect": ()=>{
                    cancelled = true;
                }
            })["SpendSigClient.useEffect"];
        }
    }["SpendSigClient.useEffect"], [
        connected,
        wallet,
        netId
    ]);
    // 2) Fetch UTxOs at script address
    async function refreshUtxos() {
        setMsg(null);
        setTxHash(null);
        try {
            if (!scriptAddr) return;
            const list = await provider.fetchAddressUTxOs(scriptAddr);
            setUtxos(list);
            setSelected(0);
            if (list.length) {
                const ada = lovelaceOf(list[0]) / 1_000_000;
                // 50% cap minus small buffer for fees/change rounding
                setMax50Ada(Math.max(0, ada * 0.5 - 0.4));
            } else {
                setMax50Ada(null);
                setMsg('No UTxOs at script address yet. Lock some tADA first.');
            }
        } catch (e) {
            console.error(e);
            var _e_message;
            setMsg((_e_message = e === null || e === void 0 ? void 0 : e.message) !== null && _e_message !== void 0 ? _e_message : 'Failed to fetch UTxOs. Check Blockfrost key and network.');
        }
    }
    // 3) Spend selected UTxO → baseBech (attach script to the *correct* input + partial sign)
    async function spend(e) {
        e.preventDefault();
        setMsg(null);
        setTxHash(null);
        if (!connected || !wallet) {
            setMsg('Connect your wallet first.');
            return;
        }
        if (!scriptAddr || !scriptCbor || !pubKeyHash) {
            setMsg('Script not ready.');
            return;
        }
        if (!utxos.length) {
            setMsg('No UTxOs to spend.');
            return;
        }
        const ada = Number(withdrawAda);
        if (!Number.isFinite(ada) || ada <= 0) {
            setMsg('Enter a positive ADA amount.');
            return;
        }
        const u = utxos[selected];
        const utxoAda = lovelaceOf(u) / 1_000_000;
        const cap = Math.max(0, utxoAda * 0.5 - 0.4); // 50% - buffer
        if (ada > cap) {
            setMsg("50% limit active. Max you can withdraw from this UTxO is ~".concat(cap.toFixed(6), " ADA."));
            return;
        }
        setBusy(true);
        try {
            const changeHex = await wallet.getChangeAddress();
            const want = Math.round(ada * 1_000_000);
            const buffer = 1_500_000; // ~1.5 ADA buffer for fees/change
            // Start with the *script* UTxO as the first input and immediately attach the script.
            const txb = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$transaction$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MeshTxBuilder"]({
                fetcher: provider,
                verbose: true
            });
            txb.setNetwork('preprod');
            txb.txIn(u.input.txHash, u.input.outputIndex, u.output.amount, u.output.address) // script input
            .txInScript(scriptCbor) // attach to the last txIn (the script input)
            .requiredSignerHash(pubKeyHash); // our wallet must sign (required signer)
            // If we need extra funds for fees/min-change, add base address UTxOs explicitly.
            let pickedTotal = lovelaceOf(u);
            if (pickedTotal < want + buffer) {
                if (!baseBech) throw new Error('Base address not ready.');
                const baseUtxos = await provider.fetchAddressUTxOs(baseBech);
                baseUtxos.sort((a, b)=>lovelaceOf(b) - lovelaceOf(a)); // largest-first
                for (const bu of baseUtxos){
                    txb.txIn(bu.input.txHash, bu.input.outputIndex, bu.output.amount, bu.output.address);
                    pickedTotal += lovelaceOf(bu);
                    if (pickedTotal >= want + buffer) break;
                }
                if (pickedTotal < want + buffer) {
                    throw new Error('Not enough ADA in wallet inputs to cover output + fees/change. Lower the amount.');
                }
            }
            txb.txOut(baseBech, [
                {
                    unit: 'lovelace',
                    quantity: String(want)
                }
            ]).changeAddress(changeHex);
            // IMPORTANT: do NOT pass { wallet } here (avoids structuredClone DataCloneError)
            const unsigned = await txb.complete();
            // IMPORTANT: partial sign = true for txs with script witnesses (Lace is happier)
            const signed = await wallet.signTx(unsigned, true);
            const hash = await wallet.submitTx(signed);
            setTxHash(hash);
            setMsg('✅ Submitted spend tx.');
            setTimeout(()=>refreshUtxos(), 1500);
        } catch (err) {
            var _err_info_error, _err_info, _err_info1;
            console.error('[spend] error', err);
            const text = (err === null || err === void 0 ? void 0 : (_err_info = err.info) === null || _err_info === void 0 ? void 0 : (_err_info_error = _err_info.error) === null || _err_info_error === void 0 ? void 0 : _err_info_error.message) || (err === null || err === void 0 ? void 0 : (_err_info1 = err.info) === null || _err_info1 === void 0 ? void 0 : _err_info1.message) || (err === null || err === void 0 ? void 0 : err.message) || String(err);
            setMsg(text);
        } finally{
            setBusy(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            maxWidth: 900,
            margin: '2rem auto',
            padding: '1rem'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                children: "Spend from Native Script (Signature)"
            }, void 0, false, {
                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                lineNumber: 198,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                style: {
                    opacity: 0.85
                },
                children: [
                    "Network: ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                        children: netId === 1 ? 'Mainnet' : 'Preprod Testnet'
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 200,
                        columnNumber: 18
                    }, this),
                    " · Wallet: ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                        children: connected ? name !== null && name !== void 0 ? name : 'Wallet' : '—'
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 200,
                        columnNumber: 81
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                lineNumber: 199,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'grid',
                    gap: 10,
                    border: '1px solid #345',
                    borderRadius: 12,
                    padding: 12
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: "Base address:"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 204,
                                columnNumber: 14
                            }, this),
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                children: baseBech || '—'
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 204,
                                columnNumber: 35
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 204,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: "Script address:"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 205,
                                columnNumber: 14
                            }, this),
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                children: scriptAddr || '—'
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 205,
                                columnNumber: 37
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 205,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: "Native script (CBOR hex):"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 206,
                                columnNumber: 14
                            }, this),
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                style: {
                                    wordBreak: 'break-all'
                                },
                                children: scriptCbor || '—'
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 206,
                                columnNumber: 47
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 206,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            gap: 8,
                            flexWrap: 'wrap'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: refreshUtxos,
                                style: {
                                    padding: '6px 10px',
                                    borderRadius: 10,
                                    border: '1px solid #567',
                                    background: '#0a1020',
                                    color: '#d6e7ff'
                                },
                                children: "↻ Refresh UTxOs"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 208,
                                columnNumber: 11
                            }, this),
                            scriptAddr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "".concat(explorerBase, "/address/").concat(scriptAddr),
                                target: "_blank",
                                rel: "noreferrer",
                                style: {
                                    color: '#7fb3ff',
                                    textDecoration: 'underline'
                                },
                                children: "View script address on explorer"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 210,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 207,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                lineNumber: 203,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    marginTop: 14,
                    border: '1px solid #345',
                    borderRadius: 12,
                    padding: 12
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        style: {
                            marginTop: 0
                        },
                        children: "UTxOs at Script Address"
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 218,
                        columnNumber: 9
                    }, this),
                    !utxos.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            opacity: 0.8
                        },
                        children: "No UTxOs loaded. Click ↻ Refresh."
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 220,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                        style: {
                            listStyle: 'none',
                            padding: 0,
                            margin: 0,
                            display: 'grid',
                            gap: 8
                        },
                        children: utxos.map((u, i)=>{
                            const ada = lovelaceOf(u) / 1_000_000;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                style: {
                                    padding: 10,
                                    border: '1px solid #223',
                                    borderRadius: 10
                                },
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    style: {
                                        display: 'grid',
                                        gap: 6
                                    },
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                    children: [
                                                        "#",
                                                        i + 1
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                                    lineNumber: 228,
                                                    columnNumber: 27
                                                }, this),
                                                " · TxIn: ",
                                                u.input.txHash.slice(0, 8),
                                                "… / ",
                                                u.input.outputIndex
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                            lineNumber: 228,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "Amount: ",
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                                    children: [
                                                        ada.toFixed(6),
                                                        " ADA"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                                    lineNumber: 229,
                                                    columnNumber: 35
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                            lineNumber: 229,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "radio",
                                            name: "pick",
                                            checked: selected === i,
                                            onChange: ()=>{
                                                setSelected(i);
                                                setMax50Ada(Math.max(0, ada * 0.5 - 0.4)); // update 50% cap
                                            }
                                        }, void 0, false, {
                                            fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                            lineNumber: 230,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                    lineNumber: 227,
                                    columnNumber: 19
                                }, this)
                            }, "".concat(u.input.txHash, "-").concat(u.input.outputIndex), false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 226,
                                columnNumber: 17
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 222,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                lineNumber: 217,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: spend,
                style: {
                    marginTop: 14,
                    display: 'grid',
                    gap: 10
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        style: {
                            display: 'grid',
                            gap: 6
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Amount to withdraw (ADA)"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 249,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                value: withdrawAda,
                                onChange: (e)=>setWithdrawAda(e.target.value),
                                placeholder: "e.g., 0.8",
                                inputMode: "decimal",
                                style: {
                                    padding: '10px 12px',
                                    border: '1px solid #567',
                                    borderRadius: 10,
                                    background: '#0a1020',
                                    color: '#d6e7ff'
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 250,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 248,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            fontSize: 13,
                            opacity: 0.85
                        },
                        children: max50Ada === null ? '50% max: —' : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                "50% max for this UTxO (with buffer): ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                    children: [
                                        max50Ada.toFixed(6),
                                        " ADA"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                    lineNumber: 262,
                                    columnNumber: 54
                                }, this)
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 259,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            gap: 10,
                            flexWrap: 'wrap'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>max50Ada !== null && setWithdrawAda(max50Ada.toFixed(6)),
                                disabled: max50Ada === null,
                                style: {
                                    padding: '6px 10px',
                                    borderRadius: 10,
                                    border: '1px solid #567',
                                    background: '#0a1020',
                                    color: '#d6e7ff'
                                },
                                children: "Use 50% max"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 266,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                disabled: !utxos.length || busy,
                                style: {
                                    padding: '10px 14px',
                                    borderRadius: 12,
                                    border: '2px solid #2b6fff',
                                    background: busy ? '#132039' : '#0a1020',
                                    color: '#7fb3ff',
                                    fontWeight: 800,
                                    cursor: busy ? 'not-allowed' : 'pointer'
                                },
                                children: busy ? 'Submitting…' : 'Spend from Script'
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 275,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                        lineNumber: 265,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                lineNumber: 247,
                columnNumber: 7
            }, this),
            (msg || txHash) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    marginTop: 12,
                    padding: 10,
                    border: '1px solid #345',
                    borderRadius: 8,
                    background: 'rgba(43,111,255,0.06)'
                },
                children: [
                    msg,
                    ' ',
                    txHash && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            "·",
                            ' ',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "".concat(explorerBase, "/transaction/").concat(txHash),
                                target: "_blank",
                                rel: "noreferrer",
                                style: {
                                    color: '#7fb3ff'
                                },
                                children: "Open on Cardanoscan"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                                lineNumber: 307,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                ]
            }, void 0, true, {
                fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
                lineNumber: 294,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/scripts/sig/spend/SpendSigClient.tsx",
        lineNumber: 197,
        columnNumber: 5
    }, this);
}
_s(SpendSigClient, "L49ZbSOH5Kfop7qBA5pHnUO7IZU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWallet"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNetwork"]
    ];
});
_c = SpendSigClient;
var _c;
__turbopack_context__.k.register(_c, "SpendSigClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_scripts_sig_spend_SpendSigClient_tsx_ad045280._.js.map