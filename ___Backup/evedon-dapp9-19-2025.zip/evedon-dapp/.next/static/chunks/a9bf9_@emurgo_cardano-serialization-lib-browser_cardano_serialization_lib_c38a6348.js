(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/@emurgo/cardano-serialization-lib-browser/cardano_serialization_lib.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/a9bf9_@emurgo_cardano-serialization-lib-browser_cardano_serialization_lib_bg_90d3be35.js",
  "static/chunks/e57c3_cardano-serialization-lib-browser_cardano_serialization_lib_bg_wasm_9a0ad83e._.js",
  "static/chunks/node_modules_@emurgo_cardano-serialization-lib-browser_ff7d437f._.js",
  "static/chunks/a9bf9_@emurgo_cardano-serialization-lib-browser_cardano_serialization_lib_bce581aa.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/@emurgo/cardano-serialization-lib-browser/cardano_serialization_lib.js [app-client] (ecmascript)");
    });
});
}),
]);