module.exports = [
"[project]/node_modules/@meshsdk/core/node_modules/@meshsdk/core-cst/dist/index.js [app-ssr] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Address",
    ()=>Address,
    "AddressType",
    ()=>AddressType,
    "AssetFingerprint",
    ()=>AssetFingerprint,
    "AssetId",
    ()=>AssetId,
    "AssetName",
    ()=>AssetName,
    "AuxilliaryData",
    ()=>AuxilliaryData,
    "BaseAddress",
    ()=>BaseAddress,
    "Bip32PrivateKey",
    ()=>Bip32PrivateKey2,
    "Bip32PrivateKeyHex",
    ()=>Bip32PrivateKeyHex2,
    "Bip32PublicKey",
    ()=>Bip32PublicKey2,
    "Bip32PublicKeyHex",
    ()=>Bip32PublicKeyHex2,
    "BootstrapWitness",
    ()=>BootstrapWitness,
    "CardanoSDKSerializer",
    ()=>CardanoSDKSerializer,
    "CborSet",
    ()=>CborSet,
    "CborWriter",
    ()=>CborWriter,
    "CertIndex",
    ()=>CertIndex,
    "Certificate",
    ()=>Certificate,
    "CertificateType",
    ()=>CertificateType,
    "ConstrPlutusData",
    ()=>ConstrPlutusData,
    "CoseSign1",
    ()=>CoseSign1,
    "CostModel",
    ()=>CostModel,
    "Costmdls",
    ()=>Costmdls,
    "Credential",
    ()=>Credential,
    "CredentialType",
    ()=>CredentialType,
    "DRep",
    ()=>DRep,
    "DRepID",
    ()=>DRepID,
    "Datum",
    ()=>Datum,
    "DatumHash",
    ()=>DatumHash,
    "DatumKind",
    ()=>DatumKind,
    "Ed25519KeyHash",
    ()=>Ed25519KeyHash2,
    "Ed25519KeyHashHex",
    ()=>Ed25519KeyHashHex2,
    "Ed25519PrivateExtendedKeyHex",
    ()=>Ed25519PrivateExtendedKeyHex,
    "Ed25519PrivateKey",
    ()=>Ed25519PrivateKey2,
    "Ed25519PrivateNormalKeyHex",
    ()=>Ed25519PrivateNormalKeyHex,
    "Ed25519PublicKey",
    ()=>Ed25519PublicKey2,
    "Ed25519PublicKeyHex",
    ()=>Ed25519PublicKeyHex2,
    "Ed25519Signature",
    ()=>Ed25519Signature2,
    "Ed25519SignatureHex",
    ()=>Ed25519SignatureHex2,
    "EnterpriseAddress",
    ()=>EnterpriseAddress,
    "ExUnits",
    ()=>ExUnits,
    "Hash",
    ()=>Hash,
    "Hash28ByteBase16",
    ()=>Hash28ByteBase162,
    "Hash32ByteBase16",
    ()=>Hash32ByteBase162,
    "HexBlob",
    ()=>HexBlob,
    "MetadatumList",
    ()=>MetadatumList,
    "MetadatumMap",
    ()=>MetadatumMap,
    "NativeScript",
    ()=>NativeScript,
    "NetworkId",
    ()=>NetworkId,
    "PaymentAddress",
    ()=>PaymentAddress,
    "PlutusData",
    ()=>PlutusData,
    "PlutusDataKind",
    ()=>PlutusDataKind,
    "PlutusLanguageVersion",
    ()=>PlutusLanguageVersion,
    "PlutusList",
    ()=>PlutusList,
    "PlutusMap",
    ()=>PlutusMap,
    "PlutusV1Script",
    ()=>PlutusV1Script,
    "PlutusV2Script",
    ()=>PlutusV2Script,
    "PlutusV3Script",
    ()=>PlutusV3Script,
    "PointerAddress",
    ()=>PointerAddress,
    "PolicyId",
    ()=>PolicyId,
    "PoolId",
    ()=>PoolId,
    "Redeemer",
    ()=>Redeemer,
    "RedeemerPurpose",
    ()=>RedeemerPurpose,
    "RedeemerTag",
    ()=>RedeemerTag,
    "Redeemers",
    ()=>Redeemers,
    "RequireAllOf",
    ()=>RequireAllOf,
    "RequireAnyOf",
    ()=>RequireAnyOf,
    "RequireNOf",
    ()=>RequireNOf,
    "RequireSignature",
    ()=>RequireSignature,
    "RequireTimeAfter",
    ()=>RequireTimeAfter,
    "RequireTimeBefore",
    ()=>RequireTimeBefore,
    "RewardAccount",
    ()=>RewardAccount,
    "RewardAddress",
    ()=>RewardAddress,
    "Script",
    ()=>Script,
    "ScriptHash",
    ()=>ScriptHash,
    "ScriptPubkey",
    ()=>ScriptPubkey,
    "Slot",
    ()=>Slot,
    "StakeCredentialStatus",
    ()=>StakeCredentialStatus,
    "StakeDelegation",
    ()=>StakeDelegation,
    "StakeRegistration",
    ()=>StakeRegistration,
    "Transaction",
    ()=>Transaction,
    "TransactionBody",
    ()=>TransactionBody,
    "TransactionId",
    ()=>TransactionId,
    "TransactionInput",
    ()=>TransactionInput,
    "TransactionMetadatum",
    ()=>TransactionMetadatum,
    "TransactionOutput",
    ()=>TransactionOutput,
    "TransactionUnspentOutput",
    ()=>TransactionUnspentOutput,
    "TransactionWitnessSet",
    ()=>TransactionWitnessSet,
    "TxCBOR",
    ()=>TxCBOR,
    "TxIndex",
    ()=>TxIndex,
    "Value",
    ()=>Value,
    "VkeyWitness",
    ()=>VkeyWitness,
    "VrfVkBech32",
    ()=>VrfVkBech32,
    "addVKeyWitnessSetToTransaction",
    ()=>addVKeyWitnessSetToTransaction,
    "addrBech32ToPlutusDataHex",
    ()=>addrBech32ToPlutusDataHex,
    "addrBech32ToPlutusDataObj",
    ()=>addrBech32ToPlutusDataObj,
    "addressToBech32",
    ()=>addressToBech32,
    "applyEncoding",
    ()=>applyEncoding,
    "applyParamsToScript",
    ()=>applyParamsToScript,
    "assetTypes",
    ()=>assetTypes,
    "blake2b",
    ()=>blake2b2,
    "buildBaseAddress",
    ()=>buildBaseAddress,
    "buildBip32PrivateKey",
    ()=>buildBip32PrivateKey,
    "buildDRepID",
    ()=>buildDRepID,
    "buildEd25519PrivateKeyFromSecretKey",
    ()=>buildEd25519PrivateKeyFromSecretKey,
    "buildEnterpriseAddress",
    ()=>buildEnterpriseAddress,
    "buildKeys",
    ()=>buildKeys,
    "buildRewardAddress",
    ()=>buildRewardAddress,
    "buildScriptPubkey",
    ()=>buildScriptPubkey,
    "bytesToHex",
    ()=>bytesToHex,
    "calculateFees",
    ()=>calculateFees,
    "checkSignature",
    ()=>checkSignature,
    "clampScalar",
    ()=>clampScalar,
    "computeAuxiliaryDataHash",
    ()=>computeAuxiliaryDataHash,
    "deserializeAddress",
    ()=>deserializeAddress,
    "deserializeBech32Address",
    ()=>deserializeBech32Address,
    "deserializeDataHash",
    ()=>deserializeDataHash,
    "deserializeEd25519KeyHash",
    ()=>deserializeEd25519KeyHash,
    "deserializeNativeScript",
    ()=>deserializeNativeScript,
    "deserializePlutusData",
    ()=>deserializePlutusData,
    "deserializePlutusScript",
    ()=>deserializePlutusScript,
    "deserializeScriptHash",
    ()=>deserializeScriptHash,
    "deserializeScriptRef",
    ()=>deserializeScriptRef,
    "deserializeTx",
    ()=>deserializeTx,
    "deserializeTxHash",
    ()=>deserializeTxHash,
    "deserializeTxUnspentOutput",
    ()=>deserializeTxUnspentOutput,
    "deserializeValue",
    ()=>deserializeValue,
    "empty",
    ()=>empty,
    "fromBuilderToPlutusData",
    ()=>fromBuilderToPlutusData,
    "fromJsonToPlutusData",
    ()=>fromJsonToPlutusData,
    "fromNativeScript",
    ()=>fromNativeScript,
    "fromPlutusDataToJson",
    ()=>fromPlutusDataToJson,
    "fromScriptRef",
    ()=>fromScriptRef,
    "fromTxUnspentOutput",
    ()=>fromTxUnspentOutput,
    "fromValue",
    ()=>fromValue,
    "generateNonce",
    ()=>generateNonce,
    "getCoseKeyFromPublicKey",
    ()=>getCoseKeyFromPublicKey,
    "getDRepIds",
    ()=>getDRepIds,
    "getPublicKeyFromCoseKey",
    ()=>getPublicKeyFromCoseKey,
    "hexToBech32",
    ()=>hexToBech32,
    "hexToBytes",
    ()=>hexToBytes,
    "keyHashToRewardAddress",
    ()=>keyHashToRewardAddress,
    "mergeValue",
    ()=>mergeValue,
    "negateValue",
    ()=>negateValue,
    "negatives",
    ()=>negatives,
    "normalizePlutusScript",
    ()=>normalizePlutusScript,
    "parseDatumCbor",
    ()=>parseDatumCbor,
    "parseInlineDatum",
    ()=>parseInlineDatum,
    "resolveDataHash",
    ()=>resolveDataHash,
    "resolveEd25519KeyHash",
    ()=>resolveEd25519KeyHash,
    "resolveNativeScriptAddress",
    ()=>resolveNativeScriptAddress,
    "resolveNativeScriptHash",
    ()=>resolveNativeScriptHash,
    "resolvePaymentKeyHash",
    ()=>resolvePaymentKeyHash,
    "resolvePlutusScriptAddress",
    ()=>resolvePlutusScriptAddress,
    "resolvePlutusScriptHash",
    ()=>resolvePlutusScriptHash,
    "resolvePoolId",
    ()=>resolvePoolId,
    "resolvePrivateKey",
    ()=>resolvePrivateKey,
    "resolveRewardAddress",
    ()=>resolveRewardAddress,
    "resolveScriptHashDRepId",
    ()=>resolveScriptHashDRepId,
    "resolveScriptRef",
    ()=>resolveScriptRef,
    "resolveStakeKeyHash",
    ()=>resolveStakeKeyHash,
    "resolveTxHash",
    ()=>resolveTxHash,
    "scriptHashToBech32",
    ()=>scriptHashToBech32,
    "scriptHashToRewardAddress",
    ()=>scriptHashToRewardAddress,
    "serializeAddressObj",
    ()=>serializeAddressObj,
    "serializePlutusAddressToBech32",
    ()=>serializePlutusAddressToBech32,
    "serialzeAddress",
    ()=>serialzeAddress,
    "signData",
    ()=>signData,
    "subValue",
    ()=>subValue,
    "toAddress",
    ()=>toAddress,
    "toBaseAddress",
    ()=>toBaseAddress,
    "toCardanoAddress",
    ()=>toCardanoAddress,
    "toDRep",
    ()=>toDRep,
    "toEnterpriseAddress",
    ()=>toEnterpriseAddress,
    "toNativeScript",
    ()=>toNativeScript,
    "toPlutusData",
    ()=>toPlutusData,
    "toRewardAddress",
    ()=>toRewardAddress,
    "toScriptRef",
    ()=>toScriptRef,
    "toTxUnspentOutput",
    ()=>toTxUnspentOutput,
    "toValue",
    ()=>toValue,
    "utf8ToBytes",
    ()=>utf8ToBytes,
    "utf8ToHex",
    ()=>utf8ToHex,
    "v2ScriptToBech32",
    ()=>v2ScriptToBech32
]);
// src/index.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/core/dist/esm/Cardano/index.js [app-ssr] (ecmascript) <export * as Cardano>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/core/dist/esm/Serialization/index.js [app-ssr] (ecmascript) <export * as Serialization>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/hexTypes.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Ed25519e$2f$Ed25519KeyHash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/Ed25519e/Ed25519KeyHash.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Ed25519e$2f$Ed25519PublicKey$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/Ed25519e/Ed25519PublicKey.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Ed25519e$2f$Ed25519Signature$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/Ed25519e/Ed25519Signature.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Bip32$2f$Bip32PrivateKey$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/Bip32/Bip32PrivateKey.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Bip32$2f$Bip32PublicKey$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/Bip32/Bip32PublicKey.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Ed25519e$2f$Ed25519PrivateKey$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/Ed25519e/Ed25519PrivateKey.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blake2b$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__blake2b$3e$__ = __turbopack_context__.i("[project]/node_modules/blake2b/index.js [app-ssr] (ecmascript) <export default as blake2b>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/util/dist/esm/primitives.js [app-ssr] (ecmascript)");
// src/message-signing/check-signature.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/core/node_modules/@meshsdk/common/dist/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/buffer [external] (buffer, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@harmoniclabs/cbor/dist/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blakejs$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/blakejs/index.js [app-ssr] (ecmascript)");
// ../../node_modules/nanoid/index.js
var __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/crypto [external] (crypto, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/base32-encoding/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bech32/dist/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bip39$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bip39/src/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$util$2f$conwayEra$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/core/dist/esm/util/conwayEra.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$plutus$2d$data$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@harmoniclabs/plutus-data/dist/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$uplc$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@harmoniclabs/uplc/dist/index.js [app-ssr] (ecmascript)");
// src/index.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/util/dist/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/core/dist/esm/index.js [app-ssr] (ecmascript)");
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __require = /* @__PURE__ */ ((x)=>("TURBOPACK compile-time truthy", 1) ? /*TURBOPACK member replacement*/ __turbopack_context__.z : "TURBOPACK unreachable")(function(x) {
    if ("TURBOPACK compile-time truthy", 1) return /*TURBOPACK member replacement*/ __turbopack_context__.z.apply(this, arguments);
    //TURBOPACK unreachable
    ;
});
var __commonJS = (cb, mod)=>function __require2() {
        return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = {
            exports: {}
        }).exports, mod), mod.exports;
    };
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toESM = (mod, isNodeMode, target)=>(target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(// If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
        value: mod,
        enumerable: true
    }) : target, mod));
// ../../node_modules/bignumber.js/bignumber.js
var require_bignumber = __commonJS({
    "../../node_modules/bignumber.js/bignumber.js" (exports, module) {
        "use strict";
        (function(globalObject) {
            "use strict";
            var BigNumber, isNumeric = /^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i, mathceil = Math.ceil, mathfloor = Math.floor, bignumberError = "[BigNumber Error] ", tooManyDigits = bignumberError + "Number primitive has more than 15 significant digits: ", BASE = 1e14, LOG_BASE = 14, MAX_SAFE_INTEGER = 9007199254740991, POWS_TEN = [
                1,
                10,
                100,
                1e3,
                1e4,
                1e5,
                1e6,
                1e7,
                1e8,
                1e9,
                1e10,
                1e11,
                1e12,
                1e13
            ], SQRT_BASE = 1e7, MAX = 1e9;
            function clone(configObject) {
                var div, convertBase, parseNumeric, P = BigNumber2.prototype = {
                    constructor: BigNumber2,
                    toString: null,
                    valueOf: null
                }, ONE = new BigNumber2(1), DECIMAL_PLACES = 20, ROUNDING_MODE = 4, TO_EXP_NEG = -7, TO_EXP_POS = 21, MIN_EXP = -1e7, MAX_EXP = 1e7, CRYPTO = false, MODULO_MODE = 1, POW_PRECISION = 0, FORMAT = {
                    prefix: "",
                    groupSize: 3,
                    secondaryGroupSize: 0,
                    groupSeparator: ",",
                    decimalSeparator: ".",
                    fractionGroupSize: 0,
                    fractionGroupSeparator: "\xA0",
                    // non-breaking space
                    suffix: ""
                }, ALPHABET = "0123456789abcdefghijklmnopqrstuvwxyz", alphabetHasNormalDecimalDigits = true;
                function BigNumber2(v, b) {
                    var alphabet, c, caseChanged, e, i, isNum, len, str, x = this;
                    if (!(x instanceof BigNumber2)) return new BigNumber2(v, b);
                    if (b == null) {
                        if (v && v._isBigNumber === true) {
                            x.s = v.s;
                            if (!v.c || v.e > MAX_EXP) {
                                x.c = x.e = null;
                            } else if (v.e < MIN_EXP) {
                                x.c = [
                                    x.e = 0
                                ];
                            } else {
                                x.e = v.e;
                                x.c = v.c.slice();
                            }
                            return;
                        }
                        if ((isNum = typeof v == "number") && v * 0 == 0) {
                            x.s = 1 / v < 0 ? (v = -v, -1) : 1;
                            if (v === ~~v) {
                                for(e = 0, i = v; i >= 10; i /= 10, e++);
                                if (e > MAX_EXP) {
                                    x.c = x.e = null;
                                } else {
                                    x.e = e;
                                    x.c = [
                                        v
                                    ];
                                }
                                return;
                            }
                            str = String(v);
                        } else {
                            if (!isNumeric.test(str = String(v))) return parseNumeric(x, str, isNum);
                            x.s = str.charCodeAt(0) == 45 ? (str = str.slice(1), -1) : 1;
                        }
                        if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
                        if ((i = str.search(/e/i)) > 0) {
                            if (e < 0) e = i;
                            e += +str.slice(i + 1);
                            str = str.substring(0, i);
                        } else if (e < 0) {
                            e = str.length;
                        }
                    } else {
                        intCheck(b, 2, ALPHABET.length, "Base");
                        if (b == 10 && alphabetHasNormalDecimalDigits) {
                            x = new BigNumber2(v);
                            return round(x, DECIMAL_PLACES + x.e + 1, ROUNDING_MODE);
                        }
                        str = String(v);
                        if (isNum = typeof v == "number") {
                            if (v * 0 != 0) return parseNumeric(x, str, isNum, b);
                            x.s = 1 / v < 0 ? (str = str.slice(1), -1) : 1;
                            if (BigNumber2.DEBUG && str.replace(/^0\.0*|\./, "").length > 15) {
                                throw Error(tooManyDigits + v);
                            }
                        } else {
                            x.s = str.charCodeAt(0) === 45 ? (str = str.slice(1), -1) : 1;
                        }
                        alphabet = ALPHABET.slice(0, b);
                        e = i = 0;
                        for(len = str.length; i < len; i++){
                            if (alphabet.indexOf(c = str.charAt(i)) < 0) {
                                if (c == ".") {
                                    if (i > e) {
                                        e = len;
                                        continue;
                                    }
                                } else if (!caseChanged) {
                                    if (str == str.toUpperCase() && (str = str.toLowerCase()) || str == str.toLowerCase() && (str = str.toUpperCase())) {
                                        caseChanged = true;
                                        i = -1;
                                        e = 0;
                                        continue;
                                    }
                                }
                                return parseNumeric(x, String(v), isNum, b);
                            }
                        }
                        isNum = false;
                        str = convertBase(str, b, 10, x.s);
                        if ((e = str.indexOf(".")) > -1) str = str.replace(".", "");
                        else e = str.length;
                    }
                    for(i = 0; str.charCodeAt(i) === 48; i++);
                    for(len = str.length; str.charCodeAt(--len) === 48;);
                    if (str = str.slice(i, ++len)) {
                        len -= i;
                        if (isNum && BigNumber2.DEBUG && len > 15 && (v > MAX_SAFE_INTEGER || v !== mathfloor(v))) {
                            throw Error(tooManyDigits + x.s * v);
                        }
                        if ((e = e - i - 1) > MAX_EXP) {
                            x.c = x.e = null;
                        } else if (e < MIN_EXP) {
                            x.c = [
                                x.e = 0
                            ];
                        } else {
                            x.e = e;
                            x.c = [];
                            i = (e + 1) % LOG_BASE;
                            if (e < 0) i += LOG_BASE;
                            if (i < len) {
                                if (i) x.c.push(+str.slice(0, i));
                                for(len -= LOG_BASE; i < len;){
                                    x.c.push(+str.slice(i, i += LOG_BASE));
                                }
                                i = LOG_BASE - (str = str.slice(i)).length;
                            } else {
                                i -= len;
                            }
                            for(; i--; str += "0");
                            x.c.push(+str);
                        }
                    } else {
                        x.c = [
                            x.e = 0
                        ];
                    }
                }
                BigNumber2.clone = clone;
                BigNumber2.ROUND_UP = 0;
                BigNumber2.ROUND_DOWN = 1;
                BigNumber2.ROUND_CEIL = 2;
                BigNumber2.ROUND_FLOOR = 3;
                BigNumber2.ROUND_HALF_UP = 4;
                BigNumber2.ROUND_HALF_DOWN = 5;
                BigNumber2.ROUND_HALF_EVEN = 6;
                BigNumber2.ROUND_HALF_CEIL = 7;
                BigNumber2.ROUND_HALF_FLOOR = 8;
                BigNumber2.EUCLID = 9;
                BigNumber2.config = BigNumber2.set = function(obj) {
                    var p, v;
                    if (obj != null) {
                        if (typeof obj == "object") {
                            if (obj.hasOwnProperty(p = "DECIMAL_PLACES")) {
                                v = obj[p];
                                intCheck(v, 0, MAX, p);
                                DECIMAL_PLACES = v;
                            }
                            if (obj.hasOwnProperty(p = "ROUNDING_MODE")) {
                                v = obj[p];
                                intCheck(v, 0, 8, p);
                                ROUNDING_MODE = v;
                            }
                            if (obj.hasOwnProperty(p = "EXPONENTIAL_AT")) {
                                v = obj[p];
                                if (v && v.pop) {
                                    intCheck(v[0], -MAX, 0, p);
                                    intCheck(v[1], 0, MAX, p);
                                    TO_EXP_NEG = v[0];
                                    TO_EXP_POS = v[1];
                                } else {
                                    intCheck(v, -MAX, MAX, p);
                                    TO_EXP_NEG = -(TO_EXP_POS = v < 0 ? -v : v);
                                }
                            }
                            if (obj.hasOwnProperty(p = "RANGE")) {
                                v = obj[p];
                                if (v && v.pop) {
                                    intCheck(v[0], -MAX, -1, p);
                                    intCheck(v[1], 1, MAX, p);
                                    MIN_EXP = v[0];
                                    MAX_EXP = v[1];
                                } else {
                                    intCheck(v, -MAX, MAX, p);
                                    if (v) {
                                        MIN_EXP = -(MAX_EXP = v < 0 ? -v : v);
                                    } else {
                                        throw Error(bignumberError + p + " cannot be zero: " + v);
                                    }
                                }
                            }
                            if (obj.hasOwnProperty(p = "CRYPTO")) {
                                v = obj[p];
                                if (v === !!v) {
                                    if (v) {
                                        if (typeof crypto != "undefined" && crypto && (crypto.getRandomValues || crypto.randomBytes)) {
                                            CRYPTO = v;
                                        } else {
                                            CRYPTO = !v;
                                            throw Error(bignumberError + "crypto unavailable");
                                        }
                                    } else {
                                        CRYPTO = v;
                                    }
                                } else {
                                    throw Error(bignumberError + p + " not true or false: " + v);
                                }
                            }
                            if (obj.hasOwnProperty(p = "MODULO_MODE")) {
                                v = obj[p];
                                intCheck(v, 0, 9, p);
                                MODULO_MODE = v;
                            }
                            if (obj.hasOwnProperty(p = "POW_PRECISION")) {
                                v = obj[p];
                                intCheck(v, 0, MAX, p);
                                POW_PRECISION = v;
                            }
                            if (obj.hasOwnProperty(p = "FORMAT")) {
                                v = obj[p];
                                if (typeof v == "object") FORMAT = v;
                                else throw Error(bignumberError + p + " not an object: " + v);
                            }
                            if (obj.hasOwnProperty(p = "ALPHABET")) {
                                v = obj[p];
                                if (typeof v == "string" && !/^.?$|[+\-.\s]|(.).*\1/.test(v)) {
                                    alphabetHasNormalDecimalDigits = v.slice(0, 10) == "0123456789";
                                    ALPHABET = v;
                                } else {
                                    throw Error(bignumberError + p + " invalid: " + v);
                                }
                            }
                        } else {
                            throw Error(bignumberError + "Object expected: " + obj);
                        }
                    }
                    return {
                        DECIMAL_PLACES,
                        ROUNDING_MODE,
                        EXPONENTIAL_AT: [
                            TO_EXP_NEG,
                            TO_EXP_POS
                        ],
                        RANGE: [
                            MIN_EXP,
                            MAX_EXP
                        ],
                        CRYPTO,
                        MODULO_MODE,
                        POW_PRECISION,
                        FORMAT,
                        ALPHABET
                    };
                };
                BigNumber2.isBigNumber = function(v) {
                    if (!v || v._isBigNumber !== true) return false;
                    if (!BigNumber2.DEBUG) return true;
                    var i, n, c = v.c, e = v.e, s = v.s;
                    out: if (({}).toString.call(c) == "[object Array]") {
                        if ((s === 1 || s === -1) && e >= -MAX && e <= MAX && e === mathfloor(e)) {
                            if (c[0] === 0) {
                                if (e === 0 && c.length === 1) return true;
                                break out;
                            }
                            i = (e + 1) % LOG_BASE;
                            if (i < 1) i += LOG_BASE;
                            if (String(c[0]).length == i) {
                                for(i = 0; i < c.length; i++){
                                    n = c[i];
                                    if (n < 0 || n >= BASE || n !== mathfloor(n)) break out;
                                }
                                if (n !== 0) return true;
                            }
                        }
                    } else if (c === null && e === null && (s === null || s === 1 || s === -1)) {
                        return true;
                    }
                    throw Error(bignumberError + "Invalid BigNumber: " + v);
                };
                BigNumber2.maximum = BigNumber2.max = function() {
                    return maxOrMin(arguments, -1);
                };
                BigNumber2.minimum = BigNumber2.min = function() {
                    return maxOrMin(arguments, 1);
                };
                BigNumber2.random = function() {
                    var pow2_53 = 9007199254740992;
                    var random53bitInt = Math.random() * pow2_53 & 2097151 ? function() {
                        return mathfloor(Math.random() * pow2_53);
                    } : function() {
                        return (Math.random() * 1073741824 | 0) * 8388608 + (Math.random() * 8388608 | 0);
                    };
                    return function(dp) {
                        var a, b, e, k, v, i = 0, c = [], rand = new BigNumber2(ONE);
                        if (dp == null) dp = DECIMAL_PLACES;
                        else intCheck(dp, 0, MAX);
                        k = mathceil(dp / LOG_BASE);
                        if (CRYPTO) {
                            if (crypto.getRandomValues) {
                                a = crypto.getRandomValues(new Uint32Array(k *= 2));
                                for(; i < k;){
                                    v = a[i] * 131072 + (a[i + 1] >>> 11);
                                    if (v >= 9e15) {
                                        b = crypto.getRandomValues(new Uint32Array(2));
                                        a[i] = b[0];
                                        a[i + 1] = b[1];
                                    } else {
                                        c.push(v % 1e14);
                                        i += 2;
                                    }
                                }
                                i = k / 2;
                            } else if (crypto.randomBytes) {
                                a = crypto.randomBytes(k *= 7);
                                for(; i < k;){
                                    v = (a[i] & 31) * 281474976710656 + a[i + 1] * 1099511627776 + a[i + 2] * 4294967296 + a[i + 3] * 16777216 + (a[i + 4] << 16) + (a[i + 5] << 8) + a[i + 6];
                                    if (v >= 9e15) {
                                        crypto.randomBytes(7).copy(a, i);
                                    } else {
                                        c.push(v % 1e14);
                                        i += 7;
                                    }
                                }
                                i = k / 7;
                            } else {
                                CRYPTO = false;
                                throw Error(bignumberError + "crypto unavailable");
                            }
                        }
                        if (!CRYPTO) {
                            for(; i < k;){
                                v = random53bitInt();
                                if (v < 9e15) c[i++] = v % 1e14;
                            }
                        }
                        k = c[--i];
                        dp %= LOG_BASE;
                        if (k && dp) {
                            v = POWS_TEN[LOG_BASE - dp];
                            c[i] = mathfloor(k / v) * v;
                        }
                        for(; c[i] === 0; c.pop(), i--);
                        if (i < 0) {
                            c = [
                                e = 0
                            ];
                        } else {
                            for(e = -1; c[0] === 0; c.splice(0, 1), e -= LOG_BASE);
                            for(i = 1, v = c[0]; v >= 10; v /= 10, i++);
                            if (i < LOG_BASE) e -= LOG_BASE - i;
                        }
                        rand.e = e;
                        rand.c = c;
                        return rand;
                    };
                }();
                BigNumber2.sum = function() {
                    var i = 1, args = arguments, sum = new BigNumber2(args[0]);
                    for(; i < args.length;)sum = sum.plus(args[i++]);
                    return sum;
                };
                convertBase = /* @__PURE__ */ function() {
                    var decimal = "0123456789";
                    function toBaseOut(str, baseIn, baseOut, alphabet) {
                        var j, arr = [
                            0
                        ], arrL, i = 0, len = str.length;
                        for(; i < len;){
                            for(arrL = arr.length; arrL--; arr[arrL] *= baseIn);
                            arr[0] += alphabet.indexOf(str.charAt(i++));
                            for(j = 0; j < arr.length; j++){
                                if (arr[j] > baseOut - 1) {
                                    if (arr[j + 1] == null) arr[j + 1] = 0;
                                    arr[j + 1] += arr[j] / baseOut | 0;
                                    arr[j] %= baseOut;
                                }
                            }
                        }
                        return arr.reverse();
                    }
                    return function(str, baseIn, baseOut, sign, callerIsToString) {
                        var alphabet, d, e, k, r, x, xc, y, i = str.indexOf("."), dp = DECIMAL_PLACES, rm = ROUNDING_MODE;
                        if (i >= 0) {
                            k = POW_PRECISION;
                            POW_PRECISION = 0;
                            str = str.replace(".", "");
                            y = new BigNumber2(baseIn);
                            x = y.pow(str.length - i);
                            POW_PRECISION = k;
                            y.c = toBaseOut(toFixedPoint(coeffToString(x.c), x.e, "0"), 10, baseOut, decimal);
                            y.e = y.c.length;
                        }
                        xc = toBaseOut(str, baseIn, baseOut, callerIsToString ? (alphabet = ALPHABET, decimal) : (alphabet = decimal, ALPHABET));
                        e = k = xc.length;
                        for(; xc[--k] == 0; xc.pop());
                        if (!xc[0]) return alphabet.charAt(0);
                        if (i < 0) {
                            --e;
                        } else {
                            x.c = xc;
                            x.e = e;
                            x.s = sign;
                            x = div(x, y, dp, rm, baseOut);
                            xc = x.c;
                            r = x.r;
                            e = x.e;
                        }
                        d = e + dp + 1;
                        i = xc[d];
                        k = baseOut / 2;
                        r = r || d < 0 || xc[d + 1] != null;
                        r = rm < 4 ? (i != null || r) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : i > k || i == k && (rm == 4 || r || rm == 6 && xc[d - 1] & 1 || rm == (x.s < 0 ? 8 : 7));
                        if (d < 1 || !xc[0]) {
                            str = r ? toFixedPoint(alphabet.charAt(1), -dp, alphabet.charAt(0)) : alphabet.charAt(0);
                        } else {
                            xc.length = d;
                            if (r) {
                                for(--baseOut; ++xc[--d] > baseOut;){
                                    xc[d] = 0;
                                    if (!d) {
                                        ++e;
                                        xc = [
                                            1
                                        ].concat(xc);
                                    }
                                }
                            }
                            for(k = xc.length; !xc[--k];);
                            for(i = 0, str = ""; i <= k; str += alphabet.charAt(xc[i++]));
                            str = toFixedPoint(str, e, alphabet.charAt(0));
                        }
                        return str;
                    };
                }();
                div = /* @__PURE__ */ function() {
                    function multiply(x, k, base) {
                        var m, temp, xlo, xhi, carry = 0, i = x.length, klo = k % SQRT_BASE, khi = k / SQRT_BASE | 0;
                        for(x = x.slice(); i--;){
                            xlo = x[i] % SQRT_BASE;
                            xhi = x[i] / SQRT_BASE | 0;
                            m = khi * xlo + xhi * klo;
                            temp = klo * xlo + m % SQRT_BASE * SQRT_BASE + carry;
                            carry = (temp / base | 0) + (m / SQRT_BASE | 0) + khi * xhi;
                            x[i] = temp % base;
                        }
                        if (carry) x = [
                            carry
                        ].concat(x);
                        return x;
                    }
                    function compare2(a, b, aL, bL) {
                        var i, cmp;
                        if (aL != bL) {
                            cmp = aL > bL ? 1 : -1;
                        } else {
                            for(i = cmp = 0; i < aL; i++){
                                if (a[i] != b[i]) {
                                    cmp = a[i] > b[i] ? 1 : -1;
                                    break;
                                }
                            }
                        }
                        return cmp;
                    }
                    function subtract(a, b, aL, base) {
                        var i = 0;
                        for(; aL--;){
                            a[aL] -= i;
                            i = a[aL] < b[aL] ? 1 : 0;
                            a[aL] = i * base + a[aL] - b[aL];
                        }
                        for(; !a[0] && a.length > 1; a.splice(0, 1));
                    }
                    return function(x, y, dp, rm, base) {
                        var cmp, e, i, more, n, prod, prodL, q, qc, rem, remL, rem0, xi, xL, yc0, yL, yz, s = x.s == y.s ? 1 : -1, xc = x.c, yc = y.c;
                        if (!xc || !xc[0] || !yc || !yc[0]) {
                            return new BigNumber2(// Return NaN if either NaN, or both Infinity or 0.
                            !x.s || !y.s || (xc ? yc && xc[0] == yc[0] : !yc) ? NaN : // Return ±0 if x is ±0 or y is ±Infinity, or return ±Infinity as y is ±0.
                            xc && xc[0] == 0 || !yc ? s * 0 : s / 0);
                        }
                        q = new BigNumber2(s);
                        qc = q.c = [];
                        e = x.e - y.e;
                        s = dp + e + 1;
                        if (!base) {
                            base = BASE;
                            e = bitFloor(x.e / LOG_BASE) - bitFloor(y.e / LOG_BASE);
                            s = s / LOG_BASE | 0;
                        }
                        for(i = 0; yc[i] == (xc[i] || 0); i++);
                        if (yc[i] > (xc[i] || 0)) e--;
                        if (s < 0) {
                            qc.push(1);
                            more = true;
                        } else {
                            xL = xc.length;
                            yL = yc.length;
                            i = 0;
                            s += 2;
                            n = mathfloor(base / (yc[0] + 1));
                            if (n > 1) {
                                yc = multiply(yc, n, base);
                                xc = multiply(xc, n, base);
                                yL = yc.length;
                                xL = xc.length;
                            }
                            xi = yL;
                            rem = xc.slice(0, yL);
                            remL = rem.length;
                            for(; remL < yL; rem[remL++] = 0);
                            yz = yc.slice();
                            yz = [
                                0
                            ].concat(yz);
                            yc0 = yc[0];
                            if (yc[1] >= base / 2) yc0++;
                            do {
                                n = 0;
                                cmp = compare2(yc, rem, yL, remL);
                                if (cmp < 0) {
                                    rem0 = rem[0];
                                    if (yL != remL) rem0 = rem0 * base + (rem[1] || 0);
                                    n = mathfloor(rem0 / yc0);
                                    if (n > 1) {
                                        if (n >= base) n = base - 1;
                                        prod = multiply(yc, n, base);
                                        prodL = prod.length;
                                        remL = rem.length;
                                        while(compare2(prod, rem, prodL, remL) == 1){
                                            n--;
                                            subtract(prod, yL < prodL ? yz : yc, prodL, base);
                                            prodL = prod.length;
                                            cmp = 1;
                                        }
                                    } else {
                                        if (n == 0) {
                                            cmp = n = 1;
                                        }
                                        prod = yc.slice();
                                        prodL = prod.length;
                                    }
                                    if (prodL < remL) prod = [
                                        0
                                    ].concat(prod);
                                    subtract(rem, prod, remL, base);
                                    remL = rem.length;
                                    if (cmp == -1) {
                                        while(compare2(yc, rem, yL, remL) < 1){
                                            n++;
                                            subtract(rem, yL < remL ? yz : yc, remL, base);
                                            remL = rem.length;
                                        }
                                    }
                                } else if (cmp === 0) {
                                    n++;
                                    rem = [
                                        0
                                    ];
                                }
                                qc[i++] = n;
                                if (rem[0]) {
                                    rem[remL++] = xc[xi] || 0;
                                } else {
                                    rem = [
                                        xc[xi]
                                    ];
                                    remL = 1;
                                }
                            }while ((xi++ < xL || rem[0] != null) && s--)
                            more = rem[0] != null;
                            if (!qc[0]) qc.splice(0, 1);
                        }
                        if (base == BASE) {
                            for(i = 1, s = qc[0]; s >= 10; s /= 10, i++);
                            round(q, dp + (q.e = i + e * LOG_BASE - 1) + 1, rm, more);
                        } else {
                            q.e = e;
                            q.r = +more;
                        }
                        return q;
                    };
                }();
                function format(n, i, rm, id) {
                    var c0, e, ne, len, str;
                    if (rm == null) rm = ROUNDING_MODE;
                    else intCheck(rm, 0, 8);
                    if (!n.c) return n.toString();
                    c0 = n.c[0];
                    ne = n.e;
                    if (i == null) {
                        str = coeffToString(n.c);
                        str = id == 1 || id == 2 && (ne <= TO_EXP_NEG || ne >= TO_EXP_POS) ? toExponential(str, ne) : toFixedPoint(str, ne, "0");
                    } else {
                        n = round(new BigNumber2(n), i, rm);
                        e = n.e;
                        str = coeffToString(n.c);
                        len = str.length;
                        if (id == 1 || id == 2 && (i <= e || e <= TO_EXP_NEG)) {
                            for(; len < i; str += "0", len++);
                            str = toExponential(str, e);
                        } else {
                            i -= ne;
                            str = toFixedPoint(str, e, "0");
                            if (e + 1 > len) {
                                if (--i > 0) for(str += "."; i--; str += "0");
                            } else {
                                i += e - len;
                                if (i > 0) {
                                    if (e + 1 == len) str += ".";
                                    for(; i--; str += "0");
                                }
                            }
                        }
                    }
                    return n.s < 0 && c0 ? "-" + str : str;
                }
                function maxOrMin(args, n) {
                    var k, y, i = 1, x = new BigNumber2(args[0]);
                    for(; i < args.length; i++){
                        y = new BigNumber2(args[i]);
                        if (!y.s || (k = compare(x, y)) === n || k === 0 && x.s === n) {
                            x = y;
                        }
                    }
                    return x;
                }
                function normalise(n, c, e) {
                    var i = 1, j = c.length;
                    for(; !c[--j]; c.pop());
                    for(j = c[0]; j >= 10; j /= 10, i++);
                    if ((e = i + e * LOG_BASE - 1) > MAX_EXP) {
                        n.c = n.e = null;
                    } else if (e < MIN_EXP) {
                        n.c = [
                            n.e = 0
                        ];
                    } else {
                        n.e = e;
                        n.c = c;
                    }
                    return n;
                }
                parseNumeric = /* @__PURE__ */ function() {
                    var basePrefix = /^(-?)0([xbo])(?=\w[\w.]*$)/i, dotAfter = /^([^.]+)\.$/, dotBefore = /^\.([^.]+)$/, isInfinityOrNaN = /^-?(Infinity|NaN)$/, whitespaceOrPlus = /^\s*\+(?=[\w.])|^\s+|\s+$/g;
                    return function(x, str, isNum, b) {
                        var base, s = isNum ? str : str.replace(whitespaceOrPlus, "");
                        if (isInfinityOrNaN.test(s)) {
                            x.s = isNaN(s) ? null : s < 0 ? -1 : 1;
                        } else {
                            if (!isNum) {
                                s = s.replace(basePrefix, function(m, p1, p2) {
                                    base = (p2 = p2.toLowerCase()) == "x" ? 16 : p2 == "b" ? 2 : 8;
                                    return !b || b == base ? p1 : m;
                                });
                                if (b) {
                                    base = b;
                                    s = s.replace(dotAfter, "$1").replace(dotBefore, "0.$1");
                                }
                                if (str != s) return new BigNumber2(s, base);
                            }
                            if (BigNumber2.DEBUG) {
                                throw Error(bignumberError + "Not a" + (b ? " base " + b : "") + " number: " + str);
                            }
                            x.s = null;
                        }
                        x.c = x.e = null;
                    };
                }();
                function round(x, sd, rm, r) {
                    var d, i, j, k, n, ni, rd, xc = x.c, pows10 = POWS_TEN;
                    if (xc) {
                        out: {
                            for(d = 1, k = xc[0]; k >= 10; k /= 10, d++);
                            i = sd - d;
                            if (i < 0) {
                                i += LOG_BASE;
                                j = sd;
                                n = xc[ni = 0];
                                rd = mathfloor(n / pows10[d - j - 1] % 10);
                            } else {
                                ni = mathceil((i + 1) / LOG_BASE);
                                if (ni >= xc.length) {
                                    if (r) {
                                        for(; xc.length <= ni; xc.push(0));
                                        n = rd = 0;
                                        d = 1;
                                        i %= LOG_BASE;
                                        j = i - LOG_BASE + 1;
                                    } else {
                                        break out;
                                    }
                                } else {
                                    n = k = xc[ni];
                                    for(d = 1; k >= 10; k /= 10, d++);
                                    i %= LOG_BASE;
                                    j = i - LOG_BASE + d;
                                    rd = j < 0 ? 0 : mathfloor(n / pows10[d - j - 1] % 10);
                                }
                            }
                            r = r || sd < 0 || // Are there any non-zero digits after the rounding digit?
                            // The expression  n % pows10[d - j - 1]  returns all digits of n to the right
                            // of the digit at j, e.g. if n is 908714 and j is 2, the expression gives 714.
                            xc[ni + 1] != null || (j < 0 ? n : n % pows10[d - j - 1]);
                            r = rm < 4 ? (rd || r) && (rm == 0 || rm == (x.s < 0 ? 3 : 2)) : rd > 5 || rd == 5 && (rm == 4 || r || rm == 6 && // Check whether the digit to the left of the rounding digit is odd.
                            (i > 0 ? j > 0 ? n / pows10[d - j] : 0 : xc[ni - 1]) % 10 & 1 || rm == (x.s < 0 ? 8 : 7));
                            if (sd < 1 || !xc[0]) {
                                xc.length = 0;
                                if (r) {
                                    sd -= x.e + 1;
                                    xc[0] = pows10[(LOG_BASE - sd % LOG_BASE) % LOG_BASE];
                                    x.e = -sd || 0;
                                } else {
                                    xc[0] = x.e = 0;
                                }
                                return x;
                            }
                            if (i == 0) {
                                xc.length = ni;
                                k = 1;
                                ni--;
                            } else {
                                xc.length = ni + 1;
                                k = pows10[LOG_BASE - i];
                                xc[ni] = j > 0 ? mathfloor(n / pows10[d - j] % pows10[j]) * k : 0;
                            }
                            if (r) {
                                for(;;){
                                    if (ni == 0) {
                                        for(i = 1, j = xc[0]; j >= 10; j /= 10, i++);
                                        j = xc[0] += k;
                                        for(k = 1; j >= 10; j /= 10, k++);
                                        if (i != k) {
                                            x.e++;
                                            if (xc[0] == BASE) xc[0] = 1;
                                        }
                                        break;
                                    } else {
                                        xc[ni] += k;
                                        if (xc[ni] != BASE) break;
                                        xc[ni--] = 0;
                                        k = 1;
                                    }
                                }
                            }
                            for(i = xc.length; xc[--i] === 0; xc.pop());
                        }
                        if (x.e > MAX_EXP) {
                            x.c = x.e = null;
                        } else if (x.e < MIN_EXP) {
                            x.c = [
                                x.e = 0
                            ];
                        }
                    }
                    return x;
                }
                function valueOf(n) {
                    var str, e = n.e;
                    if (e === null) return n.toString();
                    str = coeffToString(n.c);
                    str = e <= TO_EXP_NEG || e >= TO_EXP_POS ? toExponential(str, e) : toFixedPoint(str, e, "0");
                    return n.s < 0 ? "-" + str : str;
                }
                P.absoluteValue = P.abs = function() {
                    var x = new BigNumber2(this);
                    if (x.s < 0) x.s = 1;
                    return x;
                };
                P.comparedTo = function(y, b) {
                    return compare(this, new BigNumber2(y, b));
                };
                P.decimalPlaces = P.dp = function(dp, rm) {
                    var c, n, v, x = this;
                    if (dp != null) {
                        intCheck(dp, 0, MAX);
                        if (rm == null) rm = ROUNDING_MODE;
                        else intCheck(rm, 0, 8);
                        return round(new BigNumber2(x), dp + x.e + 1, rm);
                    }
                    if (!(c = x.c)) return null;
                    n = ((v = c.length - 1) - bitFloor(this.e / LOG_BASE)) * LOG_BASE;
                    if (v = c[v]) for(; v % 10 == 0; v /= 10, n--);
                    if (n < 0) n = 0;
                    return n;
                };
                P.dividedBy = P.div = function(y, b) {
                    return div(this, new BigNumber2(y, b), DECIMAL_PLACES, ROUNDING_MODE);
                };
                P.dividedToIntegerBy = P.idiv = function(y, b) {
                    return div(this, new BigNumber2(y, b), 0, 1);
                };
                P.exponentiatedBy = P.pow = function(n, m) {
                    var half, isModExp, i, k, more, nIsBig, nIsNeg, nIsOdd, y, x = this;
                    n = new BigNumber2(n);
                    if (n.c && !n.isInteger()) {
                        throw Error(bignumberError + "Exponent not an integer: " + valueOf(n));
                    }
                    if (m != null) m = new BigNumber2(m);
                    nIsBig = n.e > 14;
                    if (!x.c || !x.c[0] || x.c[0] == 1 && !x.e && x.c.length == 1 || !n.c || !n.c[0]) {
                        y = new BigNumber2(Math.pow(+valueOf(x), nIsBig ? n.s * (2 - isOdd(n)) : +valueOf(n)));
                        return m ? y.mod(m) : y;
                    }
                    nIsNeg = n.s < 0;
                    if (m) {
                        if (m.c ? !m.c[0] : !m.s) return new BigNumber2(NaN);
                        isModExp = !nIsNeg && x.isInteger() && m.isInteger();
                        if (isModExp) x = x.mod(m);
                    } else if (n.e > 9 && (x.e > 0 || x.e < -1 || (x.e == 0 ? x.c[0] > 1 || nIsBig && x.c[1] >= 24e7 : x.c[0] < 8e13 || nIsBig && x.c[0] <= 9999975e7))) {
                        k = x.s < 0 && isOdd(n) ? -0 : 0;
                        if (x.e > -1) k = 1 / k;
                        return new BigNumber2(nIsNeg ? 1 / k : k);
                    } else if (POW_PRECISION) {
                        k = mathceil(POW_PRECISION / LOG_BASE + 2);
                    }
                    if (nIsBig) {
                        half = new BigNumber2(0.5);
                        if (nIsNeg) n.s = 1;
                        nIsOdd = isOdd(n);
                    } else {
                        i = Math.abs(+valueOf(n));
                        nIsOdd = i % 2;
                    }
                    y = new BigNumber2(ONE);
                    for(;;){
                        if (nIsOdd) {
                            y = y.times(x);
                            if (!y.c) break;
                            if (k) {
                                if (y.c.length > k) y.c.length = k;
                            } else if (isModExp) {
                                y = y.mod(m);
                            }
                        }
                        if (i) {
                            i = mathfloor(i / 2);
                            if (i === 0) break;
                            nIsOdd = i % 2;
                        } else {
                            n = n.times(half);
                            round(n, n.e + 1, 1);
                            if (n.e > 14) {
                                nIsOdd = isOdd(n);
                            } else {
                                i = +valueOf(n);
                                if (i === 0) break;
                                nIsOdd = i % 2;
                            }
                        }
                        x = x.times(x);
                        if (k) {
                            if (x.c && x.c.length > k) x.c.length = k;
                        } else if (isModExp) {
                            x = x.mod(m);
                        }
                    }
                    if (isModExp) return y;
                    if (nIsNeg) y = ONE.div(y);
                    return m ? y.mod(m) : k ? round(y, POW_PRECISION, ROUNDING_MODE, more) : y;
                };
                P.integerValue = function(rm) {
                    var n = new BigNumber2(this);
                    if (rm == null) rm = ROUNDING_MODE;
                    else intCheck(rm, 0, 8);
                    return round(n, n.e + 1, rm);
                };
                P.isEqualTo = P.eq = function(y, b) {
                    return compare(this, new BigNumber2(y, b)) === 0;
                };
                P.isFinite = function() {
                    return !!this.c;
                };
                P.isGreaterThan = P.gt = function(y, b) {
                    return compare(this, new BigNumber2(y, b)) > 0;
                };
                P.isGreaterThanOrEqualTo = P.gte = function(y, b) {
                    return (b = compare(this, new BigNumber2(y, b))) === 1 || b === 0;
                };
                P.isInteger = function() {
                    return !!this.c && bitFloor(this.e / LOG_BASE) > this.c.length - 2;
                };
                P.isLessThan = P.lt = function(y, b) {
                    return compare(this, new BigNumber2(y, b)) < 0;
                };
                P.isLessThanOrEqualTo = P.lte = function(y, b) {
                    return (b = compare(this, new BigNumber2(y, b))) === -1 || b === 0;
                };
                P.isNaN = function() {
                    return !this.s;
                };
                P.isNegative = function() {
                    return this.s < 0;
                };
                P.isPositive = function() {
                    return this.s > 0;
                };
                P.isZero = function() {
                    return !!this.c && this.c[0] == 0;
                };
                P.minus = function(y, b) {
                    var i, j, t, xLTy, x = this, a = x.s;
                    y = new BigNumber2(y, b);
                    b = y.s;
                    if (!a || !b) return new BigNumber2(NaN);
                    if (a != b) {
                        y.s = -b;
                        return x.plus(y);
                    }
                    var xe = x.e / LOG_BASE, ye = y.e / LOG_BASE, xc = x.c, yc = y.c;
                    if (!xe || !ye) {
                        if (!xc || !yc) return xc ? (y.s = -b, y) : new BigNumber2(yc ? x : NaN);
                        if (!xc[0] || !yc[0]) {
                            return yc[0] ? (y.s = -b, y) : new BigNumber2(xc[0] ? x : // IEEE 754 (2008) 6.3: n - n = -0 when rounding to -Infinity
                            ROUNDING_MODE == 3 ? -0 : 0);
                        }
                    }
                    xe = bitFloor(xe);
                    ye = bitFloor(ye);
                    xc = xc.slice();
                    if (a = xe - ye) {
                        if (xLTy = a < 0) {
                            a = -a;
                            t = xc;
                        } else {
                            ye = xe;
                            t = yc;
                        }
                        t.reverse();
                        for(b = a; b--; t.push(0));
                        t.reverse();
                    } else {
                        j = (xLTy = (a = xc.length) < (b = yc.length)) ? a : b;
                        for(a = b = 0; b < j; b++){
                            if (xc[b] != yc[b]) {
                                xLTy = xc[b] < yc[b];
                                break;
                            }
                        }
                    }
                    if (xLTy) {
                        t = xc;
                        xc = yc;
                        yc = t;
                        y.s = -y.s;
                    }
                    b = (j = yc.length) - (i = xc.length);
                    if (b > 0) for(; b--; xc[i++] = 0);
                    b = BASE - 1;
                    for(; j > a;){
                        if (xc[--j] < yc[j]) {
                            for(i = j; i && !xc[--i]; xc[i] = b);
                            --xc[i];
                            xc[j] += BASE;
                        }
                        xc[j] -= yc[j];
                    }
                    for(; xc[0] == 0; xc.splice(0, 1), --ye);
                    if (!xc[0]) {
                        y.s = ROUNDING_MODE == 3 ? -1 : 1;
                        y.c = [
                            y.e = 0
                        ];
                        return y;
                    }
                    return normalise(y, xc, ye);
                };
                P.modulo = P.mod = function(y, b) {
                    var q, s, x = this;
                    y = new BigNumber2(y, b);
                    if (!x.c || !y.s || y.c && !y.c[0]) {
                        return new BigNumber2(NaN);
                    } else if (!y.c || x.c && !x.c[0]) {
                        return new BigNumber2(x);
                    }
                    if (MODULO_MODE == 9) {
                        s = y.s;
                        y.s = 1;
                        q = div(x, y, 0, 3);
                        y.s = s;
                        q.s *= s;
                    } else {
                        q = div(x, y, 0, MODULO_MODE);
                    }
                    y = x.minus(q.times(y));
                    if (!y.c[0] && MODULO_MODE == 1) y.s = x.s;
                    return y;
                };
                P.multipliedBy = P.times = function(y, b) {
                    var c, e, i, j, k, m, xcL, xlo, xhi, ycL, ylo, yhi, zc, base, sqrtBase, x = this, xc = x.c, yc = (y = new BigNumber2(y, b)).c;
                    if (!xc || !yc || !xc[0] || !yc[0]) {
                        if (!x.s || !y.s || xc && !xc[0] && !yc || yc && !yc[0] && !xc) {
                            y.c = y.e = y.s = null;
                        } else {
                            y.s *= x.s;
                            if (!xc || !yc) {
                                y.c = y.e = null;
                            } else {
                                y.c = [
                                    0
                                ];
                                y.e = 0;
                            }
                        }
                        return y;
                    }
                    e = bitFloor(x.e / LOG_BASE) + bitFloor(y.e / LOG_BASE);
                    y.s *= x.s;
                    xcL = xc.length;
                    ycL = yc.length;
                    if (xcL < ycL) {
                        zc = xc;
                        xc = yc;
                        yc = zc;
                        i = xcL;
                        xcL = ycL;
                        ycL = i;
                    }
                    for(i = xcL + ycL, zc = []; i--; zc.push(0));
                    base = BASE;
                    sqrtBase = SQRT_BASE;
                    for(i = ycL; --i >= 0;){
                        c = 0;
                        ylo = yc[i] % sqrtBase;
                        yhi = yc[i] / sqrtBase | 0;
                        for(k = xcL, j = i + k; j > i;){
                            xlo = xc[--k] % sqrtBase;
                            xhi = xc[k] / sqrtBase | 0;
                            m = yhi * xlo + xhi * ylo;
                            xlo = ylo * xlo + m % sqrtBase * sqrtBase + zc[j] + c;
                            c = (xlo / base | 0) + (m / sqrtBase | 0) + yhi * xhi;
                            zc[j--] = xlo % base;
                        }
                        zc[j] = c;
                    }
                    if (c) {
                        ++e;
                    } else {
                        zc.splice(0, 1);
                    }
                    return normalise(y, zc, e);
                };
                P.negated = function() {
                    var x = new BigNumber2(this);
                    x.s = -x.s || null;
                    return x;
                };
                P.plus = function(y, b) {
                    var t, x = this, a = x.s;
                    y = new BigNumber2(y, b);
                    b = y.s;
                    if (!a || !b) return new BigNumber2(NaN);
                    if (a != b) {
                        y.s = -b;
                        return x.minus(y);
                    }
                    var xe = x.e / LOG_BASE, ye = y.e / LOG_BASE, xc = x.c, yc = y.c;
                    if (!xe || !ye) {
                        if (!xc || !yc) return new BigNumber2(a / 0);
                        if (!xc[0] || !yc[0]) return yc[0] ? y : new BigNumber2(xc[0] ? x : a * 0);
                    }
                    xe = bitFloor(xe);
                    ye = bitFloor(ye);
                    xc = xc.slice();
                    if (a = xe - ye) {
                        if (a > 0) {
                            ye = xe;
                            t = yc;
                        } else {
                            a = -a;
                            t = xc;
                        }
                        t.reverse();
                        for(; a--; t.push(0));
                        t.reverse();
                    }
                    a = xc.length;
                    b = yc.length;
                    if (a - b < 0) {
                        t = yc;
                        yc = xc;
                        xc = t;
                        b = a;
                    }
                    for(a = 0; b;){
                        a = (xc[--b] = xc[b] + yc[b] + a) / BASE | 0;
                        xc[b] = BASE === xc[b] ? 0 : xc[b] % BASE;
                    }
                    if (a) {
                        xc = [
                            a
                        ].concat(xc);
                        ++ye;
                    }
                    return normalise(y, xc, ye);
                };
                P.precision = P.sd = function(sd, rm) {
                    var c, n, v, x = this;
                    if (sd != null && sd !== !!sd) {
                        intCheck(sd, 1, MAX);
                        if (rm == null) rm = ROUNDING_MODE;
                        else intCheck(rm, 0, 8);
                        return round(new BigNumber2(x), sd, rm);
                    }
                    if (!(c = x.c)) return null;
                    v = c.length - 1;
                    n = v * LOG_BASE + 1;
                    if (v = c[v]) {
                        for(; v % 10 == 0; v /= 10, n--);
                        for(v = c[0]; v >= 10; v /= 10, n++);
                    }
                    if (sd && x.e + 1 > n) n = x.e + 1;
                    return n;
                };
                P.shiftedBy = function(k) {
                    intCheck(k, -MAX_SAFE_INTEGER, MAX_SAFE_INTEGER);
                    return this.times("1e" + k);
                };
                P.squareRoot = P.sqrt = function() {
                    var m, n, r, rep, t, x = this, c = x.c, s = x.s, e = x.e, dp = DECIMAL_PLACES + 4, half = new BigNumber2("0.5");
                    if (s !== 1 || !c || !c[0]) {
                        return new BigNumber2(!s || s < 0 && (!c || c[0]) ? NaN : c ? x : 1 / 0);
                    }
                    s = Math.sqrt(+valueOf(x));
                    if (s == 0 || s == 1 / 0) {
                        n = coeffToString(c);
                        if ((n.length + e) % 2 == 0) n += "0";
                        s = Math.sqrt(+n);
                        e = bitFloor((e + 1) / 2) - (e < 0 || e % 2);
                        if (s == 1 / 0) {
                            n = "5e" + e;
                        } else {
                            n = s.toExponential();
                            n = n.slice(0, n.indexOf("e") + 1) + e;
                        }
                        r = new BigNumber2(n);
                    } else {
                        r = new BigNumber2(s + "");
                    }
                    if (r.c[0]) {
                        e = r.e;
                        s = e + dp;
                        if (s < 3) s = 0;
                        for(;;){
                            t = r;
                            r = half.times(t.plus(div(x, t, dp, 1)));
                            if (coeffToString(t.c).slice(0, s) === (n = coeffToString(r.c)).slice(0, s)) {
                                if (r.e < e) --s;
                                n = n.slice(s - 3, s + 1);
                                if (n == "9999" || !rep && n == "4999") {
                                    if (!rep) {
                                        round(t, t.e + DECIMAL_PLACES + 2, 0);
                                        if (t.times(t).eq(x)) {
                                            r = t;
                                            break;
                                        }
                                    }
                                    dp += 4;
                                    s += 4;
                                    rep = 1;
                                } else {
                                    if (!+n || !+n.slice(1) && n.charAt(0) == "5") {
                                        round(r, r.e + DECIMAL_PLACES + 2, 1);
                                        m = !r.times(r).eq(x);
                                    }
                                    break;
                                }
                            }
                        }
                    }
                    return round(r, r.e + DECIMAL_PLACES + 1, ROUNDING_MODE, m);
                };
                P.toExponential = function(dp, rm) {
                    if (dp != null) {
                        intCheck(dp, 0, MAX);
                        dp++;
                    }
                    return format(this, dp, rm, 1);
                };
                P.toFixed = function(dp, rm) {
                    if (dp != null) {
                        intCheck(dp, 0, MAX);
                        dp = dp + this.e + 1;
                    }
                    return format(this, dp, rm);
                };
                P.toFormat = function(dp, rm, format2) {
                    var str, x = this;
                    if (format2 == null) {
                        if (dp != null && rm && typeof rm == "object") {
                            format2 = rm;
                            rm = null;
                        } else if (dp && typeof dp == "object") {
                            format2 = dp;
                            dp = rm = null;
                        } else {
                            format2 = FORMAT;
                        }
                    } else if (typeof format2 != "object") {
                        throw Error(bignumberError + "Argument not an object: " + format2);
                    }
                    str = x.toFixed(dp, rm);
                    if (x.c) {
                        var i, arr = str.split("."), g1 = +format2.groupSize, g2 = +format2.secondaryGroupSize, groupSeparator = format2.groupSeparator || "", intPart = arr[0], fractionPart = arr[1], isNeg = x.s < 0, intDigits = isNeg ? intPart.slice(1) : intPart, len = intDigits.length;
                        if (g2) {
                            i = g1;
                            g1 = g2;
                            g2 = i;
                            len -= i;
                        }
                        if (g1 > 0 && len > 0) {
                            i = len % g1 || g1;
                            intPart = intDigits.substr(0, i);
                            for(; i < len; i += g1)intPart += groupSeparator + intDigits.substr(i, g1);
                            if (g2 > 0) intPart += groupSeparator + intDigits.slice(i);
                            if (isNeg) intPart = "-" + intPart;
                        }
                        str = fractionPart ? intPart + (format2.decimalSeparator || "") + ((g2 = +format2.fractionGroupSize) ? fractionPart.replace(new RegExp("\\d{" + g2 + "}\\B", "g"), "$&" + (format2.fractionGroupSeparator || "")) : fractionPart) : intPart;
                    }
                    return (format2.prefix || "") + str + (format2.suffix || "");
                };
                P.toFraction = function(md) {
                    var d, d0, d1, d2, e, exp, n, n0, n1, q, r, s, x = this, xc = x.c;
                    if (md != null) {
                        n = new BigNumber2(md);
                        if (!n.isInteger() && (n.c || n.s !== 1) || n.lt(ONE)) {
                            throw Error(bignumberError + "Argument " + (n.isInteger() ? "out of range: " : "not an integer: ") + valueOf(n));
                        }
                    }
                    if (!xc) return new BigNumber2(x);
                    d = new BigNumber2(ONE);
                    n1 = d0 = new BigNumber2(ONE);
                    d1 = n0 = new BigNumber2(ONE);
                    s = coeffToString(xc);
                    e = d.e = s.length - x.e - 1;
                    d.c[0] = POWS_TEN[(exp = e % LOG_BASE) < 0 ? LOG_BASE + exp : exp];
                    md = !md || n.comparedTo(d) > 0 ? e > 0 ? d : n1 : n;
                    exp = MAX_EXP;
                    MAX_EXP = 1 / 0;
                    n = new BigNumber2(s);
                    n0.c[0] = 0;
                    for(;;){
                        q = div(n, d, 0, 1);
                        d2 = d0.plus(q.times(d1));
                        if (d2.comparedTo(md) == 1) break;
                        d0 = d1;
                        d1 = d2;
                        n1 = n0.plus(q.times(d2 = n1));
                        n0 = d2;
                        d = n.minus(q.times(d2 = d));
                        n = d2;
                    }
                    d2 = div(md.minus(d0), d1, 0, 1);
                    n0 = n0.plus(d2.times(n1));
                    d0 = d0.plus(d2.times(d1));
                    n0.s = n1.s = x.s;
                    e = e * 2;
                    r = div(n1, d1, e, ROUNDING_MODE).minus(x).abs().comparedTo(div(n0, d0, e, ROUNDING_MODE).minus(x).abs()) < 1 ? [
                        n1,
                        d1
                    ] : [
                        n0,
                        d0
                    ];
                    MAX_EXP = exp;
                    return r;
                };
                P.toNumber = function() {
                    return +valueOf(this);
                };
                P.toPrecision = function(sd, rm) {
                    if (sd != null) intCheck(sd, 1, MAX);
                    return format(this, sd, rm, 2);
                };
                P.toString = function(b) {
                    var str, n = this, s = n.s, e = n.e;
                    if (e === null) {
                        if (s) {
                            str = "Infinity";
                            if (s < 0) str = "-" + str;
                        } else {
                            str = "NaN";
                        }
                    } else {
                        if (b == null) {
                            str = e <= TO_EXP_NEG || e >= TO_EXP_POS ? toExponential(coeffToString(n.c), e) : toFixedPoint(coeffToString(n.c), e, "0");
                        } else if (b === 10 && alphabetHasNormalDecimalDigits) {
                            n = round(new BigNumber2(n), DECIMAL_PLACES + e + 1, ROUNDING_MODE);
                            str = toFixedPoint(coeffToString(n.c), n.e, "0");
                        } else {
                            intCheck(b, 2, ALPHABET.length, "Base");
                            str = convertBase(toFixedPoint(coeffToString(n.c), e, "0"), 10, b, s, true);
                        }
                        if (s < 0 && n.c[0]) str = "-" + str;
                    }
                    return str;
                };
                P.valueOf = P.toJSON = function() {
                    return valueOf(this);
                };
                P._isBigNumber = true;
                if (configObject != null) BigNumber2.set(configObject);
                return BigNumber2;
            }
            function bitFloor(n) {
                var i = n | 0;
                return n > 0 || n === i ? i : i - 1;
            }
            function coeffToString(a) {
                var s, z, i = 1, j = a.length, r = a[0] + "";
                for(; i < j;){
                    s = a[i++] + "";
                    z = LOG_BASE - s.length;
                    for(; z--; s = "0" + s);
                    r += s;
                }
                for(j = r.length; r.charCodeAt(--j) === 48;);
                return r.slice(0, j + 1 || 1);
            }
            function compare(x, y) {
                var a, b, xc = x.c, yc = y.c, i = x.s, j = y.s, k = x.e, l = y.e;
                if (!i || !j) return null;
                a = xc && !xc[0];
                b = yc && !yc[0];
                if (a || b) return a ? b ? 0 : -j : i;
                if (i != j) return i;
                a = i < 0;
                b = k == l;
                if (!xc || !yc) return b ? 0 : !xc ^ a ? 1 : -1;
                if (!b) return k > l ^ a ? 1 : -1;
                j = (k = xc.length) < (l = yc.length) ? k : l;
                for(i = 0; i < j; i++)if (xc[i] != yc[i]) return xc[i] > yc[i] ^ a ? 1 : -1;
                return k == l ? 0 : k > l ^ a ? 1 : -1;
            }
            function intCheck(n, min, max, name) {
                if (n < min || n > max || n !== mathfloor(n)) {
                    throw Error(bignumberError + (name || "Argument") + (typeof n == "number" ? n < min || n > max ? " out of range: " : " not an integer: " : " not a primitive number: ") + String(n));
                }
            }
            function isOdd(n) {
                var k = n.c.length - 1;
                return bitFloor(n.e / LOG_BASE) == k && n.c[k] % 2 != 0;
            }
            function toExponential(str, e) {
                return (str.length > 1 ? str.charAt(0) + "." + str.slice(1) : str) + (e < 0 ? "e" : "e+") + e;
            }
            function toFixedPoint(str, e, z) {
                var len, zs;
                if (e < 0) {
                    for(zs = z + "."; ++e; zs += z);
                    str = zs + str;
                } else {
                    len = str.length;
                    if (++e > len) {
                        for(zs = z, e -= len; --e; zs += z);
                        str += zs;
                    } else if (e < len) {
                        str = str.slice(0, e) + "." + str.slice(e);
                    }
                }
                return str;
            }
            BigNumber = clone();
            BigNumber["default"] = BigNumber.BigNumber = BigNumber;
            if (typeof define == "function" && define.amd) {
                ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
                    return BigNumber;
                }(__turbopack_context__.r, exports, module));
            } else if (typeof module != "undefined" && module.exports) {
                module.exports = BigNumber;
            } else {
                if (!globalObject) {
                    globalObject = typeof self != "undefined" && self ? self : window;
                }
                globalObject.BigNumber = BigNumber;
            }
        })(exports);
    }
});
// ../../node_modules/json-bigint/lib/stringify.js
var require_stringify = __commonJS({
    "../../node_modules/json-bigint/lib/stringify.js" (exports, module) {
        "use strict";
        var BigNumber = require_bignumber();
        var JSON2 = module.exports;
        (function() {
            "use strict";
            function f(n) {
                return n < 10 ? "0" + n : n;
            }
            var cx = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, escapable = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g, gap, indent, meta = {
                // table of character substitutions
                "\b": "\\b",
                "	": "\\t",
                "\n": "\\n",
                "\f": "\\f",
                "\r": "\\r",
                '"': '\\"',
                "\\": "\\\\"
            }, rep;
            function quote(string) {
                escapable.lastIndex = 0;
                return escapable.test(string) ? '"' + string.replace(escapable, function(a) {
                    var c = meta[a];
                    return typeof c === "string" ? c : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
                }) + '"' : '"' + string + '"';
            }
            function str(key, holder) {
                var i, k, v, length, mind = gap, partial, value = holder[key], isBigNumber = value != null && (value instanceof BigNumber || BigNumber.isBigNumber(value));
                if (value && typeof value === "object" && typeof value.toJSON === "function") {
                    value = value.toJSON(key);
                }
                if (typeof rep === "function") {
                    value = rep.call(holder, key, value);
                }
                switch(typeof value){
                    case "string":
                        if (isBigNumber) {
                            return value;
                        } else {
                            return quote(value);
                        }
                    case "number":
                        return isFinite(value) ? String(value) : "null";
                    case "boolean":
                    case "null":
                    case "bigint":
                        return String(value);
                    // If the type is 'object', we might be dealing with an object or an array or
                    // null.
                    case "object":
                        if (!value) {
                            return "null";
                        }
                        gap += indent;
                        partial = [];
                        if (Object.prototype.toString.apply(value) === "[object Array]") {
                            length = value.length;
                            for(i = 0; i < length; i += 1){
                                partial[i] = str(i, value) || "null";
                            }
                            v = partial.length === 0 ? "[]" : gap ? "[\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "]" : "[" + partial.join(",") + "]";
                            gap = mind;
                            return v;
                        }
                        if (rep && typeof rep === "object") {
                            length = rep.length;
                            for(i = 0; i < length; i += 1){
                                if (typeof rep[i] === "string") {
                                    k = rep[i];
                                    v = str(k, value);
                                    if (v) {
                                        partial.push(quote(k) + (gap ? ": " : ":") + v);
                                    }
                                }
                            }
                        } else {
                            Object.keys(value).forEach(function(k2) {
                                var v2 = str(k2, value);
                                if (v2) {
                                    partial.push(quote(k2) + (gap ? ": " : ":") + v2);
                                }
                            });
                        }
                        v = partial.length === 0 ? "{}" : gap ? "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}" : "{" + partial.join(",") + "}";
                        gap = mind;
                        return v;
                }
            }
            if (typeof JSON2.stringify !== "function") {
                JSON2.stringify = function(value, replacer, space) {
                    var i;
                    gap = "";
                    indent = "";
                    if (typeof space === "number") {
                        for(i = 0; i < space; i += 1){
                            indent += " ";
                        }
                    } else if (typeof space === "string") {
                        indent = space;
                    }
                    rep = replacer;
                    if (replacer && typeof replacer !== "function" && (typeof replacer !== "object" || typeof replacer.length !== "number")) {
                        throw new Error("JSON.stringify");
                    }
                    return str("", {
                        "": value
                    });
                };
            }
        })();
    }
});
// ../../node_modules/json-bigint/lib/parse.js
var require_parse = __commonJS({
    "../../node_modules/json-bigint/lib/parse.js" (exports, module) {
        "use strict";
        var BigNumber = null;
        var suspectProtoRx = /(?:_|\\u005[Ff])(?:_|\\u005[Ff])(?:p|\\u0070)(?:r|\\u0072)(?:o|\\u006[Ff])(?:t|\\u0074)(?:o|\\u006[Ff])(?:_|\\u005[Ff])(?:_|\\u005[Ff])/;
        var suspectConstructorRx = /(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)/;
        var json_parse = function(options) {
            "use strict";
            var _options = {
                strict: false,
                // not being strict means do not generate syntax errors for "duplicate key"
                storeAsString: false,
                // toggles whether the values should be stored as BigNumber (default) or a string
                alwaysParseAsBig: false,
                // toggles whether all numbers should be Big
                useNativeBigInt: false,
                // toggles whether to use native BigInt instead of bignumber.js
                protoAction: "error",
                constructorAction: "error"
            };
            if (options !== void 0 && options !== null) {
                if (options.strict === true) {
                    _options.strict = true;
                }
                if (options.storeAsString === true) {
                    _options.storeAsString = true;
                }
                _options.alwaysParseAsBig = options.alwaysParseAsBig === true ? options.alwaysParseAsBig : false;
                _options.useNativeBigInt = options.useNativeBigInt === true ? options.useNativeBigInt : false;
                if (typeof options.constructorAction !== "undefined") {
                    if (options.constructorAction === "error" || options.constructorAction === "ignore" || options.constructorAction === "preserve") {
                        _options.constructorAction = options.constructorAction;
                    } else {
                        throw new Error(`Incorrect value for constructorAction option, must be "error", "ignore" or undefined but passed ${options.constructorAction}`);
                    }
                }
                if (typeof options.protoAction !== "undefined") {
                    if (options.protoAction === "error" || options.protoAction === "ignore" || options.protoAction === "preserve") {
                        _options.protoAction = options.protoAction;
                    } else {
                        throw new Error(`Incorrect value for protoAction option, must be "error", "ignore" or undefined but passed ${options.protoAction}`);
                    }
                }
            }
            var at, ch, escapee = {
                '"': '"',
                "\\": "\\",
                "/": "/",
                b: "\b",
                f: "\f",
                n: "\n",
                r: "\r",
                t: "	"
            }, text, error = function(m) {
                throw {
                    name: "SyntaxError",
                    message: m,
                    at,
                    text
                };
            }, next = function(c) {
                if (c && c !== ch) {
                    error("Expected '" + c + "' instead of '" + ch + "'");
                }
                ch = text.charAt(at);
                at += 1;
                return ch;
            }, number = function() {
                var number2, string2 = "";
                if (ch === "-") {
                    string2 = "-";
                    next("-");
                }
                while(ch >= "0" && ch <= "9"){
                    string2 += ch;
                    next();
                }
                if (ch === ".") {
                    string2 += ".";
                    while(next() && ch >= "0" && ch <= "9"){
                        string2 += ch;
                    }
                }
                if (ch === "e" || ch === "E") {
                    string2 += ch;
                    next();
                    if (ch === "-" || ch === "+") {
                        string2 += ch;
                        next();
                    }
                    while(ch >= "0" && ch <= "9"){
                        string2 += ch;
                        next();
                    }
                }
                number2 = +string2;
                if (!isFinite(number2)) {
                    error("Bad number");
                } else {
                    if (BigNumber == null) BigNumber = require_bignumber();
                    if (string2.length > 15) return _options.storeAsString ? string2 : _options.useNativeBigInt ? BigInt(string2) : new BigNumber(string2);
                    else return !_options.alwaysParseAsBig ? number2 : _options.useNativeBigInt ? BigInt(number2) : new BigNumber(number2);
                }
            }, string = function() {
                var hex, i, string2 = "", uffff;
                if (ch === '"') {
                    var startAt = at;
                    while(next()){
                        if (ch === '"') {
                            if (at - 1 > startAt) string2 += text.substring(startAt, at - 1);
                            next();
                            return string2;
                        }
                        if (ch === "\\") {
                            if (at - 1 > startAt) string2 += text.substring(startAt, at - 1);
                            next();
                            if (ch === "u") {
                                uffff = 0;
                                for(i = 0; i < 4; i += 1){
                                    hex = parseInt(next(), 16);
                                    if (!isFinite(hex)) {
                                        break;
                                    }
                                    uffff = uffff * 16 + hex;
                                }
                                string2 += String.fromCharCode(uffff);
                            } else if (typeof escapee[ch] === "string") {
                                string2 += escapee[ch];
                            } else {
                                break;
                            }
                            startAt = at;
                        }
                    }
                }
                error("Bad string");
            }, white = function() {
                while(ch && ch <= " "){
                    next();
                }
            }, word = function() {
                switch(ch){
                    case "t":
                        next("t");
                        next("r");
                        next("u");
                        next("e");
                        return true;
                    case "f":
                        next("f");
                        next("a");
                        next("l");
                        next("s");
                        next("e");
                        return false;
                    case "n":
                        next("n");
                        next("u");
                        next("l");
                        next("l");
                        return null;
                }
                error("Unexpected '" + ch + "'");
            }, value, array = function() {
                var array2 = [];
                if (ch === "[") {
                    next("[");
                    white();
                    if (ch === "]") {
                        next("]");
                        return array2;
                    }
                    while(ch){
                        array2.push(value());
                        white();
                        if (ch === "]") {
                            next("]");
                            return array2;
                        }
                        next(",");
                        white();
                    }
                }
                error("Bad array");
            }, object = function() {
                var key, object2 = /* @__PURE__ */ Object.create(null);
                if (ch === "{") {
                    next("{");
                    white();
                    if (ch === "}") {
                        next("}");
                        return object2;
                    }
                    while(ch){
                        key = string();
                        white();
                        next(":");
                        if (_options.strict === true && Object.hasOwnProperty.call(object2, key)) {
                            error('Duplicate key "' + key + '"');
                        }
                        if (suspectProtoRx.test(key) === true) {
                            if (_options.protoAction === "error") {
                                error("Object contains forbidden prototype property");
                            } else if (_options.protoAction === "ignore") {
                                value();
                            } else {
                                object2[key] = value();
                            }
                        } else if (suspectConstructorRx.test(key) === true) {
                            if (_options.constructorAction === "error") {
                                error("Object contains forbidden constructor property");
                            } else if (_options.constructorAction === "ignore") {
                                value();
                            } else {
                                object2[key] = value();
                            }
                        } else {
                            object2[key] = value();
                        }
                        white();
                        if (ch === "}") {
                            next("}");
                            return object2;
                        }
                        next(",");
                        white();
                    }
                }
                error("Bad object");
            };
            value = function() {
                white();
                switch(ch){
                    case "{":
                        return object();
                    case "[":
                        return array();
                    case '"':
                        return string();
                    case "-":
                        return number();
                    default:
                        return ch >= "0" && ch <= "9" ? number() : word();
                }
            };
            return function(source, reviver) {
                var result;
                text = source + "";
                at = 0;
                ch = " ";
                result = value();
                white();
                if (ch) {
                    error("Syntax error");
                }
                return typeof reviver === "function" ? function walk(holder, key) {
                    var k, v, value2 = holder[key];
                    if (value2 && typeof value2 === "object") {
                        Object.keys(value2).forEach(function(k2) {
                            v = walk(value2, k2);
                            if (v !== void 0) {
                                value2[k2] = v;
                            } else {
                                delete value2[k2];
                            }
                        });
                    }
                    return reviver.call(holder, key, value2);
                }({
                    "": result
                }, "") : result;
            };
        };
        module.exports = json_parse;
    }
});
// ../../node_modules/json-bigint/index.js
var require_json_bigint = __commonJS({
    "../../node_modules/json-bigint/index.js" (exports, module) {
        "use strict";
        var json_stringify = require_stringify().stringify;
        var json_parse = require_parse();
        module.exports = function(options) {
            return {
                parse: json_parse(options),
                stringify: json_stringify
            };
        };
        module.exports.parse = json_parse();
        module.exports.stringify = json_stringify;
    }
});
// ../../node_modules/minimalistic-assert/index.js
var require_minimalistic_assert = __commonJS({
    "../../node_modules/minimalistic-assert/index.js" (exports, module) {
        "use strict";
        module.exports = assert;
        function assert(val, msg) {
            if (!val) throw new Error(msg || "Assertion failed");
        }
        assert.equal = function assertEqual(l, r, msg) {
            if (l != r) throw new Error(msg || "Assertion failed: " + l + " != " + r);
        };
    }
});
// ../../node_modules/inherits/inherits_browser.js
var require_inherits_browser = __commonJS({
    "../../node_modules/inherits/inherits_browser.js" (exports, module) {
        "use strict";
        if (typeof Object.create === "function") {
            module.exports = function inherits(ctor, superCtor) {
                if (superCtor) {
                    ctor.super_ = superCtor;
                    ctor.prototype = Object.create(superCtor.prototype, {
                        constructor: {
                            value: ctor,
                            enumerable: false,
                            writable: true,
                            configurable: true
                        }
                    });
                }
            };
        } else {
            module.exports = function inherits(ctor, superCtor) {
                if (superCtor) {
                    ctor.super_ = superCtor;
                    var TempCtor = function() {};
                    TempCtor.prototype = superCtor.prototype;
                    ctor.prototype = new TempCtor();
                    ctor.prototype.constructor = ctor;
                }
            };
        }
    }
});
// ../../node_modules/inherits/inherits.js
var require_inherits = __commonJS({
    "../../node_modules/inherits/inherits.js" (exports, module) {
        "use strict";
        try {
            util = __require("util");
            if (typeof util.inherits !== "function") throw "";
            module.exports = util.inherits;
        } catch (e) {
            module.exports = require_inherits_browser();
        }
        var util;
    }
});
// ../../node_modules/hash.js/lib/hash/utils.js
var require_utils = __commonJS({
    "../../node_modules/hash.js/lib/hash/utils.js" (exports) {
        "use strict";
        var assert = require_minimalistic_assert();
        var inherits = require_inherits();
        exports.inherits = inherits;
        function isSurrogatePair(msg, i) {
            if ((msg.charCodeAt(i) & 64512) !== 55296) {
                return false;
            }
            if (i < 0 || i + 1 >= msg.length) {
                return false;
            }
            return (msg.charCodeAt(i + 1) & 64512) === 56320;
        }
        function toArray(msg, enc) {
            if (Array.isArray(msg)) return msg.slice();
            if (!msg) return [];
            var res = [];
            if (typeof msg === "string") {
                if (!enc) {
                    var p = 0;
                    for(var i = 0; i < msg.length; i++){
                        var c = msg.charCodeAt(i);
                        if (c < 128) {
                            res[p++] = c;
                        } else if (c < 2048) {
                            res[p++] = c >> 6 | 192;
                            res[p++] = c & 63 | 128;
                        } else if (isSurrogatePair(msg, i)) {
                            c = 65536 + ((c & 1023) << 10) + (msg.charCodeAt(++i) & 1023);
                            res[p++] = c >> 18 | 240;
                            res[p++] = c >> 12 & 63 | 128;
                            res[p++] = c >> 6 & 63 | 128;
                            res[p++] = c & 63 | 128;
                        } else {
                            res[p++] = c >> 12 | 224;
                            res[p++] = c >> 6 & 63 | 128;
                            res[p++] = c & 63 | 128;
                        }
                    }
                } else if (enc === "hex") {
                    msg = msg.replace(/[^a-z0-9]+/ig, "");
                    if (msg.length % 2 !== 0) msg = "0" + msg;
                    for(i = 0; i < msg.length; i += 2)res.push(parseInt(msg[i] + msg[i + 1], 16));
                }
            } else {
                for(i = 0; i < msg.length; i++)res[i] = msg[i] | 0;
            }
            return res;
        }
        exports.toArray = toArray;
        function toHex(msg) {
            var res = "";
            for(var i = 0; i < msg.length; i++)res += zero2(msg[i].toString(16));
            return res;
        }
        exports.toHex = toHex;
        function htonl(w) {
            var res = w >>> 24 | w >>> 8 & 65280 | w << 8 & 16711680 | (w & 255) << 24;
            return res >>> 0;
        }
        exports.htonl = htonl;
        function toHex32(msg, endian) {
            var res = "";
            for(var i = 0; i < msg.length; i++){
                var w = msg[i];
                if (endian === "little") w = htonl(w);
                res += zero8(w.toString(16));
            }
            return res;
        }
        exports.toHex32 = toHex32;
        function zero2(word) {
            if (word.length === 1) return "0" + word;
            else return word;
        }
        exports.zero2 = zero2;
        function zero8(word) {
            if (word.length === 7) return "0" + word;
            else if (word.length === 6) return "00" + word;
            else if (word.length === 5) return "000" + word;
            else if (word.length === 4) return "0000" + word;
            else if (word.length === 3) return "00000" + word;
            else if (word.length === 2) return "000000" + word;
            else if (word.length === 1) return "0000000" + word;
            else return word;
        }
        exports.zero8 = zero8;
        function join32(msg, start, end, endian) {
            var len = end - start;
            assert(len % 4 === 0);
            var res = new Array(len / 4);
            for(var i = 0, k = start; i < res.length; i++, k += 4){
                var w;
                if (endian === "big") w = msg[k] << 24 | msg[k + 1] << 16 | msg[k + 2] << 8 | msg[k + 3];
                else w = msg[k + 3] << 24 | msg[k + 2] << 16 | msg[k + 1] << 8 | msg[k];
                res[i] = w >>> 0;
            }
            return res;
        }
        exports.join32 = join32;
        function split32(msg, endian) {
            var res = new Array(msg.length * 4);
            for(var i = 0, k = 0; i < msg.length; i++, k += 4){
                var m = msg[i];
                if (endian === "big") {
                    res[k] = m >>> 24;
                    res[k + 1] = m >>> 16 & 255;
                    res[k + 2] = m >>> 8 & 255;
                    res[k + 3] = m & 255;
                } else {
                    res[k + 3] = m >>> 24;
                    res[k + 2] = m >>> 16 & 255;
                    res[k + 1] = m >>> 8 & 255;
                    res[k] = m & 255;
                }
            }
            return res;
        }
        exports.split32 = split32;
        function rotr32(w, b) {
            return w >>> b | w << 32 - b;
        }
        exports.rotr32 = rotr32;
        function rotl32(w, b) {
            return w << b | w >>> 32 - b;
        }
        exports.rotl32 = rotl32;
        function sum32(a, b) {
            return a + b >>> 0;
        }
        exports.sum32 = sum32;
        function sum32_3(a, b, c) {
            return a + b + c >>> 0;
        }
        exports.sum32_3 = sum32_3;
        function sum32_4(a, b, c, d) {
            return a + b + c + d >>> 0;
        }
        exports.sum32_4 = sum32_4;
        function sum32_5(a, b, c, d, e) {
            return a + b + c + d + e >>> 0;
        }
        exports.sum32_5 = sum32_5;
        function sum64(buf, pos, ah, al) {
            var bh = buf[pos];
            var bl = buf[pos + 1];
            var lo = al + bl >>> 0;
            var hi = (lo < al ? 1 : 0) + ah + bh;
            buf[pos] = hi >>> 0;
            buf[pos + 1] = lo;
        }
        exports.sum64 = sum64;
        function sum64_hi(ah, al, bh, bl) {
            var lo = al + bl >>> 0;
            var hi = (lo < al ? 1 : 0) + ah + bh;
            return hi >>> 0;
        }
        exports.sum64_hi = sum64_hi;
        function sum64_lo(ah, al, bh, bl) {
            var lo = al + bl;
            return lo >>> 0;
        }
        exports.sum64_lo = sum64_lo;
        function sum64_4_hi(ah, al, bh, bl, ch, cl, dh, dl) {
            var carry = 0;
            var lo = al;
            lo = lo + bl >>> 0;
            carry += lo < al ? 1 : 0;
            lo = lo + cl >>> 0;
            carry += lo < cl ? 1 : 0;
            lo = lo + dl >>> 0;
            carry += lo < dl ? 1 : 0;
            var hi = ah + bh + ch + dh + carry;
            return hi >>> 0;
        }
        exports.sum64_4_hi = sum64_4_hi;
        function sum64_4_lo(ah, al, bh, bl, ch, cl, dh, dl) {
            var lo = al + bl + cl + dl;
            return lo >>> 0;
        }
        exports.sum64_4_lo = sum64_4_lo;
        function sum64_5_hi(ah, al, bh, bl, ch, cl, dh, dl, eh, el) {
            var carry = 0;
            var lo = al;
            lo = lo + bl >>> 0;
            carry += lo < al ? 1 : 0;
            lo = lo + cl >>> 0;
            carry += lo < cl ? 1 : 0;
            lo = lo + dl >>> 0;
            carry += lo < dl ? 1 : 0;
            lo = lo + el >>> 0;
            carry += lo < el ? 1 : 0;
            var hi = ah + bh + ch + dh + eh + carry;
            return hi >>> 0;
        }
        exports.sum64_5_hi = sum64_5_hi;
        function sum64_5_lo(ah, al, bh, bl, ch, cl, dh, dl, eh, el) {
            var lo = al + bl + cl + dl + el;
            return lo >>> 0;
        }
        exports.sum64_5_lo = sum64_5_lo;
        function rotr64_hi(ah, al, num) {
            var r = al << 32 - num | ah >>> num;
            return r >>> 0;
        }
        exports.rotr64_hi = rotr64_hi;
        function rotr64_lo(ah, al, num) {
            var r = ah << 32 - num | al >>> num;
            return r >>> 0;
        }
        exports.rotr64_lo = rotr64_lo;
        function shr64_hi(ah, al, num) {
            return ah >>> num;
        }
        exports.shr64_hi = shr64_hi;
        function shr64_lo(ah, al, num) {
            var r = ah << 32 - num | al >>> num;
            return r >>> 0;
        }
        exports.shr64_lo = shr64_lo;
    }
});
// ../../node_modules/hash.js/lib/hash/common.js
var require_common = __commonJS({
    "../../node_modules/hash.js/lib/hash/common.js" (exports) {
        "use strict";
        var utils = require_utils();
        var assert = require_minimalistic_assert();
        function BlockHash() {
            this.pending = null;
            this.pendingTotal = 0;
            this.blockSize = this.constructor.blockSize;
            this.outSize = this.constructor.outSize;
            this.hmacStrength = this.constructor.hmacStrength;
            this.padLength = this.constructor.padLength / 8;
            this.endian = "big";
            this._delta8 = this.blockSize / 8;
            this._delta32 = this.blockSize / 32;
        }
        exports.BlockHash = BlockHash;
        BlockHash.prototype.update = function update(msg, enc) {
            msg = utils.toArray(msg, enc);
            if (!this.pending) this.pending = msg;
            else this.pending = this.pending.concat(msg);
            this.pendingTotal += msg.length;
            if (this.pending.length >= this._delta8) {
                msg = this.pending;
                var r = msg.length % this._delta8;
                this.pending = msg.slice(msg.length - r, msg.length);
                if (this.pending.length === 0) this.pending = null;
                msg = utils.join32(msg, 0, msg.length - r, this.endian);
                for(var i = 0; i < msg.length; i += this._delta32)this._update(msg, i, i + this._delta32);
            }
            return this;
        };
        BlockHash.prototype.digest = function digest(enc) {
            this.update(this._pad());
            assert(this.pending === null);
            return this._digest(enc);
        };
        BlockHash.prototype._pad = function pad() {
            var len = this.pendingTotal;
            var bytes = this._delta8;
            var k = bytes - (len + this.padLength) % bytes;
            var res = new Array(k + this.padLength);
            res[0] = 128;
            for(var i = 1; i < k; i++)res[i] = 0;
            len <<= 3;
            if (this.endian === "big") {
                for(var t = 8; t < this.padLength; t++)res[i++] = 0;
                res[i++] = 0;
                res[i++] = 0;
                res[i++] = 0;
                res[i++] = 0;
                res[i++] = len >>> 24 & 255;
                res[i++] = len >>> 16 & 255;
                res[i++] = len >>> 8 & 255;
                res[i++] = len & 255;
            } else {
                res[i++] = len & 255;
                res[i++] = len >>> 8 & 255;
                res[i++] = len >>> 16 & 255;
                res[i++] = len >>> 24 & 255;
                res[i++] = 0;
                res[i++] = 0;
                res[i++] = 0;
                res[i++] = 0;
                for(t = 8; t < this.padLength; t++)res[i++] = 0;
            }
            return res;
        };
    }
});
// ../../node_modules/hash.js/lib/hash/sha/common.js
var require_common2 = __commonJS({
    "../../node_modules/hash.js/lib/hash/sha/common.js" (exports) {
        "use strict";
        var utils = require_utils();
        var rotr32 = utils.rotr32;
        function ft_1(s, x, y, z) {
            if (s === 0) return ch32(x, y, z);
            if (s === 1 || s === 3) return p32(x, y, z);
            if (s === 2) return maj32(x, y, z);
        }
        exports.ft_1 = ft_1;
        function ch32(x, y, z) {
            return x & y ^ ~x & z;
        }
        exports.ch32 = ch32;
        function maj32(x, y, z) {
            return x & y ^ x & z ^ y & z;
        }
        exports.maj32 = maj32;
        function p32(x, y, z) {
            return x ^ y ^ z;
        }
        exports.p32 = p32;
        function s0_256(x) {
            return rotr32(x, 2) ^ rotr32(x, 13) ^ rotr32(x, 22);
        }
        exports.s0_256 = s0_256;
        function s1_256(x) {
            return rotr32(x, 6) ^ rotr32(x, 11) ^ rotr32(x, 25);
        }
        exports.s1_256 = s1_256;
        function g0_256(x) {
            return rotr32(x, 7) ^ rotr32(x, 18) ^ x >>> 3;
        }
        exports.g0_256 = g0_256;
        function g1_256(x) {
            return rotr32(x, 17) ^ rotr32(x, 19) ^ x >>> 10;
        }
        exports.g1_256 = g1_256;
    }
});
// ../../node_modules/hash.js/lib/hash/sha/1.js
var require__ = __commonJS({
    "../../node_modules/hash.js/lib/hash/sha/1.js" (exports, module) {
        "use strict";
        var utils = require_utils();
        var common = require_common();
        var shaCommon = require_common2();
        var rotl32 = utils.rotl32;
        var sum32 = utils.sum32;
        var sum32_5 = utils.sum32_5;
        var ft_1 = shaCommon.ft_1;
        var BlockHash = common.BlockHash;
        var sha1_K = [
            1518500249,
            1859775393,
            2400959708,
            3395469782
        ];
        function SHA1() {
            if (!(this instanceof SHA1)) return new SHA1();
            BlockHash.call(this);
            this.h = [
                1732584193,
                4023233417,
                2562383102,
                271733878,
                3285377520
            ];
            this.W = new Array(80);
        }
        utils.inherits(SHA1, BlockHash);
        module.exports = SHA1;
        SHA1.blockSize = 512;
        SHA1.outSize = 160;
        SHA1.hmacStrength = 80;
        SHA1.padLength = 64;
        SHA1.prototype._update = function _update(msg, start) {
            var W = this.W;
            for(var i = 0; i < 16; i++)W[i] = msg[start + i];
            for(; i < W.length; i++)W[i] = rotl32(W[i - 3] ^ W[i - 8] ^ W[i - 14] ^ W[i - 16], 1);
            var a = this.h[0];
            var b = this.h[1];
            var c = this.h[2];
            var d = this.h[3];
            var e = this.h[4];
            for(i = 0; i < W.length; i++){
                var s = ~~(i / 20);
                var t = sum32_5(rotl32(a, 5), ft_1(s, b, c, d), e, W[i], sha1_K[s]);
                e = d;
                d = c;
                c = rotl32(b, 30);
                b = a;
                a = t;
            }
            this.h[0] = sum32(this.h[0], a);
            this.h[1] = sum32(this.h[1], b);
            this.h[2] = sum32(this.h[2], c);
            this.h[3] = sum32(this.h[3], d);
            this.h[4] = sum32(this.h[4], e);
        };
        SHA1.prototype._digest = function digest(enc) {
            if (enc === "hex") return utils.toHex32(this.h, "big");
            else return utils.split32(this.h, "big");
        };
    }
});
// ../../node_modules/hash.js/lib/hash/sha/256.js
var require__2 = __commonJS({
    "../../node_modules/hash.js/lib/hash/sha/256.js" (exports, module) {
        "use strict";
        var utils = require_utils();
        var common = require_common();
        var shaCommon = require_common2();
        var assert = require_minimalistic_assert();
        var sum32 = utils.sum32;
        var sum32_4 = utils.sum32_4;
        var sum32_5 = utils.sum32_5;
        var ch32 = shaCommon.ch32;
        var maj32 = shaCommon.maj32;
        var s0_256 = shaCommon.s0_256;
        var s1_256 = shaCommon.s1_256;
        var g0_256 = shaCommon.g0_256;
        var g1_256 = shaCommon.g1_256;
        var BlockHash = common.BlockHash;
        var sha256_K = [
            1116352408,
            1899447441,
            3049323471,
            3921009573,
            961987163,
            1508970993,
            2453635748,
            2870763221,
            3624381080,
            310598401,
            607225278,
            1426881987,
            1925078388,
            2162078206,
            2614888103,
            3248222580,
            3835390401,
            4022224774,
            264347078,
            604807628,
            770255983,
            1249150122,
            1555081692,
            1996064986,
            2554220882,
            2821834349,
            2952996808,
            3210313671,
            3336571891,
            3584528711,
            113926993,
            338241895,
            666307205,
            773529912,
            1294757372,
            1396182291,
            1695183700,
            1986661051,
            2177026350,
            2456956037,
            2730485921,
            2820302411,
            3259730800,
            3345764771,
            3516065817,
            3600352804,
            4094571909,
            275423344,
            430227734,
            506948616,
            659060556,
            883997877,
            958139571,
            1322822218,
            1537002063,
            1747873779,
            1955562222,
            2024104815,
            2227730452,
            2361852424,
            2428436474,
            2756734187,
            3204031479,
            3329325298
        ];
        function SHA256() {
            if (!(this instanceof SHA256)) return new SHA256();
            BlockHash.call(this);
            this.h = [
                1779033703,
                3144134277,
                1013904242,
                2773480762,
                1359893119,
                2600822924,
                528734635,
                1541459225
            ];
            this.k = sha256_K;
            this.W = new Array(64);
        }
        utils.inherits(SHA256, BlockHash);
        module.exports = SHA256;
        SHA256.blockSize = 512;
        SHA256.outSize = 256;
        SHA256.hmacStrength = 192;
        SHA256.padLength = 64;
        SHA256.prototype._update = function _update(msg, start) {
            var W = this.W;
            for(var i = 0; i < 16; i++)W[i] = msg[start + i];
            for(; i < W.length; i++)W[i] = sum32_4(g1_256(W[i - 2]), W[i - 7], g0_256(W[i - 15]), W[i - 16]);
            var a = this.h[0];
            var b = this.h[1];
            var c = this.h[2];
            var d = this.h[3];
            var e = this.h[4];
            var f = this.h[5];
            var g = this.h[6];
            var h = this.h[7];
            assert(this.k.length === W.length);
            for(i = 0; i < W.length; i++){
                var T1 = sum32_5(h, s1_256(e), ch32(e, f, g), this.k[i], W[i]);
                var T2 = sum32(s0_256(a), maj32(a, b, c));
                h = g;
                g = f;
                f = e;
                e = sum32(d, T1);
                d = c;
                c = b;
                b = a;
                a = sum32(T1, T2);
            }
            this.h[0] = sum32(this.h[0], a);
            this.h[1] = sum32(this.h[1], b);
            this.h[2] = sum32(this.h[2], c);
            this.h[3] = sum32(this.h[3], d);
            this.h[4] = sum32(this.h[4], e);
            this.h[5] = sum32(this.h[5], f);
            this.h[6] = sum32(this.h[6], g);
            this.h[7] = sum32(this.h[7], h);
        };
        SHA256.prototype._digest = function digest(enc) {
            if (enc === "hex") return utils.toHex32(this.h, "big");
            else return utils.split32(this.h, "big");
        };
    }
});
// ../../node_modules/hash.js/lib/hash/sha/224.js
var require__3 = __commonJS({
    "../../node_modules/hash.js/lib/hash/sha/224.js" (exports, module) {
        "use strict";
        var utils = require_utils();
        var SHA256 = require__2();
        function SHA224() {
            if (!(this instanceof SHA224)) return new SHA224();
            SHA256.call(this);
            this.h = [
                3238371032,
                914150663,
                812702999,
                4144912697,
                4290775857,
                1750603025,
                1694076839,
                3204075428
            ];
        }
        utils.inherits(SHA224, SHA256);
        module.exports = SHA224;
        SHA224.blockSize = 512;
        SHA224.outSize = 224;
        SHA224.hmacStrength = 192;
        SHA224.padLength = 64;
        SHA224.prototype._digest = function digest(enc) {
            if (enc === "hex") return utils.toHex32(this.h.slice(0, 7), "big");
            else return utils.split32(this.h.slice(0, 7), "big");
        };
    }
});
// ../../node_modules/hash.js/lib/hash/sha/512.js
var require__4 = __commonJS({
    "../../node_modules/hash.js/lib/hash/sha/512.js" (exports, module) {
        "use strict";
        var utils = require_utils();
        var common = require_common();
        var assert = require_minimalistic_assert();
        var rotr64_hi = utils.rotr64_hi;
        var rotr64_lo = utils.rotr64_lo;
        var shr64_hi = utils.shr64_hi;
        var shr64_lo = utils.shr64_lo;
        var sum64 = utils.sum64;
        var sum64_hi = utils.sum64_hi;
        var sum64_lo = utils.sum64_lo;
        var sum64_4_hi = utils.sum64_4_hi;
        var sum64_4_lo = utils.sum64_4_lo;
        var sum64_5_hi = utils.sum64_5_hi;
        var sum64_5_lo = utils.sum64_5_lo;
        var BlockHash = common.BlockHash;
        var sha512_K = [
            1116352408,
            3609767458,
            1899447441,
            602891725,
            3049323471,
            3964484399,
            3921009573,
            2173295548,
            961987163,
            4081628472,
            1508970993,
            3053834265,
            2453635748,
            2937671579,
            2870763221,
            3664609560,
            3624381080,
            2734883394,
            310598401,
            1164996542,
            607225278,
            1323610764,
            1426881987,
            3590304994,
            1925078388,
            4068182383,
            2162078206,
            991336113,
            2614888103,
            633803317,
            3248222580,
            3479774868,
            3835390401,
            2666613458,
            4022224774,
            944711139,
            264347078,
            2341262773,
            604807628,
            2007800933,
            770255983,
            1495990901,
            1249150122,
            1856431235,
            1555081692,
            3175218132,
            1996064986,
            2198950837,
            2554220882,
            3999719339,
            2821834349,
            766784016,
            2952996808,
            2566594879,
            3210313671,
            3203337956,
            3336571891,
            1034457026,
            3584528711,
            2466948901,
            113926993,
            3758326383,
            338241895,
            168717936,
            666307205,
            1188179964,
            773529912,
            1546045734,
            1294757372,
            1522805485,
            1396182291,
            2643833823,
            1695183700,
            2343527390,
            1986661051,
            1014477480,
            2177026350,
            1206759142,
            2456956037,
            344077627,
            2730485921,
            1290863460,
            2820302411,
            3158454273,
            3259730800,
            3505952657,
            3345764771,
            106217008,
            3516065817,
            3606008344,
            3600352804,
            1432725776,
            4094571909,
            1467031594,
            275423344,
            851169720,
            430227734,
            3100823752,
            506948616,
            1363258195,
            659060556,
            3750685593,
            883997877,
            3785050280,
            958139571,
            3318307427,
            1322822218,
            3812723403,
            1537002063,
            2003034995,
            1747873779,
            3602036899,
            1955562222,
            1575990012,
            2024104815,
            1125592928,
            2227730452,
            2716904306,
            2361852424,
            442776044,
            2428436474,
            593698344,
            2756734187,
            3733110249,
            3204031479,
            2999351573,
            3329325298,
            3815920427,
            3391569614,
            3928383900,
            3515267271,
            566280711,
            3940187606,
            3454069534,
            4118630271,
            4000239992,
            116418474,
            1914138554,
            174292421,
            2731055270,
            289380356,
            3203993006,
            460393269,
            320620315,
            685471733,
            587496836,
            852142971,
            1086792851,
            1017036298,
            365543100,
            1126000580,
            2618297676,
            1288033470,
            3409855158,
            1501505948,
            4234509866,
            1607167915,
            987167468,
            1816402316,
            1246189591
        ];
        function SHA512() {
            if (!(this instanceof SHA512)) return new SHA512();
            BlockHash.call(this);
            this.h = [
                1779033703,
                4089235720,
                3144134277,
                2227873595,
                1013904242,
                4271175723,
                2773480762,
                1595750129,
                1359893119,
                2917565137,
                2600822924,
                725511199,
                528734635,
                4215389547,
                1541459225,
                327033209
            ];
            this.k = sha512_K;
            this.W = new Array(160);
        }
        utils.inherits(SHA512, BlockHash);
        module.exports = SHA512;
        SHA512.blockSize = 1024;
        SHA512.outSize = 512;
        SHA512.hmacStrength = 192;
        SHA512.padLength = 128;
        SHA512.prototype._prepareBlock = function _prepareBlock(msg, start) {
            var W = this.W;
            for(var i = 0; i < 32; i++)W[i] = msg[start + i];
            for(; i < W.length; i += 2){
                var c0_hi = g1_512_hi(W[i - 4], W[i - 3]);
                var c0_lo = g1_512_lo(W[i - 4], W[i - 3]);
                var c1_hi = W[i - 14];
                var c1_lo = W[i - 13];
                var c2_hi = g0_512_hi(W[i - 30], W[i - 29]);
                var c2_lo = g0_512_lo(W[i - 30], W[i - 29]);
                var c3_hi = W[i - 32];
                var c3_lo = W[i - 31];
                W[i] = sum64_4_hi(c0_hi, c0_lo, c1_hi, c1_lo, c2_hi, c2_lo, c3_hi, c3_lo);
                W[i + 1] = sum64_4_lo(c0_hi, c0_lo, c1_hi, c1_lo, c2_hi, c2_lo, c3_hi, c3_lo);
            }
        };
        SHA512.prototype._update = function _update(msg, start) {
            this._prepareBlock(msg, start);
            var W = this.W;
            var ah = this.h[0];
            var al = this.h[1];
            var bh = this.h[2];
            var bl = this.h[3];
            var ch = this.h[4];
            var cl = this.h[5];
            var dh = this.h[6];
            var dl = this.h[7];
            var eh = this.h[8];
            var el = this.h[9];
            var fh = this.h[10];
            var fl = this.h[11];
            var gh = this.h[12];
            var gl = this.h[13];
            var hh = this.h[14];
            var hl = this.h[15];
            assert(this.k.length === W.length);
            for(var i = 0; i < W.length; i += 2){
                var c0_hi = hh;
                var c0_lo = hl;
                var c1_hi = s1_512_hi(eh, el);
                var c1_lo = s1_512_lo(eh, el);
                var c2_hi = ch64_hi(eh, el, fh, fl, gh, gl);
                var c2_lo = ch64_lo(eh, el, fh, fl, gh, gl);
                var c3_hi = this.k[i];
                var c3_lo = this.k[i + 1];
                var c4_hi = W[i];
                var c4_lo = W[i + 1];
                var T1_hi = sum64_5_hi(c0_hi, c0_lo, c1_hi, c1_lo, c2_hi, c2_lo, c3_hi, c3_lo, c4_hi, c4_lo);
                var T1_lo = sum64_5_lo(c0_hi, c0_lo, c1_hi, c1_lo, c2_hi, c2_lo, c3_hi, c3_lo, c4_hi, c4_lo);
                c0_hi = s0_512_hi(ah, al);
                c0_lo = s0_512_lo(ah, al);
                c1_hi = maj64_hi(ah, al, bh, bl, ch, cl);
                c1_lo = maj64_lo(ah, al, bh, bl, ch, cl);
                var T2_hi = sum64_hi(c0_hi, c0_lo, c1_hi, c1_lo);
                var T2_lo = sum64_lo(c0_hi, c0_lo, c1_hi, c1_lo);
                hh = gh;
                hl = gl;
                gh = fh;
                gl = fl;
                fh = eh;
                fl = el;
                eh = sum64_hi(dh, dl, T1_hi, T1_lo);
                el = sum64_lo(dl, dl, T1_hi, T1_lo);
                dh = ch;
                dl = cl;
                ch = bh;
                cl = bl;
                bh = ah;
                bl = al;
                ah = sum64_hi(T1_hi, T1_lo, T2_hi, T2_lo);
                al = sum64_lo(T1_hi, T1_lo, T2_hi, T2_lo);
            }
            sum64(this.h, 0, ah, al);
            sum64(this.h, 2, bh, bl);
            sum64(this.h, 4, ch, cl);
            sum64(this.h, 6, dh, dl);
            sum64(this.h, 8, eh, el);
            sum64(this.h, 10, fh, fl);
            sum64(this.h, 12, gh, gl);
            sum64(this.h, 14, hh, hl);
        };
        SHA512.prototype._digest = function digest(enc) {
            if (enc === "hex") return utils.toHex32(this.h, "big");
            else return utils.split32(this.h, "big");
        };
        function ch64_hi(xh, xl, yh, yl, zh) {
            var r = xh & yh ^ ~xh & zh;
            if (r < 0) r += 4294967296;
            return r;
        }
        function ch64_lo(xh, xl, yh, yl, zh, zl) {
            var r = xl & yl ^ ~xl & zl;
            if (r < 0) r += 4294967296;
            return r;
        }
        function maj64_hi(xh, xl, yh, yl, zh) {
            var r = xh & yh ^ xh & zh ^ yh & zh;
            if (r < 0) r += 4294967296;
            return r;
        }
        function maj64_lo(xh, xl, yh, yl, zh, zl) {
            var r = xl & yl ^ xl & zl ^ yl & zl;
            if (r < 0) r += 4294967296;
            return r;
        }
        function s0_512_hi(xh, xl) {
            var c0_hi = rotr64_hi(xh, xl, 28);
            var c1_hi = rotr64_hi(xl, xh, 2);
            var c2_hi = rotr64_hi(xl, xh, 7);
            var r = c0_hi ^ c1_hi ^ c2_hi;
            if (r < 0) r += 4294967296;
            return r;
        }
        function s0_512_lo(xh, xl) {
            var c0_lo = rotr64_lo(xh, xl, 28);
            var c1_lo = rotr64_lo(xl, xh, 2);
            var c2_lo = rotr64_lo(xl, xh, 7);
            var r = c0_lo ^ c1_lo ^ c2_lo;
            if (r < 0) r += 4294967296;
            return r;
        }
        function s1_512_hi(xh, xl) {
            var c0_hi = rotr64_hi(xh, xl, 14);
            var c1_hi = rotr64_hi(xh, xl, 18);
            var c2_hi = rotr64_hi(xl, xh, 9);
            var r = c0_hi ^ c1_hi ^ c2_hi;
            if (r < 0) r += 4294967296;
            return r;
        }
        function s1_512_lo(xh, xl) {
            var c0_lo = rotr64_lo(xh, xl, 14);
            var c1_lo = rotr64_lo(xh, xl, 18);
            var c2_lo = rotr64_lo(xl, xh, 9);
            var r = c0_lo ^ c1_lo ^ c2_lo;
            if (r < 0) r += 4294967296;
            return r;
        }
        function g0_512_hi(xh, xl) {
            var c0_hi = rotr64_hi(xh, xl, 1);
            var c1_hi = rotr64_hi(xh, xl, 8);
            var c2_hi = shr64_hi(xh, xl, 7);
            var r = c0_hi ^ c1_hi ^ c2_hi;
            if (r < 0) r += 4294967296;
            return r;
        }
        function g0_512_lo(xh, xl) {
            var c0_lo = rotr64_lo(xh, xl, 1);
            var c1_lo = rotr64_lo(xh, xl, 8);
            var c2_lo = shr64_lo(xh, xl, 7);
            var r = c0_lo ^ c1_lo ^ c2_lo;
            if (r < 0) r += 4294967296;
            return r;
        }
        function g1_512_hi(xh, xl) {
            var c0_hi = rotr64_hi(xh, xl, 19);
            var c1_hi = rotr64_hi(xl, xh, 29);
            var c2_hi = shr64_hi(xh, xl, 6);
            var r = c0_hi ^ c1_hi ^ c2_hi;
            if (r < 0) r += 4294967296;
            return r;
        }
        function g1_512_lo(xh, xl) {
            var c0_lo = rotr64_lo(xh, xl, 19);
            var c1_lo = rotr64_lo(xl, xh, 29);
            var c2_lo = shr64_lo(xh, xl, 6);
            var r = c0_lo ^ c1_lo ^ c2_lo;
            if (r < 0) r += 4294967296;
            return r;
        }
    }
});
// ../../node_modules/hash.js/lib/hash/sha/384.js
var require__5 = __commonJS({
    "../../node_modules/hash.js/lib/hash/sha/384.js" (exports, module) {
        "use strict";
        var utils = require_utils();
        var SHA512 = require__4();
        function SHA384() {
            if (!(this instanceof SHA384)) return new SHA384();
            SHA512.call(this);
            this.h = [
                3418070365,
                3238371032,
                1654270250,
                914150663,
                2438529370,
                812702999,
                355462360,
                4144912697,
                1731405415,
                4290775857,
                2394180231,
                1750603025,
                3675008525,
                1694076839,
                1203062813,
                3204075428
            ];
        }
        utils.inherits(SHA384, SHA512);
        module.exports = SHA384;
        SHA384.blockSize = 1024;
        SHA384.outSize = 384;
        SHA384.hmacStrength = 192;
        SHA384.padLength = 128;
        SHA384.prototype._digest = function digest(enc) {
            if (enc === "hex") return utils.toHex32(this.h.slice(0, 12), "big");
            else return utils.split32(this.h.slice(0, 12), "big");
        };
    }
});
// ../../node_modules/hash.js/lib/hash/sha.js
var require_sha = __commonJS({
    "../../node_modules/hash.js/lib/hash/sha.js" (exports) {
        "use strict";
        exports.sha1 = require__();
        exports.sha224 = require__3();
        exports.sha256 = require__2();
        exports.sha384 = require__5();
        exports.sha512 = require__4();
    }
});
// ../../node_modules/hash.js/lib/hash/ripemd.js
var require_ripemd = __commonJS({
    "../../node_modules/hash.js/lib/hash/ripemd.js" (exports) {
        "use strict";
        var utils = require_utils();
        var common = require_common();
        var rotl32 = utils.rotl32;
        var sum32 = utils.sum32;
        var sum32_3 = utils.sum32_3;
        var sum32_4 = utils.sum32_4;
        var BlockHash = common.BlockHash;
        function RIPEMD160() {
            if (!(this instanceof RIPEMD160)) return new RIPEMD160();
            BlockHash.call(this);
            this.h = [
                1732584193,
                4023233417,
                2562383102,
                271733878,
                3285377520
            ];
            this.endian = "little";
        }
        utils.inherits(RIPEMD160, BlockHash);
        exports.ripemd160 = RIPEMD160;
        RIPEMD160.blockSize = 512;
        RIPEMD160.outSize = 160;
        RIPEMD160.hmacStrength = 192;
        RIPEMD160.padLength = 64;
        RIPEMD160.prototype._update = function update(msg, start) {
            var A = this.h[0];
            var B = this.h[1];
            var C = this.h[2];
            var D = this.h[3];
            var E = this.h[4];
            var Ah = A;
            var Bh = B;
            var Ch = C;
            var Dh = D;
            var Eh = E;
            for(var j = 0; j < 80; j++){
                var T = sum32(rotl32(sum32_4(A, f(j, B, C, D), msg[r[j] + start], K(j)), s[j]), E);
                A = E;
                E = D;
                D = rotl32(C, 10);
                C = B;
                B = T;
                T = sum32(rotl32(sum32_4(Ah, f(79 - j, Bh, Ch, Dh), msg[rh[j] + start], Kh(j)), sh[j]), Eh);
                Ah = Eh;
                Eh = Dh;
                Dh = rotl32(Ch, 10);
                Ch = Bh;
                Bh = T;
            }
            T = sum32_3(this.h[1], C, Dh);
            this.h[1] = sum32_3(this.h[2], D, Eh);
            this.h[2] = sum32_3(this.h[3], E, Ah);
            this.h[3] = sum32_3(this.h[4], A, Bh);
            this.h[4] = sum32_3(this.h[0], B, Ch);
            this.h[0] = T;
        };
        RIPEMD160.prototype._digest = function digest(enc) {
            if (enc === "hex") return utils.toHex32(this.h, "little");
            else return utils.split32(this.h, "little");
        };
        function f(j, x, y, z) {
            if (j <= 15) return x ^ y ^ z;
            else if (j <= 31) return x & y | ~x & z;
            else if (j <= 47) return (x | ~y) ^ z;
            else if (j <= 63) return x & z | y & ~z;
            else return x ^ (y | ~z);
        }
        function K(j) {
            if (j <= 15) return 0;
            else if (j <= 31) return 1518500249;
            else if (j <= 47) return 1859775393;
            else if (j <= 63) return 2400959708;
            else return 2840853838;
        }
        function Kh(j) {
            if (j <= 15) return 1352829926;
            else if (j <= 31) return 1548603684;
            else if (j <= 47) return 1836072691;
            else if (j <= 63) return 2053994217;
            else return 0;
        }
        var r = [
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8,
            9,
            10,
            11,
            12,
            13,
            14,
            15,
            7,
            4,
            13,
            1,
            10,
            6,
            15,
            3,
            12,
            0,
            9,
            5,
            2,
            14,
            11,
            8,
            3,
            10,
            14,
            4,
            9,
            15,
            8,
            1,
            2,
            7,
            0,
            6,
            13,
            11,
            5,
            12,
            1,
            9,
            11,
            10,
            0,
            8,
            12,
            4,
            13,
            3,
            7,
            15,
            14,
            5,
            6,
            2,
            4,
            0,
            5,
            9,
            7,
            12,
            2,
            10,
            14,
            1,
            3,
            8,
            11,
            6,
            15,
            13
        ];
        var rh = [
            5,
            14,
            7,
            0,
            9,
            2,
            11,
            4,
            13,
            6,
            15,
            8,
            1,
            10,
            3,
            12,
            6,
            11,
            3,
            7,
            0,
            13,
            5,
            10,
            14,
            15,
            8,
            12,
            4,
            9,
            1,
            2,
            15,
            5,
            1,
            3,
            7,
            14,
            6,
            9,
            11,
            8,
            12,
            2,
            10,
            0,
            4,
            13,
            8,
            6,
            4,
            1,
            3,
            11,
            15,
            0,
            5,
            12,
            2,
            13,
            9,
            7,
            10,
            14,
            12,
            15,
            10,
            4,
            1,
            5,
            8,
            7,
            6,
            2,
            13,
            14,
            0,
            3,
            9,
            11
        ];
        var s = [
            11,
            14,
            15,
            12,
            5,
            8,
            7,
            9,
            11,
            13,
            14,
            15,
            6,
            7,
            9,
            8,
            7,
            6,
            8,
            13,
            11,
            9,
            7,
            15,
            7,
            12,
            15,
            9,
            11,
            7,
            13,
            12,
            11,
            13,
            6,
            7,
            14,
            9,
            13,
            15,
            14,
            8,
            13,
            6,
            5,
            12,
            7,
            5,
            11,
            12,
            14,
            15,
            14,
            15,
            9,
            8,
            9,
            14,
            5,
            6,
            8,
            6,
            5,
            12,
            9,
            15,
            5,
            11,
            6,
            8,
            13,
            12,
            5,
            12,
            13,
            14,
            11,
            8,
            5,
            6
        ];
        var sh = [
            8,
            9,
            9,
            11,
            13,
            15,
            15,
            5,
            7,
            7,
            8,
            11,
            14,
            14,
            12,
            6,
            9,
            13,
            15,
            7,
            12,
            8,
            9,
            11,
            7,
            7,
            12,
            7,
            6,
            15,
            13,
            11,
            9,
            7,
            15,
            11,
            8,
            6,
            6,
            14,
            12,
            13,
            5,
            14,
            13,
            13,
            7,
            5,
            15,
            5,
            8,
            11,
            14,
            14,
            6,
            14,
            6,
            9,
            12,
            9,
            12,
            5,
            15,
            8,
            8,
            5,
            12,
            9,
            12,
            5,
            14,
            6,
            8,
            13,
            6,
            5,
            15,
            13,
            11,
            11
        ];
    }
});
// ../../node_modules/hash.js/lib/hash/hmac.js
var require_hmac = __commonJS({
    "../../node_modules/hash.js/lib/hash/hmac.js" (exports, module) {
        "use strict";
        var utils = require_utils();
        var assert = require_minimalistic_assert();
        function Hmac(hash2, key, enc) {
            if (!(this instanceof Hmac)) return new Hmac(hash2, key, enc);
            this.Hash = hash2;
            this.blockSize = hash2.blockSize / 8;
            this.outSize = hash2.outSize / 8;
            this.inner = null;
            this.outer = null;
            this._init(utils.toArray(key, enc));
        }
        module.exports = Hmac;
        Hmac.prototype._init = function init(key) {
            if (key.length > this.blockSize) key = new this.Hash().update(key).digest();
            assert(key.length <= this.blockSize);
            for(var i = key.length; i < this.blockSize; i++)key.push(0);
            for(i = 0; i < key.length; i++)key[i] ^= 54;
            this.inner = new this.Hash().update(key);
            for(i = 0; i < key.length; i++)key[i] ^= 106;
            this.outer = new this.Hash().update(key);
        };
        Hmac.prototype.update = function update(msg, enc) {
            this.inner.update(msg, enc);
            return this;
        };
        Hmac.prototype.digest = function digest(enc) {
            this.outer.update(this.inner.digest());
            return this.outer.digest(enc);
        };
    }
});
// ../../node_modules/hash.js/lib/hash.js
var require_hash = __commonJS({
    "../../node_modules/hash.js/lib/hash.js" (exports) {
        "use strict";
        var hash2 = exports;
        hash2.utils = require_utils();
        hash2.common = require_common();
        hash2.sha = require_sha();
        hash2.ripemd = require_ripemd();
        hash2.hmac = require_hmac();
        hash2.sha1 = hash2.sha.sha1;
        hash2.sha256 = hash2.sha.sha256;
        hash2.sha224 = hash2.sha.sha224;
        hash2.sha384 = hash2.sha.sha384;
        hash2.sha512 = hash2.sha.sha512;
        hash2.ripemd160 = hash2.ripemd.ripemd160;
    }
});
;
;
;
;
var Slot = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Slot;
var Value = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Value;
var Transaction = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Transaction;
var TransactionId = (value)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].TransactionId(value);
};
var TransactionBody = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TransactionBody;
var TransactionWitnessSet = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TransactionWitnessSet;
var AuxilliaryData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].AuxiliaryData;
var TransactionMetadatum = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TransactionMetadatum;
var MetadatumMap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].MetadatumMap;
var MetadatumList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].MetadatumList;
var TransactionUnspentOutput = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TransactionUnspentOutput;
var TransactionInput = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TransactionInput;
var TransactionOutput = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TransactionOutput;
var PlutusData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PlutusData;
var PlutusList = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PlutusList;
var PlutusMap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PlutusMap;
var Redeemers = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Redeemers;
var Redeemer = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Redeemer;
var RedeemerPurpose = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RedeemerPurpose;
var RedeemerTag = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].RedeemerTag;
var Script = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Script;
var PolicyId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].PolicyId;
var AssetName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].AssetName;
var AssetId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].AssetId;
var ScriptHash = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Hash28ByteBase16"];
var Address = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address;
var RewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress;
var AddressType = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].AddressType;
var BaseAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].BaseAddress;
var EnterpriseAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].EnterpriseAddress;
var PaymentAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].PaymentAddress;
var AssetFingerprint = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].AssetFingerprint;
var Credential = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Credential;
var Ed25519PublicKeyHex2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Ed25519PublicKeyHex"];
var Ed25519PrivateNormalKeyHex = (value)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["typedHex"])(value, 64);
var Ed25519PrivateExtendedKeyHex = (value)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["typedHex"])(value, 128);
var Ed25519KeyHash2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Ed25519e$2f$Ed25519KeyHash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Ed25519KeyHash"];
var Ed25519KeyHashHex2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Ed25519KeyHashHex"];
var Hash28ByteBase162 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Hash28ByteBase16"];
var Hash32ByteBase162 = (value)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Hash32ByteBase16"](value);
};
var CredentialType = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].CredentialType;
var Certificate = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Certificate;
var PoolId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].PoolId;
var StakeRegistration = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeRegistration;
var StakeDelegation = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeDelegation;
var CertificateType = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].CertificateType;
var VkeyWitness = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].VkeyWitness;
var Ed25519SignatureHex2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Ed25519SignatureHex"];
var Ed25519PublicKey2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Ed25519e$2f$Ed25519PublicKey$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Ed25519PublicKey"];
var Ed25519Signature2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Ed25519e$2f$Ed25519Signature$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Ed25519Signature"];
var Bip32PrivateKey2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Bip32$2f$Bip32PrivateKey$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bip32PrivateKey"];
var Bip32PrivateKeyHex2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bip32PrivateKeyHex"];
var Bip32PublicKey2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Bip32$2f$Bip32PublicKey$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bip32PublicKey"];
var Bip32PublicKeyHex2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Bip32PublicKeyHex"];
var PlutusLanguageVersion = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].PlutusLanguageVersion;
var NativeScript = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].NativeScript;
var PlutusV1Script = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PlutusV1Script;
var PlutusV2Script = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PlutusV2Script;
var PlutusV3Script = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PlutusV3Script;
var PlutusDataKind = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PlutusDataKind;
var PointerAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].PointerAddress;
var CertIndex = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].CertIndex;
var TxIndex = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].TxIndex;
var Costmdls = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Costmdls;
var CostModel = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CostModel;
var CborWriter = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborWriter;
var ConstrPlutusData = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].ConstrPlutusData;
var RewardAccount = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAccount;
var Hash = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Hash;
var DatumHash = (value)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Hash32ByteBase16"](value);
};
var Datum = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Datum;
var ExUnits = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].ExUnits;
var NetworkId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].NetworkId;
var DatumKind = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DatumKind;
var CborSet = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet;
var RequireAllOf = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].NativeScriptKind.RequireAllOf;
var RequireAnyOf = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].NativeScriptKind.RequireAnyOf;
var RequireNOf = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].NativeScriptKind.RequireNOf;
var RequireSignature = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].NativeScriptKind.RequireSignature;
var RequireTimeAfter = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].NativeScriptKind.RequireTimeAfter;
var RequireTimeBefore = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].NativeScriptKind.RequireTimeBefore;
var VrfVkBech32 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].VrfVkBech32;
var ScriptPubkey = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].ScriptPubkey;
var DRepID = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].DRepID;
var DRep = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep;
var StakeCredentialStatus = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].StakeCredentialStatus;
var HexBlob = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"];
var TxCBOR = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TxCBOR;
var Ed25519PrivateKey2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Ed25519e$2f$Ed25519PrivateKey$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Ed25519PrivateKey"];
var computeAuxiliaryDataHash = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].computeAuxiliaryDataHash;
var blake2b2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blake2b$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__blake2b$3e$__["blake2b"];
var BootstrapWitness = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].BootstrapWitness;
;
;
// src/message-signing/cose-sign1.ts
var import_json_bigint = __toESM(require_json_bigint(), 1);
;
;
;
var CoseSign1 = class _CoseSign1 {
    protectedMap;
    unProtectedMap;
    payload;
    signature;
    constructor(payload){
        this.protectedMap = payload.protectedMap;
        this.unProtectedMap = payload.unProtectedMap;
        this.payload = payload.payload;
        if (!this.unProtectedMap.map.find((value)=>{
            return import_json_bigint.default.stringify(value.k) === import_json_bigint.default.stringify(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborText"]("hashed"));
        })) {
            this.unProtectedMap.map.push({
                k: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborText"]("hashed"),
                v: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborSimple"](false)
            });
        }
        this.signature = payload.signature;
    }
    static fromCbor(cbor) {
        const decoded = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].parse(cbor);
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isRawCborArray"])(decoded.toRawObj())) throw Error("Invalid CBOR");
        if (decoded.array.length !== 4) throw Error("Invalid COSE_SIGN1");
        let protectedMap;
        const protectedSerialized = decoded.array[0];
        try {
            protectedMap = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].parse(protectedSerialized.bytes);
            if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isRawCborMap"])(protectedMap.toRawObj())) {
                throw Error();
            }
        } catch (error) {
            throw Error("Invalid protected");
        }
        let unProtectedMap = decoded.array[1];
        if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isRawCborMap"])(unProtectedMap.toRawObj())) throw Error("Invalid unprotected");
        const payload = decoded.array[2];
        const signature = decoded.array[3];
        return new _CoseSign1({
            protectedMap,
            unProtectedMap,
            payload,
            signature
        });
    }
    createSigStructure(externalAad = __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].alloc(0)) {
        let protectedSerialized = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](__TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].alloc(0));
        if (this.protectedMap.map.length !== 0) {
            protectedSerialized = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(this.protectedMap).toBuffer());
        }
        if (!this.payload) throw Error("Invalid payload");
        const structure = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborArray"]([
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborText"]("Signature1"),
            protectedSerialized,
            new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](externalAad),
            this.payload
        ]);
        return __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(structure).toBuffer());
    }
    buildMessage(signature) {
        this.signature = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](signature);
        let protectedSerialized = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](__TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].alloc(0));
        if (this.protectedMap.map.length !== 0) {
            protectedSerialized = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(this.protectedMap).toBuffer());
        }
        if (!this.payload) throw Error("Invalid payload");
        const coseSign1 = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborArray"]([
            protectedSerialized,
            this.unProtectedMap,
            this.payload,
            this.signature
        ]);
        return __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(coseSign1).toBuffer());
    }
    verifySignature({ externalAad = __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].alloc(0), publicKeyBuffer } = {}) {
        if (!publicKeyBuffer) {
            publicKeyBuffer = this.getPublicKey();
        }
        if (!publicKeyBuffer) throw Error("Public key not found");
        if (!this.signature) throw Error("Signature not found");
        const publicKey = new Ed25519PublicKey2(publicKeyBuffer);
        return publicKey.verify(new Ed25519Signature2(this.signature.bytes), HexBlob(__TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(this.createSigStructure(externalAad)).toString("hex")));
    }
    hashPayload() {
        if (!this.unProtectedMap) throw Error("Invalid unprotected map");
        if (!this.payload) throw Error("Invalid payload");
        const hashedIndex = this.unProtectedMap.map.findIndex((value)=>{
            return import_json_bigint.default.stringify(value.k) === import_json_bigint.default.stringify(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborText"]("hashed"));
        });
        const hashed = this.unProtectedMap.map[hashedIndex];
        if (hashed && import_json_bigint.default.stringify(hashed.v) === import_json_bigint.default.stringify(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborSimple"](true))) throw Error("Payload already hashed");
        if (hashed && import_json_bigint.default.stringify(hashed.v) === import_json_bigint.default.stringify(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborSimple"](true)) != false) throw Error("Invalid unprotected map");
        this.unProtectedMap.map.splice(hashedIndex, 1);
        const hash2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blakejs$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["blake2b"])(this.payload.bytes, void 0, 24);
        this.payload = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](hash2);
    }
    getAddress() {
        const address = this.protectedMap.map.find((value)=>{
            return import_json_bigint.default.stringify(value.k) === import_json_bigint.default.stringify(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborText"]("address"));
        });
        if (!address) throw Error("Address not found");
        return __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(address.v.bytes);
    }
    getPublicKey() {
        const publicKey = this.protectedMap.map.find((value)=>{
            return import_json_bigint.default.stringify(value.k) === import_json_bigint.default.stringify(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborUInt"](4));
        });
        if (!publicKey) throw Error("Public key not found");
        return __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(publicKey.v.bytes);
    }
    getSignature() {
        return this.signature ? __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(this.signature.bytes) : this.signature;
    }
    getPayload() {
        return this.payload ? __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(this.payload.bytes) : this.payload;
    }
};
var getPublicKeyFromCoseKey = (cbor)=>{
    const decodedCoseKey = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].parse(cbor);
    const publicKeyEntry = decodedCoseKey.map.find((value)=>{
        return import_json_bigint.default.stringify(value.k) === import_json_bigint.default.stringify(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborNegInt"](BigInt(-2)));
    });
    if (publicKeyEntry) {
        return __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(publicKeyEntry.v.bytes);
    }
    throw Error("Public key not found");
};
var getCoseKeyFromPublicKey = (cbor)=>{
    const coseKeyMap = [];
    coseKeyMap.push({
        k: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborUInt"](1),
        v: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborUInt"](1)
    });
    coseKeyMap.push({
        k: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborUInt"](3),
        v: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborNegInt"](-8)
    });
    coseKeyMap.push({
        k: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborUInt"](6),
        v: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborNegInt"](-2)
    });
    coseKeyMap.push({
        k: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborNegInt"](-2),
        v: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](__TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(cbor, "hex"))
    });
    return __TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborMap"](coseKeyMap)).toBuffer());
};
// src/message-signing/check-signature.ts
var checkSignature = async (data, { key, signature }, address)=>{
    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ready"])();
    const builder = CoseSign1.fromCbor(signature);
    const publicKeyBuffer = getPublicKeyFromCoseKey(key);
    if (address) {
        let network = NetworkId.Mainnet;
        const paymentAddress = BaseAddress.fromAddress(Address.fromBech32(address));
        const coseSign1PublicKey = Ed25519PublicKey2.fromBytes(publicKeyBuffer);
        const credential = {
            hash: Hash28ByteBase162.fromEd25519KeyHashHex(coseSign1PublicKey.hash().hex()),
            type: 0
        };
        if (address.startsWith("addr")) {
            if (address.startsWith("addr_test1")) {
                network = NetworkId.Testnet;
            }
            const stakeCredential = paymentAddress?.getStakeCredential();
            if (stakeCredential) {
                const paymentAddressBech32 = BaseAddress.fromCredentials(network, credential, stakeCredential).toAddress().toBech32();
                if (address !== paymentAddressBech32) {
                    const extractedRewardAddress = RewardAddress.fromCredentials(network, stakeCredential).toAddress().toBech32();
                    const rewardAddress = RewardAddress.fromCredentials(network, credential).toAddress().toBech32();
                    if (rewardAddress !== extractedRewardAddress) {
                        return false;
                    }
                }
            } else {
                const enterpriseAddress = EnterpriseAddress.fromCredentials(network, credential).toAddress().toBech32();
                if (enterpriseAddress !== address) {
                    return false;
                }
            }
        } else if (address.startsWith("stake")) {
            if (address.startsWith("stake_test1")) {
                network = NetworkId.Testnet;
            }
            const rewardAddress = RewardAddress.fromCredentials(network, credential).toAddress().toBech32();
            if (rewardAddress !== address) {
                return false;
            }
        } else {
            return false;
        }
    }
    if (builder.getPayload() === null) {
        return false;
    }
    const hexData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isHexString"])(data) ? data : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["stringToHex"])(data);
    if (Buffer.from(hexData, "hex").compare(builder.getPayload()) !== 0) {
        return false;
    }
    return builder.verifySignature({
        publicKeyBuffer
    });
};
;
var POOL_SIZE_MULTIPLIER = 128;
var pool;
var poolOffset;
var fillPool = (bytes)=>{
    if (!pool || pool.length < bytes) {
        pool = Buffer.allocUnsafe(bytes * POOL_SIZE_MULTIPLIER);
        __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["default"].randomFillSync(pool);
        poolOffset = 0;
    } else if (poolOffset + bytes > pool.length) {
        __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["default"].randomFillSync(pool);
        poolOffset = 0;
    }
    poolOffset += bytes;
};
var random = (bytes)=>{
    fillPool(bytes |= 0);
    return pool.subarray(poolOffset - bytes, poolOffset);
};
var customRandom = (alphabet, defaultSize, getRandom)=>{
    let mask = (2 << 31 - Math.clz32(alphabet.length - 1 | 1)) - 1;
    let step = Math.ceil(1.6 * mask * defaultSize / alphabet.length);
    return (size = defaultSize)=>{
        let id = "";
        while(true){
            let bytes = getRandom(step);
            let i = step;
            while(i--){
                id += alphabet[bytes[i] & mask] || "";
                if (id.length === size) return id;
            }
        }
    };
};
var customAlphabet = (alphabet, size = 21)=>customRandom(alphabet, size, random);
;
var generateNonce = (label = "", length = 32)=>{
    if (length <= 0 || length > 2048) {
        throw new Error("Length must be bewteen 1 and 2048");
    }
    const randomString = customAlphabet("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789");
    const payload = randomString(length);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["stringToHex"])(`${label}${payload}`);
};
;
;
var signData = (data, signer)=>{
    const hexData = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isHexString"])(data) ? data : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["stringToHex"])(data);
    const payload = Buffer.from(hexData, "hex");
    const publicKey = Buffer.from(signer.key.toPublic().bytes());
    const protectedMap = [];
    protectedMap.push({
        k: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborUInt"](1),
        v: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborNegInt"](-8)
    });
    protectedMap.push({
        k: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborUInt"](4),
        v: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](publicKey)
    });
    protectedMap.push({
        k: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborText"]("address"),
        v: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](Buffer.from(signer.address.toBytes(), "hex"))
    });
    const coseSign1Builder = new CoseSign1({
        protectedMap: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborMap"](protectedMap),
        unProtectedMap: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborMap"]([]),
        payload: new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](payload)
    });
    const signature = signer.key.sign(HexBlob(Buffer.from(coseSign1Builder.createSigStructure()).toString("hex")));
    const coseSignature = coseSign1Builder.buildMessage(Buffer.from(signature.bytes())).toString("hex");
    return {
        key: getCoseKeyFromPublicKey(publicKey.toString("hex")).toString("hex"),
        signature: coseSignature
    };
};
;
;
;
;
;
;
// src/utils/builder.ts
var import_hash = __toESM(require_hash(), 1);
;
;
;
;
var buildBaseAddress = (networkId, paymentKeyHash, stakeKeyHash)=>{
    return BaseAddress.fromCredentials(networkId, {
        hash: paymentKeyHash,
        type: CredentialType.KeyHash
    }, {
        hash: stakeKeyHash,
        type: CredentialType.KeyHash
    });
};
var buildEnterpriseAddress = (networkId, paymentKeyHash)=>{
    return EnterpriseAddress.fromCredentials(networkId, {
        hash: paymentKeyHash,
        type: CredentialType.KeyHash
    });
};
var clampScalar = (scalar)=>{
    if (scalar[0] !== void 0) {
        scalar[0] &= 248;
    }
    if (scalar[31] !== void 0) {
        scalar[31] &= 31;
        scalar[31] |= 64;
    }
    return scalar;
};
var buildBip32PrivateKey = (entropy, password = "")=>{
    const PBKDF2_ITERATIONS = 4096;
    const PBKDF2_KEY_SIZE = 96;
    const PBKDF2_DIGEST_ALGORITHM = "sha512";
    const _entropy = Buffer.from(entropy, "hex");
    const xprv = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["pbkdf2Sync"])(password, _entropy, PBKDF2_ITERATIONS, PBKDF2_KEY_SIZE, PBKDF2_DIGEST_ALGORITHM);
    return Bip32PrivateKey2.fromBytes(clampScalar(xprv));
};
var buildRewardAddress = (networkId, stakeKeyHash)=>{
    const cred = {
        type: CredentialType.KeyHash,
        hash: stakeKeyHash
    };
    return RewardAddress.fromCredentials(networkId, cred);
};
var buildKeys = (privateKeyHex, accountIndex, keyIndex = 0)=>{
    if (typeof privateKeyHex === "string") {
        const privateKey = Bip32PrivateKey2.fromHex(Bip32PrivateKeyHex2(privateKeyHex));
        const accountKey = privateKey.derive([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HARDENED_KEY_START"] + 1852,
            // purpose
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HARDENED_KEY_START"] + 1815,
            // coin type
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HARDENED_KEY_START"] + accountIndex
        ]);
        const paymentKey = accountKey.derive([
            0,
            keyIndex
        ]).toRawKey();
        const stakeKey = accountKey.derive([
            2,
            0
        ]).toRawKey();
        const dRepKey = accountKey.derive([
            3,
            keyIndex
        ]).toRawKey();
        return {
            paymentKey,
            stakeKey,
            dRepKey
        };
    } else {
        const paymentKey = Ed25519PrivateKey2.fromNormalHex(Ed25519PrivateNormalKeyHex(privateKeyHex[0]));
        const stakeKey = Ed25519PrivateKey2.fromNormalHex(Ed25519PrivateNormalKeyHex(privateKeyHex[1]));
        return {
            paymentKey,
            stakeKey
        };
    }
};
var buildEd25519PrivateKeyFromSecretKey = (secretKeyHex)=>{
    return Ed25519PrivateKey2.fromExtendedBytes(new Uint8Array(clampScalar(Buffer.from(import_hash.default.sha512().update(Buffer.from(secretKeyHex, "hex")).digest()))));
};
var buildScriptPubkey = (keyHash)=>{
    const scriptPubkey = new ScriptPubkey(Ed25519KeyHashHex2(keyHash.hex()));
    return NativeScript.newScriptPubkey(scriptPubkey);
};
var buildDRepID = (dRepKey, networkId = NetworkId.Testnet, addressType = AddressType.EnterpriseKey)=>{
    const dRepKeyBytes = Buffer.from(dRepKey, "hex");
    const dRepIdHex = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blake2b$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__blake2b$3e$__["blake2b"])(28).update(dRepKeyBytes).digest("hex");
    const paymentAddress = EnterpriseAddress.packParts({
        networkId,
        paymentPart: {
            hash: Hash28ByteBase162(dRepIdHex),
            type: CredentialType.KeyHash
        },
        type: addressType
    });
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"].toTypedBech32("drep", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"].fromBytes(paymentAddress));
};
;
;
;
;
;
;
;
;
var toPlutusData = (data)=>{
    const toPlutusList = (data2)=>{
        const plutusList = new PlutusList();
        data2.forEach((element)=>{
            plutusList.add(toPlutusData(element));
        });
        return plutusList;
    };
    switch(typeof data){
        case "string":
            return PlutusData.newBytes((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toBytes"])(data));
        case "number":
            return PlutusData.newInteger(BigInt(data));
        case "bigint":
            return PlutusData.newInteger(BigInt(data));
        case "object":
            if (data instanceof Array) {
                const plutusList = toPlutusList(data);
                return PlutusData.newList(plutusList);
            } else if (data instanceof Map) {
                const plutusMap = new PlutusMap();
                data.forEach((value, key)=>{
                    plutusMap.insert(toPlutusData(key), toPlutusData(value));
                });
                return PlutusData.newMap(plutusMap);
            } else {
                return PlutusData.newConstrPlutusData(new ConstrPlutusData(BigInt(data.alternative), toPlutusList(data.fields)));
            }
    }
};
var isConstrPlutusDataJson = (data)=>{
    return typeof data === "object" && "constructor" in data && (typeof data.constructor === "number" || typeof data.constructor === "bigint" || typeof data.constructor === "string") && "fields" in data && Array.isArray(data.fields);
};
function isMapPlutusDataJson(data) {
    return typeof data === "object" && Array.isArray(data);
}
function isKeyValuePlutusDataJson(data) {
    return typeof data === "object" && "k" in data && typeof data.k === "object" && "v" in data && typeof data.v === "object";
}
var fromJsonToPlutusData = (data)=>{
    if (isConstrPlutusDataJson(data)) {
        const plutusList = new PlutusList();
        data.fields.map((val)=>{
            plutusList.add(fromJsonToPlutusData(val));
        });
        const plutusConstrData = new ConstrPlutusData(BigInt(data.constructor), plutusList);
        return PlutusData.newConstrPlutusData(plutusConstrData);
    } else if ("int" in data && Object.keys(data).length === 1) {
        if (typeof data.int === "bigint" || typeof data.int === "number" || typeof data.int === "string") {
            return PlutusData.newInteger(BigInt(data.int));
        } else {
            throw new Error("Malformed int field in Plutus data, expected one of bigint, number or string");
        }
    } else if ("bytes" in data && Object.keys(data).length === 1) {
        if (typeof data.bytes === "string") {
            return PlutusData.newBytes(Buffer.from(data.bytes, "hex"));
        } else {
            throw new Error("Malformed bytes field in Plutus data, expected string");
        }
    } else if ("list" in data && Object.keys(data).length === 1) {
        if (Array.isArray(data.list)) {
            const plutusList = new PlutusList();
            data.list.map((val)=>{
                plutusList.add(fromJsonToPlutusData(val));
            });
            return PlutusData.newList(plutusList);
        } else {
            throw new Error("Malformed list field in Plutus data, expected list");
        }
    } else if ("map" in data && Object.keys(data).length === 1) {
        if (isMapPlutusDataJson(data.map)) {
            const plutusMap = new PlutusMap();
            data.map.forEach((val)=>{
                if (isKeyValuePlutusDataJson(val)) {
                    plutusMap.insert(fromJsonToPlutusData(val.k), fromJsonToPlutusData(val.v));
                } else {
                    throw new Error("Malformed key value pair in Plutus data map");
                }
            });
            return PlutusData.newMap(plutusMap);
        } else {
            console.log(data);
            throw new Error("Malformed map field in Plutus data");
        }
    } else {
        throw new Error("Malformed Plutus data json");
    }
};
var fromBuilderToPlutusData = (data)=>{
    if (data.type === "Mesh") {
        return toPlutusData(data.content);
    } else if (data.type === "CBOR") {
        return PlutusData.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(data.content));
    } else if (data.type === "JSON") {
        let content;
        if (typeof data.content === "string") {
            content = JSON.parse(data.content);
        } else {
            content = data.content;
        }
        return fromJsonToPlutusData(content);
    } else {
        throw new Error("Malformed builder data, expected types of, Mesh, CBOR or JSON");
    }
};
var fromPlutusDataToJson = (data)=>{
    if (data.getKind() === PlutusDataKind.ConstrPlutusData) {
        const plutusData = data.asConstrPlutusData();
        if (plutusData !== void 0) {
            const fields = plutusData.getData();
            const list = [];
            for(let i = 0; i < fields.getLength(); i++){
                const element = fields.get(i);
                list.push(fromPlutusDataToJson(element));
            }
            return {
                constructor: plutusData.getAlternative(),
                fields: list
            };
        } else {
            throw new Error("Invalid constructor data found");
        }
    } else if (data.getKind() === PlutusDataKind.Map) {
        const plutusMap = data.asMap();
        const mapList = [];
        if (plutusMap !== void 0) {
            const keys = plutusMap.getKeys();
            for(let i = 0; i < keys.getLength(); i++){
                const key = keys.get(i);
                const value = plutusMap.get(key);
                if (value) {
                    mapList.push({
                        k: fromPlutusDataToJson(key),
                        v: fromPlutusDataToJson(value)
                    });
                }
            }
            return {
                map: mapList
            };
        } else {
            throw new Error("Invalid map data found");
        }
    } else if (data.getKind() === PlutusDataKind.List) {
        const plutusList = data.asList();
        if (plutusList !== void 0) {
            const list = [];
            for(let i = 0; i < plutusList.getLength(); i++){
                const element = plutusList.get(i);
                list.push(fromPlutusDataToJson(element));
            }
            return {
                list
            };
        } else {
            throw new Error("Invalid list data found");
        }
    } else if (data.getKind() === PlutusDataKind.Integer) {
        const plutusInt = data.asInteger();
        if (plutusInt !== void 0) {
            return {
                int: plutusInt
            };
        } else {
            throw new Error("Invalid integer data found");
        }
    } else if (data.getKind() === PlutusDataKind.Bytes) {
        const plutusBytes = data.asBoundedBytes();
        if (plutusBytes !== void 0) {
            return {
                bytes: Buffer.from(plutusBytes).toString("hex")
            };
        } else {
            throw new Error("Invalid bytes data found");
        }
    } else {
        throw new Error("Invalid Plutus data found");
    }
};
var datumCborToJson = (datumCbor)=>{
    const parsedDatum = PlutusData.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(datumCbor));
    return fromPlutusDataToJson(parsedDatum);
};
var parseDatumCbor = (datumCbor)=>{
    return datumCborToJson(datumCbor);
};
var parseInlineDatum = (utxo)=>{
    const datumCbor = utxo.inline_datum || "";
    return datumCborToJson(datumCbor);
};
var deserializeDataHash = (dataHash)=>DatumHash(dataHash);
var deserializePlutusData = (plutusData)=>PlutusData.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(plutusData));
;
;
;
;
var deserializeEd25519KeyHash = (ed25519KeyHash)=>Ed25519KeyHash2.fromBytes((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toBytes"])(ed25519KeyHash));
var deserializePlutusScript = (plutusScript, version)=>{
    switch(version){
        case "V1":
            return PlutusV1Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(plutusScript));
        case "V2":
            return PlutusV2Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(plutusScript));
        case "V3":
            return PlutusV3Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(plutusScript));
        default:
            throw new Error("Invalid Plutus script version");
    }
};
var deserializeNativeScript = (nativeScript)=>NativeScript.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(nativeScript));
var deserializeScriptHash = (scriptHash)=>ScriptHash.fromEd25519KeyHashHex((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Ed25519KeyHashHex"])(scriptHash));
var deserializeScriptRef = (scriptRef)=>Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(scriptRef));
var deserializeTxUnspentOutput = (txUnspentOutput)=>TransactionUnspentOutput.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(txUnspentOutput));
var deserializeValue = (value)=>Value.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(value));
var deserializeTx = (tx)=>Transaction.fromCbor(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TxCBOR(tx));
var deserializeTxHash = (txHash)=>TransactionId(txHash);
// src/utils/converter.ts
var toAddress = (bech325)=>Address.fromBech32(bech325);
var toCardanoAddress = (address)=>{
    try {
        return Address.fromBech32(address);
    } catch  {
        try {
            return Address.fromBase58(address);
        } catch  {
            throw new Error(`Invalid address format, ${address}`);
        }
    }
};
var toBaseAddress = (bech325)=>{
    return BaseAddress.fromAddress(toAddress(bech325));
};
var toEnterpriseAddress = (bech325)=>{
    return EnterpriseAddress.fromAddress(toAddress(bech325));
};
var toRewardAddress = (bech325)=>RewardAddress.fromAddress(toAddress(bech325));
var fromTxUnspentOutput = (txUnspentOutput)=>{
    const dataHash = txUnspentOutput.output().datum() ? txUnspentOutput.output().datum()?.toCbor().toString() : void 0;
    const scriptRef = txUnspentOutput.output().scriptRef() ? txUnspentOutput.output().scriptRef()?.toCbor().toString() : void 0;
    const plutusData = txUnspentOutput.output().datum()?.asInlineData() ? txUnspentOutput.output().datum()?.asInlineData()?.toCbor().toString() : void 0;
    return {
        input: {
            outputIndex: Number(txUnspentOutput.input().index()),
            txHash: txUnspentOutput.input().transactionId()
        },
        output: {
            address: txUnspentOutput.output().address().toBech32(),
            amount: fromValue(txUnspentOutput.output().amount()),
            dataHash,
            // todo not sure if correct
            plutusData,
            // todo not sure if correct
            scriptRef
        }
    };
};
var toTxUnspentOutput = (utxo)=>{
    const txInput = new TransactionInput(deserializeTxHash(utxo.input.txHash), BigInt(utxo.input.outputIndex));
    const txOutput = new TransactionOutput(toAddress(utxo.output.address), toValue(utxo.output.amount));
    if (utxo.output.dataHash !== void 0) {
        txOutput.setDatum(Datum.fromCore(deserializeDataHash(utxo.output.dataHash)));
    }
    if (utxo.output.plutusData !== void 0) {
        const plutusData = deserializePlutusData(utxo.output.plutusData);
        const datum = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Datum(void 0, plutusData);
        txOutput.setDatum(datum);
    }
    if (utxo.output.scriptRef !== void 0) {
        txOutput.setScriptRef(deserializeScriptRef(utxo.output.scriptRef));
    }
    return new TransactionUnspentOutput(txInput, txOutput);
};
var addressToBech32 = (address)=>{
    return address.toBech32();
};
var fromValue = (value)=>{
    const assets = [
        {
            unit: "lovelace",
            quantity: value.coin().toString()
        }
    ];
    const multiAsset = value.multiasset();
    if (multiAsset !== void 0) {
        const _assets = Array.from(multiAsset.keys());
        for(let i = 0; i < _assets.length; i += 1){
            const assetId = _assets[i];
            if (assetId !== void 0) {
                const assetQuantity = multiAsset.get(assetId);
                if (assetQuantity !== void 0) {
                    assets.push({
                        unit: assetId,
                        quantity: assetQuantity.toString()
                    });
                }
            }
        }
    }
    return assets;
};
var toScriptRef = (script)=>{
    if ("code" in script) {
        const plutusScript = deserializePlutusScript(script.code, script.version);
        if (plutusScript instanceof PlutusV1Script) return Script.newPlutusV1Script(plutusScript);
        if (plutusScript instanceof PlutusV2Script) return Script.newPlutusV2Script(plutusScript);
        if (plutusScript instanceof PlutusV3Script) return Script.newPlutusV3Script(plutusScript);
    }
    return Script.newNativeScript(toNativeScript(script));
};
var fromScriptRef = (scriptRef)=>{
    const script = Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(scriptRef));
    const plutusScriptCodeV3 = script.asPlutusV3()?.toCbor().toString();
    if (plutusScriptCodeV3) {
        return {
            code: plutusScriptCodeV3,
            version: "V3"
        };
    }
    const plutusScriptCodeV2 = script.asPlutusV2()?.toCbor().toString();
    if (plutusScriptCodeV2) {
        return {
            code: plutusScriptCodeV2,
            version: "V2"
        };
    }
    const plutusScriptCodeV1 = script.asPlutusV1()?.toCbor().toString();
    if (plutusScriptCodeV1) {
        return {
            code: plutusScriptCodeV1,
            version: "V1"
        };
    }
    const nativeScript = script.asNative();
    if (!nativeScript) {
        throw new Error("Invalid script");
    }
    return fromNativeScript(nativeScript);
};
var fromNativeScript = (script)=>{
    const fromNativeScripts = (scripts)=>{
        const nativeScripts = new Array();
        for(let index = 0; index < scripts.length; index += 1){
            const script2 = scripts[index];
            if (script2) {
                nativeScripts.push(fromNativeScript(script2));
            }
        }
        return nativeScripts;
    };
    switch(script.kind()){
        case RequireAllOf:
            {
                const scriptAll = script.asScriptAll();
                return {
                    type: "all",
                    scripts: fromNativeScripts(scriptAll.nativeScripts())
                };
            }
        case RequireAnyOf:
            {
                const scriptAny = script.asScriptAny();
                return {
                    type: "any",
                    scripts: fromNativeScripts(scriptAny.nativeScripts())
                };
            }
        case RequireNOf:
            {
                const scriptNOfK = script.asScriptNOfK();
                return {
                    type: "atLeast",
                    required: scriptNOfK.required(),
                    scripts: fromNativeScripts(scriptNOfK.nativeScripts())
                };
            }
        case RequireTimeAfter:
            {
                const timelockStart = script.asTimelockStart();
                return {
                    type: "after",
                    slot: timelockStart.slot().toString()
                };
            }
        case RequireTimeBefore:
            {
                const timelockExpiry = script.asTimelockExpiry();
                return {
                    type: "before",
                    slot: timelockExpiry.slot().toString()
                };
            }
        case RequireSignature:
            {
                const scriptPubkey = script.asScriptPubkey();
                return {
                    type: "sig",
                    keyHash: scriptPubkey.keyHash().toString()
                };
            }
        default:
            throw new Error(`Script Kind: ${script.kind()}, is not supported`);
    }
};
var toNativeScript = (script)=>{
    const toNativeScripts = (scripts)=>{
        const nativeScripts = [];
        scripts.forEach((script2)=>{
            nativeScripts.push(toNativeScript(script2));
        });
        return nativeScripts;
    };
    switch(script.type){
        case "all":
            return NativeScript.newScriptAll(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].ScriptAll(toNativeScripts(script.scripts)));
        case "any":
            return NativeScript.newScriptAny(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].ScriptAny(toNativeScripts(script.scripts)));
        case "atLeast":
            return NativeScript.newScriptNOfK(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].ScriptNOfK(toNativeScripts(script.scripts), script.required));
        case "after":
            return NativeScript.newTimelockStart(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TimelockStart(Slot(parseInt(script.slot))));
        case "before":
            return NativeScript.newTimelockExpiry(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TimelockExpiry(Slot(parseInt(script.slot))));
        case "sig":
            return NativeScript.newScriptPubkey(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].ScriptPubkey(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$Ed25519e$2f$Ed25519KeyHash$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Ed25519KeyHash"].fromBytes((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toBytes"])(script.keyHash)).hex()));
    }
};
var toValue = (assets)=>{
    const multiAsset = /* @__PURE__ */ new Map();
    assets.filter((asset)=>asset.unit !== "lovelace" && asset.unit !== "").forEach((asset)=>{
        multiAsset.set(AssetId(asset.unit), BigInt(asset.quantity));
    });
    const lovelace = assets.find((asset)=>asset.unit === "lovelace" || asset.unit === "");
    const value = new Value(BigInt(lovelace ? lovelace.quantity : 0));
    if (assets.length > 1 || !lovelace) {
        value.setMultiasset(multiAsset);
    }
    return value;
};
var toDRep = (dRepId)=>{
    if (dRepId.length === 58) {
        const { prefix, words } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].decode(dRepId);
        if (prefix !== "drep") {
            throw new Error("Invalid DRepId prefix");
        }
        const bytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].decode(new Uint8Array(words));
        if (bytes[0] === 34) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newKeyHash(Ed25519KeyHashHex2(bytes.subarray(1).toString("hex")));
        } else if (bytes[0] === 35) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newScriptHash(Hash28ByteBase162(bytes.subarray(1).toString("hex")));
        } else {
            throw new Error("Malformed CIP129 DRepId");
        }
    } else {
        const { prefix, words } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].decode(dRepId);
        switch(prefix){
            case "drep":
                {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newKeyHash(Ed25519KeyHashHex2(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].decode(new Uint8Array(words)).toString("hex")));
                }
            case "drep_script":
                {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newScriptHash(Hash28ByteBase162(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].decode(new Uint8Array(words)).toString("hex")));
                }
            default:
                {
                    throw new Error("Malformed DRepId prefix");
                }
        }
    }
};
var getDRepIds = (dRepId)=>{
    let result = {
        cip105: "",
        cip129: ""
    };
    if (dRepId.length === 58) {
        result.cip129 = dRepId;
        const { prefix, words } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].decode(dRepId);
        if (prefix !== "drep") {
            throw new Error("Malformed CIP129 DRepId");
        }
        const bytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].decode(new Uint8Array(words));
        if (bytes[0] === 34) {
            result.cip105 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].encode("drep", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].encode(bytes.subarray(1)));
        } else if (bytes[0] === 35) {
            result.cip105 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].encode("drep_script", __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].encode(bytes.subarray(1)));
        } else {
            throw new Error("Malformed CIP129 DRepId");
        }
    } else {
        result.cip105 = dRepId;
        try {
            const { prefix, words } = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].decode(dRepId);
            let rawBytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].decode(new Uint8Array(words));
            if (prefix === "drep") {
                if (!rawBytes) {
                    throw new Error("Malformed key hash in DRepId");
                }
                let rawBytesWithPrefix = new Uint8Array(rawBytes.length + 1);
                rawBytesWithPrefix.set([
                    34
                ]);
                rawBytesWithPrefix.set(rawBytes, 1);
                let base32RawBytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].encode(rawBytesWithPrefix);
                result.cip129 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].encode("drep", base32RawBytes);
            } else if (prefix === "drep_script") {
                if (!rawBytes) {
                    throw new Error("Malformed script hash in DRepId");
                }
                let rawBytesWithPrefix = new Uint8Array(rawBytes.length + 1);
                rawBytesWithPrefix.set([
                    35
                ]);
                rawBytesWithPrefix.set(rawBytes, 1);
                let base32RawBytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].encode(rawBytesWithPrefix);
                result.cip129 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].encode("drep", base32RawBytes);
            } else {
                throw new Error("Can only calculate DRepIds for script/key DReps");
            }
        } catch (e) {
            console.error(e);
            throw new Error("Malformed DRepId");
        }
    }
    return result;
};
// src/utils/value.ts
function mergeValue(a, b) {
    const ma = a.multiasset() ?? /* @__PURE__ */ new Map();
    b.multiasset()?.forEach((v, k)=>{
        const newVal = (ma.get(k) ?? 0n) + v;
        if (newVal == 0n) {
            ma.delete(k);
        } else {
            ma.set(k, newVal);
        }
    });
    return new Value(BigInt(a.coin()) + BigInt(b.coin()), ma.size > 0 ? ma : void 0);
}
function negateValue(v) {
    const entries = v.multiasset()?.entries();
    const tokenMap = /* @__PURE__ */ new Map();
    if (entries) {
        for (const entry of entries){
            tokenMap.set(entry[0], -entry[1]);
        }
    }
    return new Value(-v.coin(), tokenMap);
}
function subValue(a, b) {
    return mergeValue(a, negateValue(b));
}
function negatives(v) {
    const entries = v.multiasset()?.entries();
    const coin = v.coin() < 0n ? v.coin() : 0n;
    const tokenMap = /* @__PURE__ */ new Map();
    if (entries) {
        for (const entry of entries){
            if (entry[1] < 0n) {
                tokenMap.set(entry[0], entry[1]);
            }
        }
    }
    return new Value(coin, tokenMap);
}
function assetTypes(v) {
    let count = v.coin() == 0n ? 0 : 1;
    const entries = v.multiasset();
    if (entries) {
        entries.forEach(()=>{
            count += 1;
        });
    }
    return count;
}
function empty(v) {
    return assetTypes(v) == 0;
}
;
;
var serialzeAddress = (deserializedAddress, networkId = 0)=>{
    const { pubKeyHash, scriptHash, stakeCredentialHash, stakeScriptCredentialHash } = deserializedAddress;
    const isPaymentScript = !pubKeyHash;
    const isStakeScript = !stakeCredentialHash;
    const paymentHash = isPaymentScript ? scriptHash : pubKeyHash;
    const stakeHash = isStakeScript ? stakeScriptCredentialHash : stakeCredentialHash;
    if (!paymentHash) throw new Error("Error: serializeAddress: Address must contain a payment part");
    const addressObj = isPaymentScript ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["scriptAddress"])(paymentHash, stakeHash, isStakeScript) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["pubKeyAddress"])(paymentHash, stakeHash, isStakeScript);
    return serializeAddressObj(addressObj, networkId);
};
var addrBech32ToPlutusData = (bech325)=>{
    const cardanoAddress = Address.fromBech32(bech325);
    const cardanoAddressProps = cardanoAddress.getProps();
    const paymentPartList = new PlutusList();
    if (!cardanoAddressProps.paymentPart) {
        throw new Error("Error: addrBech32ToPlutusDataHex: Address must contain a payment part");
    }
    paymentPartList.add(PlutusData.newBytes(Buffer.from(cardanoAddressProps.paymentPart.hash, "hex")));
    const paymentPart = PlutusData.newConstrPlutusData(new ConstrPlutusData(BigInt(cardanoAddressProps.paymentPart.type), paymentPartList));
    const delegationPartList = new PlutusList();
    let delegationPart;
    if (cardanoAddressProps.delegationPart) {
        delegationPartList.add(PlutusData.newBytes(Buffer.from(cardanoAddressProps.delegationPart.hash, "hex")));
        const inlineDelegationPart = PlutusData.newConstrPlutusData(new ConstrPlutusData(BigInt(0), delegationPartList));
        const someList = new PlutusList();
        someList.add(inlineDelegationPart);
        delegationPart = PlutusData.newConstrPlutusData(new ConstrPlutusData(BigInt(0), someList));
    } else if (cardanoAddressProps.pointer) {
        const pointerList = new PlutusList();
        pointerList.add(PlutusData.newInteger(BigInt(cardanoAddressProps.pointer.slot)));
        pointerList.add(PlutusData.newInteger(BigInt(cardanoAddressProps.pointer.txIndex)));
        pointerList.add(PlutusData.newInteger(BigInt(cardanoAddressProps.pointer.certIndex)));
        const pointer = PlutusData.newConstrPlutusData(new ConstrPlutusData(BigInt(1), pointerList));
        const someList = new PlutusList();
        someList.add(pointer);
        delegationPart = PlutusData.newConstrPlutusData(new ConstrPlutusData(BigInt(0), someList));
    } else {
        delegationPart = PlutusData.newConstrPlutusData(new ConstrPlutusData(BigInt(1), new PlutusList()));
    }
    const addressList = new PlutusList();
    addressList.add(paymentPart);
    addressList.add(delegationPart);
    return PlutusData.newConstrPlutusData(new ConstrPlutusData(BigInt(0), addressList));
};
var addrBech32ToPlutusDataHex = (bech325)=>{
    return addrBech32ToPlutusData(bech325).toCbor();
};
var addrBech32ToPlutusDataObj = (bech325)=>{
    return fromPlutusDataToJson(addrBech32ToPlutusData(bech325));
};
var plutusDataToAddrBech32 = (plutusData, networkId = 0)=>{
    const constrPlutusData = plutusData.asConstrPlutusData();
    if (!constrPlutusData || constrPlutusData.getAlternative() !== BigInt(0)) {
        throw new Error("Error: serializeAddressObj: Address must contain a constructor 0");
    }
    const plutusDataList = constrPlutusData.getData();
    if (plutusDataList.getLength() !== 2) {
        throw new Error("Error: serializeAddressObj: Address must contain 2 parts");
    }
    const paymentData = plutusDataList.get(0);
    const paymentConstrData = paymentData.asConstrPlutusData();
    if (!paymentConstrData) {
        throw new Error("Error: serializeAddressObj: Payment part must be a constructor");
    }
    const paymentConstrDataList = paymentConstrData.getData();
    if (paymentConstrDataList.getLength() !== 1) {
        throw new Error("Error: serializeAddressObj: Payment part must contain 1 element");
    }
    const paymentBytes = paymentConstrDataList.get(0).asBoundedBytes();
    if (!paymentBytes) {
        throw new Error("Error: serializeAddressObj: Payment inner part must be bytes");
    }
    if (paymentConstrData.getAlternative() !== BigInt(0) && paymentConstrData.getAlternative() !== BigInt(1)) {
        throw new Error("Error: serializeAddressObj: Payment part must be alternative 0 or 1");
    }
    const cardanoPaymentCredential = {
        hash: Hash28ByteBase162(Buffer.from(paymentBytes).toString("hex")),
        type: Number(paymentConstrData.getAlternative())
    };
    const delegationData = plutusDataList.get(1);
    const delegationConstrData = delegationData.asConstrPlutusData();
    if (!delegationConstrData) {
        throw new Error("Error: serializeAddressObj: Delegation part must be a constructor");
    }
    if (delegationConstrData.getAlternative() === BigInt(1)) {
        return EnterpriseAddress.fromCredentials(networkId, cardanoPaymentCredential).toAddress().toBech32().toString();
    } else if (delegationConstrData.getAlternative() === BigInt(0)) {
        const delegationDataList = delegationConstrData.getData();
        if (delegationDataList.getLength() !== 1) {
            throw new Error("Error: serializeAddressObj: Delegation part must contain 1 element");
        }
        const delegationDataInner = delegationDataList.get(0);
        const delegationDataInnerConstrData = delegationDataInner.asConstrPlutusData();
        if (!delegationDataInnerConstrData) {
            throw new Error("Error: serializeAddressObj: Delegation inner part must be a constructor");
        }
        if (delegationDataInnerConstrData.getAlternative() === BigInt(0)) {
            const delegationDataInnerList = delegationDataInnerConstrData.getData();
            if (delegationDataInnerList.getLength() !== 1) {
                throw new Error("Error: serializeAddressObj: Delegation inner part must contain 1 element");
            }
            const delegationCredential = delegationDataInnerList.get(0).asConstrPlutusData();
            if (!delegationCredential) {
                throw new Error("Error: serializeAddressObj: Delegation inner part must be a constructor");
            }
            const delegationBytesList = delegationCredential.getData();
            if (delegationBytesList.getLength() !== 1) {
                throw new Error("Error: serializeAddressObj: Delegation bytes part must contain 1 element");
            }
            const delegationBytes = delegationBytesList.get(0).asBoundedBytes();
            if (!delegationBytes) {
                throw new Error("Error: serializeAddressObj: Delegation bytes part must be of type bytes");
            }
            const cardanoStakeCredential = {
                hash: Hash28ByteBase162(Buffer.from(delegationBytes).toString("hex")),
                type: Number(delegationCredential.getAlternative())
            };
            return BaseAddress.fromCredentials(networkId, cardanoPaymentCredential, cardanoStakeCredential).toAddress().toBech32().toString();
        } else if (delegationDataInnerConstrData.getAlternative() === BigInt(1)) {
            const delegationDataInnerList = delegationDataInnerConstrData.getData();
            if (delegationDataInnerList.getLength() !== 3) {
                throw new Error("Error: serializeAddressObj: Delegation inner part must contain 3 elements");
            }
            const slot = delegationDataInnerList.get(0).asInteger();
            if (!slot) {
                throw new Error("Error: serializeAddressObj: Delegation inner part slot must be integer");
            }
            const txIndex = delegationDataInnerList.get(1).asInteger();
            if (!txIndex) {
                throw new Error("Error: serializeAddressObj: Delegation inner part txIndex must be integer");
            }
            const certIndex = delegationDataInnerList.get(2).asInteger();
            if (!certIndex) {
                throw new Error("Error: serializeAddressObj: Delegation inner part certIndex must be integer");
            }
            const cardanoPointer = {
                slot,
                txIndex: TxIndex(Number(txIndex)),
                certIndex: CertIndex(Number(certIndex))
            };
            return PointerAddress.fromCredentials(networkId, cardanoPaymentCredential, cardanoPointer).toAddress().toBech32().toString();
        } else {
            throw new Error("Error: serializeAddressObj: Delegation inner part must be alternative 0 or 1");
        }
    } else {
        throw new Error("Error: serializeAddressObj: Delegation part must be alternative 0 or 1");
    }
};
var serializeAddressObj = (plutusDataAddressObject, networkId = 0)=>{
    const cardanoPlutusData = fromJsonToPlutusData(plutusDataAddressObject);
    return plutusDataToAddrBech32(cardanoPlutusData, networkId);
};
var serializePlutusAddressToBech32 = (plutusHex, networkId = 0)=>{
    const cardanoPlutusData = PlutusData.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(plutusHex));
    return plutusDataToAddrBech32(cardanoPlutusData, networkId).toString();
};
var deserializeBech32Address = (bech32Addr)=>{
    const deserializedAddress = Address.fromBech32(bech32Addr).getProps();
    return {
        pubKeyHash: deserializedAddress.paymentPart?.type === CredentialType.KeyHash ? deserializedAddress.paymentPart?.hash : "",
        scriptHash: deserializedAddress.paymentPart?.type === CredentialType.ScriptHash ? deserializedAddress.paymentPart?.hash : "",
        stakeCredentialHash: deserializedAddress.delegationPart?.type === CredentialType.KeyHash ? deserializedAddress.delegationPart?.hash : "",
        stakeScriptCredentialHash: deserializedAddress.delegationPart?.type === CredentialType.ScriptHash ? deserializedAddress.delegationPart?.hash : ""
    };
};
var deserializeAddress = (address)=>{
    const _address = Address.fromString(address);
    if (_address === null) throw new Error("Invalid address");
    return _address;
};
var scriptHashToBech32 = (scriptHash, stakeCredentialHash, networkId = 0, isScriptStakeCredentialHash = false)=>{
    if (stakeCredentialHash) {
        return BaseAddress.fromCredentials(networkId, {
            hash: Hash28ByteBase162(scriptHash),
            type: CredentialType.ScriptHash
        }, {
            hash: Hash28ByteBase162(stakeCredentialHash),
            type: isScriptStakeCredentialHash ? CredentialType.ScriptHash : CredentialType.KeyHash
        }).toAddress().toBech32().toString();
    } else {
        return EnterpriseAddress.fromCredentials(networkId, {
            hash: Hash28ByteBase162(scriptHash),
            type: CredentialType.ScriptHash
        }).toAddress().toBech32().toString();
    }
};
var v2ScriptToBech32 = (scriptCbor, stakeCredential, networkId = 0, isScriptStakeCredential = false)=>scriptHashToBech32(Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(scriptCbor)).hash().toString(), stakeCredential, networkId, isScriptStakeCredential);
var scriptHashToRewardAddress = (hash2, networkId = 0)=>{
    return RewardAddress.fromCredentials(networkId, {
        hash: Hash28ByteBase162(hash2),
        type: CredentialType.ScriptHash
    }).toAddress().toBech32().toString();
};
var keyHashToRewardAddress = (hash2, networkId = 0)=>{
    return RewardAddress.fromCredentials(networkId, {
        hash: Hash28ByteBase162(hash2),
        type: CredentialType.KeyHash
    }).toAddress().toBech32().toString();
};
;
;
var bytesToHex = (bytes)=>Buffer.from(bytes).toString("hex");
var hexToBytes = (hex)=>Buffer.from(hex, "hex");
var utf8ToBytes = (str)=>Buffer.from(str, "utf8");
var utf8ToHex = (str)=>Buffer.from(str, "utf8").toString("hex");
var hexToBech32 = (prefix, hex)=>{
    const buf = Buffer.from(hex, "hex");
    const base32RawBytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].encode(buf);
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].encode(prefix, base32RawBytes);
};
// src/utils/witness-set.ts
var addVKeyWitnessSetToTransaction = (txHex, vkeyWitnessSet)=>{
    const tx = Transaction.fromCbor(TxCBOR(txHex));
    const currentWitnessSet = tx.witnessSet();
    const newVkeyWitnessSet = TransactionWitnessSet.fromCbor(HexBlob(vkeyWitnessSet));
    const currentVkeyWitnesses = currentWitnessSet.vkeys();
    const newVkeyWitnesses = newVkeyWitnessSet.vkeys();
    const allVkeyWitnesses = [
        ...currentVkeyWitnesses?.values() ?? [],
        ...newVkeyWitnesses?.values() ?? []
    ];
    currentWitnessSet.setVkeys(CborSet.fromCore(allVkeyWitnesses.map((vkw)=>vkw.toCore()), VkeyWitness.fromCore));
    tx.setWitnessSet(currentWitnessSet);
    return tx.toCbor();
};
// src/utils/fee.ts
var calculateFees = (minFeeA, minFeeB, minFeeRefScriptCostPerByte, priceMem, priceStep, tx, refScriptSize)=>{
    let fee = minFeeB + tx.toCbor().length / 2 * minFeeA;
    fee += calculateRefScriptFees(refScriptSize, minFeeRefScriptCostPerByte);
    let scriptFee = BigInt(0);
    let priceMemNumerator = priceMem;
    let priceMemDenominator = 1;
    while(priceMemNumerator % 1){
        priceMemNumerator *= 10;
        priceMemDenominator *= 10;
    }
    let priceStepNumerator = priceStep;
    let priceStepDenominator = 1;
    while(priceStepNumerator % 1){
        priceStepNumerator *= 10;
        priceStepDenominator *= 10;
    }
    if (tx.witnessSet().redeemers()) {
        for (const redeemer of tx.witnessSet().redeemers().values()){
            scriptFee += redeemer.exUnits().mem() * BigInt(priceMemNumerator.toString()) / BigInt(priceMemDenominator.toString());
            scriptFee += redeemer.exUnits().steps() * BigInt(priceStepNumerator.toString()) / BigInt(priceStepDenominator.toString());
            if (priceMemNumerator % priceMemDenominator !== 0) {
                scriptFee += BigInt(1);
            }
            if (priceStepNumerator % priceStepDenominator !== 0) {
                scriptFee += BigInt(1);
            }
        }
    }
    return BigInt(fee) + scriptFee;
};
var calculateRefScriptFees = (refScriptSize, minFeeRefScriptCostPerByte, tierMultiplier = 1.2)=>{
    let fee = 0;
    const tierSize = 25600;
    let currentRefScriptSize = refScriptSize;
    let multiplier = 1;
    while(currentRefScriptSize >= tierSize){
        fee += tierSize * multiplier * minFeeRefScriptCostPerByte;
        currentRefScriptSize -= tierSize;
        multiplier *= tierMultiplier;
    }
    if (currentRefScriptSize > 0) {
        fee += currentRefScriptSize * multiplier * minFeeRefScriptCostPerByte;
    }
    fee = Math.ceil(fee);
    return fee;
};
// src/resolvers/index.ts
var resolveDataHash = (rawData, type = "Mesh")=>{
    const plutusData = fromBuilderToPlutusData({
        content: rawData,
        type
    });
    return plutusData.hash().toString();
};
var resolveNativeScriptAddress = (script, networkId = 0)=>{
    const nativeScript = toNativeScript(script);
    const enterpriseAddress = EnterpriseAddress.fromCredentials(networkId, {
        hash: nativeScript.hash(),
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].CredentialType.ScriptHash
    });
    return enterpriseAddress.toAddress().toBech32().toString();
};
var resolveNativeScriptHash = (script)=>{
    return toNativeScript(script).hash().toString();
};
var resolvePaymentKeyHash = (bech325)=>{
    try {
        const paymentKeyHash = [
            toBaseAddress(bech325)?.getPaymentCredential().hash,
            toEnterpriseAddress(bech325)?.getPaymentCredential().hash
        ].find((kh)=>kh !== void 0);
        if (paymentKeyHash !== void 0) return paymentKeyHash.toString();
        throw new Error(`Couldn't resolve payment key hash from address: ${bech325}`);
    } catch (error) {
        throw new Error(`An error occurred during resolvePaymentKeyHash: ${error}.`);
    }
};
var resolvePlutusScriptAddress = (script, networkId = 0)=>{
    const plutusScript = deserializePlutusScript(script.code, script.version);
    const enterpriseAddress = EnterpriseAddress.fromCredentials(networkId, {
        hash: plutusScript.hash(),
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].CredentialType.ScriptHash
    });
    return enterpriseAddress.toAddress().toBech32().toString();
};
var resolvePlutusScriptHash = (bech325)=>{
    try {
        const enterpriseAddress = toEnterpriseAddress(bech325);
        const scriptHash = enterpriseAddress?.getPaymentCredential().hash;
        if (scriptHash !== void 0) return scriptHash.toString();
        throw new Error(`Couldn't resolve script hash from address: ${bech325}`);
    } catch (error) {
        throw new Error(`An error occurred during resolveScriptHash: ${error}.`);
    }
};
var resolvePoolId = (hash2)=>{
    return PoolId.fromKeyHash(Ed25519KeyHashHex2(hash2)).toString();
};
var resolvePrivateKey = (words)=>{
    const buildBip32PrivateKey2 = (entropy2, password = "")=>{
        return Bip32PrivateKey2.fromBip39Entropy(Buffer.from((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toBytes"])(entropy2)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fromUTF8"])(password));
    };
    const entropy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bip39$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mnemonicToEntropy"])(words.join(" "));
    const bip32PrivateKey = buildBip32PrivateKey2(entropy);
    const bytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].encode(bip32PrivateKey.bytes());
    const bech32PrivateKey = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].encode("xprv", bytes, 1023);
    return bech32PrivateKey;
};
var resolveScriptRef = (script)=>{
    return toScriptRef(script).toCbor().toString();
};
var resolveRewardAddress = (bech325)=>{
    try {
        const address = toAddress(bech325);
        const baseAddress = toBaseAddress(bech325);
        const stakeKeyHash = baseAddress?.getStakeCredential().hash;
        if (stakeKeyHash !== void 0) return buildRewardAddress(address.getNetworkId(), stakeKeyHash).toAddress().toBech32().toString();
        throw new Error(`Couldn't resolve reward address from address: ${bech325}`);
    } catch (error) {
        throw new Error(`An error occurred during resolveRewardAddress: ${error}.`);
    }
};
var resolveStakeKeyHash = (bech325)=>{
    try {
        const stakeKeyHash = [
            toBaseAddress(bech325)?.getStakeCredential().hash,
            toRewardAddress(bech325)?.getPaymentCredential().hash
        ].find((kh)=>kh !== void 0);
        if (stakeKeyHash !== void 0) return stakeKeyHash.toString();
        throw new Error(`Couldn't resolve stake key hash from address: ${bech325}`);
    } catch (error) {
        throw new Error(`An error occurred during resolveStakeKeyHash: ${error}.`);
    }
};
var resolveTxHash = (txHex)=>{
    const txBody = deserializeTx(txHex).body();
    const hash2 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blake2b$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__blake2b$3e$__["blake2b"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blake2b$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__blake2b$3e$__["blake2b"].BYTES).update(hexToBytes(txBody.toCbor())).digest();
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].TransactionId.fromHexBlob(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"].fromBytes(hash2)).toString();
};
var resolveScriptHashDRepId = (scriptHash)=>{
    return DRepID.cip129FromCredential({
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].CredentialType.ScriptHash,
        hash: Hash28ByteBase162(scriptHash)
    }).toString();
};
var resolveEd25519KeyHash = (bech325)=>{
    try {
        const keyHash = [
            toBaseAddress(bech325)?.getPaymentCredential().hash,
            toEnterpriseAddress(bech325)?.getPaymentCredential().hash
        ].find((kh)=>kh !== void 0);
        if (keyHash !== void 0) return keyHash.toString();
        throw new Error(`Couldn't resolve key hash from address: ${bech325}`);
    } catch (error) {
        throw new Error(`An error occurred during resolveEd25519KeyHash: ${error}.`);
    }
};
;
;
;
;
;
;
;
;
var toCardanoCert = (cert)=>{
    switch(cert.type){
        case "RegisterPool":
            {
                let relays = [];
                for (const relay of cert.poolParams.relays){
                    switch(relay.type){
                        case "SingleHostAddr":
                            {
                                relays.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Relay.newSingleHostAddr(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].SingleHostAddr(relay.port, relay.IPV4, relay.IPV6)));
                                break;
                            }
                        case "SingleHostName":
                            {
                                relays.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Relay.newSingleHostName(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].SingleHostName(relay.domainName, relay.port)));
                                break;
                            }
                        case "MultiHostName":
                            {
                                relays.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Relay.newMultiHostName(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].MultiHostName(relay.domainName)));
                                break;
                            }
                    }
                }
                let poolOwners = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Hash.fromCore);
                let poolOwnersValues = [
                    ...poolOwners.values()
                ];
                for (const poolOwner of cert.poolParams.owners){
                    poolOwnersValues.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Hash.fromCore(Ed25519KeyHashHex2(poolOwner)));
                }
                poolOwners.setValues(poolOwnersValues);
                const rewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress.fromAddress(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.poolParams.rewardAddress));
                if (rewardAddress === void 0) {
                    throw new Error("Error parsing reward address, it is expected to be in bech32 format");
                }
                const metadata = cert.poolParams.metadata ? new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PoolMetadata(cert.poolParams.metadata.URL, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Hash32ByteBase16"](cert.poolParams.metadata.hash)) : void 0;
                return Certificate.newPoolRegistration(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PoolRegistration(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PoolParams(Ed25519KeyHashHex2(cert.poolParams.operator), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].VrfVkHex(cert.poolParams.vrfKeyHash), BigInt(cert.poolParams.pledge), BigInt(cert.poolParams.cost), new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].UnitInterval(BigInt(cert.poolParams.margin[0]), BigInt(cert.poolParams.margin[1])), rewardAddress, poolOwners, relays, metadata)));
            }
        case "RegisterStake":
            {
                const rewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress.fromAddress(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.stakeKeyAddress));
                if (rewardAddress === void 0) {
                    throw new Error("Error parsing reward address, it is expected to be in bech32 format");
                }
                return Certificate.newStakeRegistration(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeRegistration(rewardAddress.getPaymentCredential()));
            }
        case "DelegateStake":
            {
                const rewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress.fromAddress(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.stakeKeyAddress));
                if (rewardAddress === void 0) {
                    throw new Error("Error parsing reward address, it is expected to be in bech32 format");
                }
                return Certificate.newStakeDelegation(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeDelegation(rewardAddress.getPaymentCredential(), cert.poolId.startsWith("pool1") ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].PoolId.toKeyHash(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].PoolId(cert.poolId)) : Ed25519KeyHashHex2(cert.poolId)));
            }
        case "DeregisterStake":
            {
                const rewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress.fromAddress(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.stakeKeyAddress));
                if (rewardAddress === void 0) {
                    throw new Error("Error parsing reward address, it is expected to be in bech32 format");
                }
                return Certificate.newStakeDeregistration(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeDeregistration(rewardAddress.getPaymentCredential()));
            }
        case "RetirePool":
            {
                return Certificate.newPoolRetirement(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PoolRetirement(cert.poolId.startsWith("pool1") ? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].PoolId.toKeyHash(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].PoolId(cert.poolId)) : Ed25519KeyHashHex2(cert.poolId), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].EpochNo(cert.epoch)));
            }
        case "VoteDelegation":
            {
                const rewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress.fromAddress(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.stakeKeyAddress));
                if (rewardAddress === void 0) {
                    throw new Error("Error parsing reward address, it is expected to be in bech32 format");
                }
                if (cert.drep.dRepId !== void 0) {
                    return Certificate.newVoteDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].VoteDelegation(rewardAddress.getPaymentCredential(), toDRep(cert.drep.dRepId)));
                } else if (cert.drep.alwaysAbstain !== void 0) {
                    return Certificate.newVoteDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].VoteDelegation(rewardAddress.getPaymentCredential(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newAlwaysAbstain()));
                } else if (cert.drep.alwaysNoConfidence !== void 0) {
                    return Certificate.newVoteDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].VoteDelegation(rewardAddress.getPaymentCredential(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newAlwaysNoConfidence()));
                } else {
                    throw new Error("Malformed DRep type");
                }
            }
        case "StakeAndVoteDelegation":
            {
                const rewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress.fromAddress(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.stakeKeyAddress));
                if (rewardAddress === void 0) {
                    throw new Error("Error parsing reward address, it is expected to be in bech32 format");
                }
                if (cert.drep.dRepId !== void 0) {
                    return Certificate.newStakeVoteDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeVoteDelegation(rewardAddress.getPaymentCredential(), toDRep(cert.drep.dRepId), Ed25519KeyHashHex2(cert.poolKeyHash)));
                } else if (cert.drep.alwaysAbstain !== void 0) {
                    return Certificate.newStakeVoteDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeVoteDelegation(rewardAddress.getPaymentCredential(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newAlwaysAbstain(), Ed25519KeyHashHex2(cert.poolKeyHash)));
                } else if (cert.drep.alwaysNoConfidence !== void 0) {
                    return Certificate.newStakeVoteDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeVoteDelegation(rewardAddress.getPaymentCredential(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newAlwaysNoConfidence(), Ed25519KeyHashHex2(cert.poolKeyHash)));
                } else {
                    throw new Error("Malformed DRep type");
                }
            }
        case "StakeRegistrationAndDelegation":
            {
                const rewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress.fromAddress(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.stakeKeyAddress));
                if (rewardAddress === void 0) {
                    throw new Error("Error parsing reward address, it is expected to be in bech32 format");
                }
                return Certificate.newStakeRegistrationDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeRegistrationDelegation(rewardAddress.getPaymentCredential(), BigInt(cert.coin), Ed25519KeyHashHex2(cert.poolKeyHash)));
            }
        case "VoteRegistrationAndDelegation":
            {
                const rewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress.fromAddress(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.stakeKeyAddress));
                if (rewardAddress === void 0) {
                    throw new Error("Error parsing reward address, it is expected to be in bech32 format");
                }
                if (cert.drep.dRepId !== void 0) {
                    return Certificate.newVoteRegistrationDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].VoteRegistrationDelegation(rewardAddress.getPaymentCredential(), BigInt(cert.coin), toDRep(cert.drep.dRepId)));
                } else if (cert.drep.alwaysAbstain !== void 0) {
                    return Certificate.newVoteRegistrationDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].VoteRegistrationDelegation(rewardAddress.getPaymentCredential(), BigInt(cert.coin), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newAlwaysAbstain()));
                } else if (cert.drep.alwaysNoConfidence !== void 0) {
                    return Certificate.newVoteRegistrationDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].VoteRegistrationDelegation(rewardAddress.getPaymentCredential(), BigInt(cert.coin), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newAlwaysNoConfidence()));
                } else {
                    throw new Error("Malformed DRep type");
                }
            }
        case "StakeVoteRegistrationAndDelegation":
            {
                const rewardAddress = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].RewardAddress.fromAddress(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.stakeKeyAddress));
                if (rewardAddress === void 0) {
                    throw new Error("Error parsing reward address, it is expected to be in bech32 format");
                }
                if (cert.drep.dRepId !== void 0) {
                    return Certificate.newStakeVoteDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeVoteDelegation(rewardAddress.getPaymentCredential(), toDRep(cert.drep.dRepId), Ed25519KeyHashHex2(cert.poolKeyHash)));
                } else if (cert.drep.alwaysAbstain !== void 0) {
                    return Certificate.newStakeVoteDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeVoteDelegation(rewardAddress.getPaymentCredential(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newAlwaysAbstain(), Ed25519KeyHashHex2(cert.poolKeyHash)));
                } else if (cert.drep.alwaysNoConfidence !== void 0) {
                    return Certificate.newStakeVoteDelegationCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].StakeVoteDelegation(rewardAddress.getPaymentCredential(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].DRep.newAlwaysNoConfidence(), Ed25519KeyHashHex2(cert.poolKeyHash)));
                } else {
                    throw new Error("Malformed DRep type");
                }
            }
        case "CommitteeHotAuth":
            {
                const hotCred = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.committeeHotKeyAddress).getProps().paymentPart;
                const coldCred = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.committeeColdKeyAddress).getProps().paymentPart;
                if (!hotCred || !coldCred) {
                    throw new Error("Malformed hot/cold credential");
                }
                return Certificate.newAuthCommitteeHotCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].AuthCommitteeHot(coldCred, hotCred));
            }
        case "CommitteeColdResign":
            {
                const coldCred = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].Address.fromBech32(cert.committeeColdKeyAddress).getProps().paymentPart;
                if (!coldCred) {
                    throw new Error("Malformed hot/cold credential");
                }
                let anchor = void 0;
                if (cert.anchor) {
                    anchor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Anchor(cert.anchor.anchorUrl, Hash32ByteBase162(cert.anchor.anchorDataHash));
                }
                return Certificate.newResignCommitteeColdCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].ResignCommitteeCold(coldCred, anchor));
            }
        case "DRepRegistration":
            {
                let anchor = void 0;
                if (cert.anchor) {
                    anchor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Anchor(cert.anchor.anchorUrl, Hash32ByteBase162(cert.anchor.anchorDataHash));
                }
                const coreDRep = toDRep(cert.drepId).toCore();
                if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].isDRepCredential(coreDRep)) {
                    return Certificate.newRegisterDelegateRepresentativeCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].RegisterDelegateRepresentative(coreDRep, BigInt(cert.coin), anchor));
                } else {
                    throw new Error("DRepId must be a Credential");
                }
            }
        case "DRepDeregistration":
            {
                const coreDRep = toDRep(cert.drepId).toCore();
                if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].isDRepCredential(coreDRep)) {
                    return Certificate.newUnregisterDelegateRepresentativeCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].UnregisterDelegateRepresentative(coreDRep, BigInt(cert.coin)));
                } else {
                    throw new Error("DRepId must be a Credential");
                }
            }
        case "DRepUpdate":
            {
                let anchor = void 0;
                if (cert.anchor) {
                    anchor = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Anchor(cert.anchor.anchorUrl, Hash32ByteBase162(cert.anchor.anchorDataHash));
                }
                const coreDRep = toDRep(cert.drepId).toCore();
                if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].isDRepCredential(coreDRep)) {
                    return Certificate.newUpdateDelegateRepresentativeCert(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].UpdateDelegateRepresentative(coreDRep, anchor));
                } else {
                    throw new Error("DRepId must be a Credential");
                }
            }
    }
};
// src/utils/metadata.ts
var toCardanoMetadataMap = (metadata)=>{
    let cardanoMetadataMap = /* @__PURE__ */ new Map();
    metadata.forEach((val, key)=>{
        cardanoMetadataMap.set(key, toCardanoMetadatum(val));
    });
    return cardanoMetadataMap;
};
var toCardanoMetadatum = (metadatum)=>{
    if (typeof metadatum === "number") {
        return TransactionMetadatum.newInteger(BigInt(metadatum));
    } else if (typeof metadatum === "string") {
        return TransactionMetadatum.newText(metadatum);
    } else if (typeof metadatum === "bigint") {
        return TransactionMetadatum.newInteger(metadatum);
    } else if (metadatum instanceof Uint8Array) {
        return TransactionMetadatum.newBytes(metadatum);
    } else if (metadatum instanceof Map) {
        const result = new MetadatumMap();
        metadatum.forEach((value, key)=>{
            result.insert(toCardanoMetadatum(key), toCardanoMetadatum(value));
        });
        return TransactionMetadatum.newMap(result);
    } else if (Array.isArray(metadatum)) {
        const result = new MetadatumList();
        metadatum.forEach((val)=>{
            result.add(toCardanoMetadatum(val));
        });
        return TransactionMetadatum.newList(result);
    } else {
        throw new Error("metadatumToObj: Unsupported Metadatum type");
    }
};
;
;
;
;
var CBOR_EMPTY_MAP = new Uint8Array([
    160
]);
var hashScriptData = (costModels, redemeers, datums)=>{
    const writer = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborWriter();
    if (datums && datums.size() > 0 && (!redemeers || redemeers.size() === 0)) {
        writer.writeEncodedValue(CBOR_EMPTY_MAP);
        writer.writeEncodedValue(Buffer.from(datums.toCbor(), "hex"));
        writer.writeEncodedValue(CBOR_EMPTY_MAP);
    } else {
        if (!redemeers || redemeers.size() === 0) return void 0;
        writer.writeEncodedValue(Buffer.from(redemeers.toCbor(), "hex"));
        if (datums && datums.size() > 0) {
            writer.writeEncodedValue(Buffer.from(datums.toCbor(), "hex"));
        }
        writer.writeEncodedValue(Buffer.from(costModels.languageViewsEncoding(), "hex"));
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$hexTypes$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Hash32ByteBase16"].fromHexBlob(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"].fromBytes(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blake2b$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__blake2b$3e$__["blake2b"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$blake2b$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__default__as__blake2b$3e$__["blake2b"].BYTES).update(writer.encode()).digest()));
};
;
var toCardanoVoter = (voter)=>{
    switch(voter.type){
        case "ConstitutionalCommittee":
            {
                switch(voter.hotCred.type){
                    case "KeyHash":
                        {
                            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Voter.newConstitutionalCommitteeHotKey({
                                type: 0,
                                hash: Hash28ByteBase162(voter.hotCred.keyHash)
                            });
                        }
                    case "ScriptHash":
                        {
                            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Voter.newConstitutionalCommitteeHotKey({
                                type: 1,
                                hash: Hash28ByteBase162(voter.hotCred.scriptHash)
                            });
                        }
                }
            }
        case "DRep":
            {
                const cardanoDrep = toDRep(voter.drepId);
                if (cardanoDrep.toKeyHash() !== void 0) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Voter.newDrep({
                        type: 0,
                        hash: Hash28ByteBase162(cardanoDrep.toKeyHash())
                    });
                } else if (cardanoDrep.toScriptHash() !== void 0) {
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Voter.newDrep({
                        type: 1,
                        hash: Hash28ByteBase162(cardanoDrep.toScriptHash())
                    });
                } else {
                    throw new Error("Invalid DRep provided");
                }
            }
        case "StakingPool":
            {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Voter.newStakingPool(Ed25519KeyHashHex2(voter.keyHash));
            }
    }
};
var toCardanoVotingProcedure = (votingProcedure)=>{
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].VotingProcedure(toCardanoVoteKind(votingProcedure.voteKind), votingProcedure.anchor ? toCardanoAnchor(votingProcedure.anchor) : void 0);
};
var toCardanoAnchor = (anchor)=>{
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Anchor(anchor.anchorUrl, Hash32ByteBase162(anchor.anchorDataHash));
};
var toCardanoVoteKind = (voteType)=>{
    switch(voteType){
        case "Yes":
            {
                return 1;
            }
        case "No":
            {
                return 0;
            }
        case "Abstain":
            {
                return 2;
            }
    }
};
var toCardanoGovernanceActionId = (govActionId)=>{
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].GovernanceActionId(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"].TransactionId(govActionId.txHash), BigInt(govActionId.txIndex));
};
// src/serializer/index.ts
var VKEY_PUBKEY_SIZE_BYTES = 32;
var VKEY_SIGNATURE_SIZE_BYTES = 64;
var CHAIN_CODE_SIZE_BYTES = 32;
var CardanoSDKSerializer = class {
    protocolParams;
    constructor(protocolParams){
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$util$2f$conwayEra$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["setInConwayEra"])(true);
        this.protocolParams = protocolParams || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DEFAULT_PROTOCOL_PARAMETERS"];
    }
    serializeRewardAddress(stakeKeyHash, isScriptHash, network_id) {
        return RewardAddress.fromCredentials(network_id ?? 0, {
            type: isScriptHash ? CredentialType.ScriptHash : CredentialType.KeyHash,
            hash: Hash28ByteBase162(stakeKeyHash)
        }).toAddress().toBech32();
    }
    serializePoolId(hash2) {
        return PoolId.fromKeyHash(Ed25519KeyHashHex2(hash2)).toString();
    }
    serializeAddress(address, networkId) {
        let paymentCred = void 0;
        let stakeCred;
        if (address.pubKeyHash && address.pubKeyHash !== "") {
            paymentCred = {
                type: CredentialType.KeyHash,
                hash: Hash28ByteBase162(address.pubKeyHash)
            };
        } else if (address.scriptHash && address.scriptHash !== "") {
            paymentCred = {
                type: CredentialType.ScriptHash,
                hash: Hash28ByteBase162(address.scriptHash)
            };
        }
        if (address.stakeCredentialHash && address.stakeCredentialHash !== "") {
            stakeCred = {
                type: CredentialType.KeyHash,
                hash: Hash28ByteBase162(address.stakeCredentialHash)
            };
        } else if (address.stakeScriptCredentialHash) {
            stakeCred = {
                type: CredentialType.ScriptHash,
                hash: Hash28ByteBase162(address.stakeScriptCredentialHash)
            };
        }
        let type = AddressType.BasePaymentKeyStakeKey;
        if (paymentCred && stakeCred) {
            if (paymentCred.type === CredentialType.KeyHash && stakeCred.type === CredentialType.KeyHash) {
                type = AddressType.BasePaymentKeyStakeKey;
            } else if (paymentCred.type === CredentialType.KeyHash && stakeCred.type === CredentialType.ScriptHash) {
                type = AddressType.BasePaymentKeyStakeScript;
            } else if (paymentCred.type === CredentialType.ScriptHash && stakeCred.type === CredentialType.KeyHash) {
                type = AddressType.BasePaymentScriptStakeKey;
            } else if (paymentCred.type === CredentialType.ScriptHash && stakeCred.type === CredentialType.ScriptHash) {
                type = AddressType.BasePaymentScriptStakeScript;
            }
        } else if (paymentCred) {
            if (paymentCred.type === CredentialType.KeyHash) {
                type = AddressType.EnterpriseKey;
            } else if (paymentCred.type === CredentialType.ScriptHash) {
                type = AddressType.EnterpriseScript;
            }
        } else if (stakeCred) {
            if (stakeCred.type === CredentialType.KeyHash) {
                type = AddressType.RewardKey;
            } else if (stakeCred.type === CredentialType.ScriptHash) {
                type = AddressType.RewardScript;
            }
        }
        return new Address({
            type,
            networkId: networkId ?? 0,
            paymentPart: paymentCred,
            delegationPart: stakeCred
        }).toBech32();
    }
    serializeData(data) {
        const plutusData = fromBuilderToPlutusData(data);
        return plutusData.toCbor().toString();
    }
    deserializer = {
        key: {
            deserializeAddress: function(bech325) {
                const address = Address.fromBech32(bech325);
                const addressProps = address.getProps();
                return {
                    pubKeyHash: addressProps.paymentPart?.type === CredentialType.KeyHash ? addressProps.paymentPart?.hash ?? "" : "",
                    scriptHash: addressProps.paymentPart?.type === CredentialType.ScriptHash ? addressProps.paymentPart?.hash ?? "" : "",
                    stakeCredentialHash: addressProps.delegationPart?.type === CredentialType.KeyHash ? addressProps.paymentPart?.hash ?? "" : "",
                    stakeScriptCredentialHash: addressProps.delegationPart?.type === CredentialType.ScriptHash ? addressProps.paymentPart?.hash ?? "" : ""
                };
            }
        },
        script: {
            deserializeNativeScript: function(script) {
                const cardanoNativeScript = toNativeScript(script);
                return {
                    scriptHash: cardanoNativeScript.hash().toString(),
                    scriptCbor: cardanoNativeScript.toCbor().toString()
                };
            },
            deserializePlutusScript: function(script) {
                let cardanoPlutusScript;
                switch(script.version){
                    case "V1":
                        {
                            cardanoPlutusScript = new PlutusV1Script((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(script.code));
                            break;
                        }
                    case "V2":
                        {
                            cardanoPlutusScript = new PlutusV2Script((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(script.code));
                            break;
                        }
                    case "V3":
                        {
                            cardanoPlutusScript = new PlutusV3Script((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(script.code));
                            break;
                        }
                }
                return {
                    scriptHash: cardanoPlutusScript.hash().toString(),
                    scriptCbor: cardanoPlutusScript.toCbor().toString()
                };
            }
        },
        cert: {
            deserializePoolId: function(poolId) {
                const cardanoPoolId = PoolId(poolId);
                return PoolId.toKeyHash(cardanoPoolId).toString();
            }
        }
    };
    resolver = {
        keys: {
            resolveStakeKeyHash: function(bech325) {
                const cardanoAddress = toAddress(bech325);
                return cardanoAddress.asReward()?.getPaymentCredential().type === CredentialType.KeyHash ? cardanoAddress.asReward().getPaymentCredential().hash : "";
            },
            resolvePrivateKey: function(words) {
                const buildBip32PrivateKey2 = (entropy2, password = "")=>{
                    return Bip32PrivateKey2.fromBip39Entropy(__TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toBytes"])(entropy2)), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fromUTF8"])(password));
                };
                const entropy = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bip39$2f$src$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["mnemonicToEntropy"])(words.join(" "));
                const bip32PrivateKey = buildBip32PrivateKey2(entropy);
                const bytes = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$base32$2d$encoding$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].encode(bip32PrivateKey.bytes());
                const bech32PrivateKey = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bech32$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["bech32"].encode("xprv", bytes, 1023);
                return bech32PrivateKey;
            },
            resolveRewardAddress: function(bech325) {
                const cardanoAddress = toAddress(bech325);
                const addressProps = cardanoAddress.getProps();
                if (!addressProps.delegationPart) {
                    return "";
                }
                return RewardAddress.fromCredentials(cardanoAddress.getNetworkId(), addressProps.delegationPart).toAddress().toBech32() ?? "";
            },
            resolveEd25519KeyHash: function(bech325) {
                const cardanoAddress = toAddress(bech325);
                const addressProps = cardanoAddress.getProps();
                if (!addressProps.paymentPart) {
                    return "";
                }
                return addressProps.paymentPart.hash.toString();
            }
        },
        tx: {
            resolveTxHash: function(txHex) {
                return Transaction.fromCbor(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TxCBOR(txHex)).getId();
            }
        },
        data: {
            resolveDataHash: function(rawData, type = "Mesh") {
                return resolveDataHash(rawData, type);
            }
        },
        script: {
            resolveScriptRef: function(script) {
                if ("code" in script) {
                    let versionByte;
                    switch(script.version){
                        case "V1":
                            {
                                versionByte = 1;
                                break;
                            }
                        case "V2":
                            {
                                versionByte = 2;
                                break;
                            }
                        case "V3":
                            {
                                versionByte = 3;
                                break;
                            }
                    }
                    let taggedScript = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborTag"](24, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].parse(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborString"].fromCborObj(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborArray"]([
                        new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborUInt"](versionByte),
                        new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborString"](script.code).toCborObj()
                    ])).toBuffer()))));
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(taggedScript).toString();
                } else {
                    const nativeScript = toNativeScript(script);
                    let taggedScript = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborTag"](24, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].parse(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborString"].fromCborObj(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborArray"]([
                        new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborUInt"](0),
                        new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborString"](nativeScript.toCbor()).toCborObj()
                    ])).toBuffer()))));
                    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(taggedScript).toString();
                }
            }
        }
    };
    serializeTxBody = (txBuilderBody, protocolParams)=>{
        const serializerCore = new CardanoSDKSerializerCore(protocolParams ?? this.protocolParams);
        return serializerCore.coreSerializeTx(txBuilderBody);
    };
    serializeTxBodyWithMockSignatures(txBuilderBody, protocolParams) {
        const serializerCore = new CardanoSDKSerializerCore(protocolParams);
        return serializerCore.coreSerializeTxWithMockSignatures(txBuilderBody);
    }
    addSigningKeys = (txHex, signingKeys)=>{
        let cardanoTx = Transaction.fromCbor(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].TxCBOR(txHex));
        let currentWitnessSet = cardanoTx.witnessSet();
        let currentWitnessSetVkeys = currentWitnessSet.vkeys();
        let currentWitnessSetVkeysValues = currentWitnessSetVkeys ? [
            ...currentWitnessSetVkeys.values()
        ] : [];
        for(let i = 0; i < signingKeys.length; i++){
            let keyHex = signingKeys[i];
            if (keyHex) {
                if (keyHex.length === 68 && keyHex.substring(0, 4) === "5820") {
                    keyHex = keyHex.substring(4);
                }
                const cardanoSigner = buildEd25519PrivateKeyFromSecretKey(keyHex);
                const signature = cardanoSigner.sign((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(cardanoTx.getId()));
                currentWitnessSetVkeysValues.push(new VkeyWitness(Ed25519PublicKeyHex2(cardanoSigner.toPublic().hex()), Ed25519SignatureHex2(signature.hex())));
            }
        }
        currentWitnessSet.setVkeys(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore(currentWitnessSetVkeysValues.map((vkw)=>vkw.toCore()), VkeyWitness.fromCore));
        cardanoTx.setWitnessSet(currentWitnessSet);
        return cardanoTx.toCbor();
    };
    serializeValue(value) {
        return toValue(value).toCbor();
    }
    serializeOutput(output) {
        let cardanoOutput = new TransactionOutput(toCardanoAddress(output.address), toValue(output.amount));
        if (output.datum?.type === "Hash") {
            cardanoOutput.setDatum(Datum.newDataHash(fromBuilderToPlutusData(output.datum.data).hash()));
        } else if (output.datum?.type === "Inline") {
            cardanoOutput.setDatum(Datum.newInlineData(fromBuilderToPlutusData(output.datum.data)));
        } else if (output.datum?.type === "Embedded") {
            throw new Error("Embedded datum not supported");
        }
        if (output.referenceScript) {
            switch(output.referenceScript.version){
                case "V1":
                    {
                        cardanoOutput.setScriptRef(Script.newPlutusV1Script(PlutusV1Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(output.referenceScript.code))));
                        break;
                    }
                case "V2":
                    {
                        cardanoOutput.setScriptRef(Script.newPlutusV2Script(PlutusV2Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(output.referenceScript.code))));
                        break;
                    }
                case "V3":
                    {
                        cardanoOutput.setScriptRef(Script.newPlutusV3Script(PlutusV3Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(output.referenceScript.code))));
                        break;
                    }
                default:
                    {
                        cardanoOutput.setScriptRef(Script.newNativeScript(NativeScript.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(output.referenceScript.code))));
                        break;
                    }
            }
        }
        return cardanoOutput.toCbor();
    }
    parser = {
        getRequiredInputs: function(txHex) {
            throw new Error("Function not implemented.");
        },
        parse: function(txHex, resolvedUtxos) {
            throw new Error("Method not implemented.");
        },
        toTester: function() {
            throw new Error("Method not implemented.");
        },
        getBuilderBody: function() {
            throw new Error("Method not implemented.");
        },
        getBuilderBodyWithoutChange: function() {
            throw new Error("Method not implemented.");
        }
    };
};
var CardanoSDKSerializerCore = class {
    txBody;
    txWitnessSet;
    txAuxilliaryData;
    utxoContext = /* @__PURE__ */ new Map();
    mintRedeemers = /* @__PURE__ */ new Map();
    scriptsProvided = /* @__PURE__ */ new Set();
    datumsProvided = /* @__PURE__ */ new Set();
    usedLanguages = {
        [0]: false,
        [1]: false,
        [2]: false
    };
    protocolParams;
    refScriptSize;
    constructor(protocolParams){
        this.protocolParams = protocolParams || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DEFAULT_PROTOCOL_PARAMETERS"];
        this.txBody = new TransactionBody(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], TransactionInput.fromCore), [], BigInt(0), void 0);
        this.refScriptSize = 0;
        this.txWitnessSet = new TransactionWitnessSet();
        this.txAuxilliaryData = new AuxilliaryData();
    }
    coreSerializeTxBody = (txBuilderBody)=>{
        const { inputs, outputs, collaterals, requiredSignatures, referenceInputs, mints, metadata, validityRange, certificates, withdrawals, votes, totalCollateral, collateralReturnAddress, changeAddress } = txBuilderBody;
        const uniqueRefInputs = this.removeBodyInputRefInputOverlap(inputs, referenceInputs);
        try {
            this.addAllInputs(inputs);
        } catch (e) {
            throwErrorWithOrigin("Error serializing inputs", e);
        }
        try {
            this.setFee(txBuilderBody.fee ?? "0");
        } catch (e) {
            throwErrorWithOrigin("Error serializing fee", e);
        }
        try {
            this.sanitizeOutputs(outputs);
        } catch (e) {
            throwErrorWithOrigin("Error calculating min utxo values for outputs", e);
        }
        try {
            this.addAllOutputs(outputs);
        } catch (e) {
            throwErrorWithOrigin("Error serializing outputs", e);
        }
        try {
            this.addAllMints(mints);
        } catch (e) {
            throwErrorWithOrigin("Error serializing mints", e);
        }
        try {
            this.addAllCerts(certificates);
        } catch (e) {
            throwErrorWithOrigin("Error serializing certificates", e);
        }
        try {
            this.addAllWithdrawals(withdrawals);
        } catch (e) {
            throwErrorWithOrigin("Error serializing withdrawals", e);
        }
        try {
            this.addAllVotes(votes);
        } catch (e) {
            throwErrorWithOrigin("Error serializing votes", e);
        }
        try {
            this.addAllCollateralInputs(collaterals);
        } catch (e) {
            throwErrorWithOrigin("Error serializing collateral inputs", e);
        }
        if (totalCollateral) {
            try {
                this.txBody.setTotalCollateral(BigInt(totalCollateral));
                this.addCollateralReturn(totalCollateral, collaterals, collateralReturnAddress ?? changeAddress);
            } catch (e) {
                throwErrorWithOrigin("Error serializing total collateral and collateral return", e);
            }
        }
        try {
            this.addAllReferenceInputs(uniqueRefInputs);
        } catch (e) {
            throwErrorWithOrigin("Error serializing reference inputs", e);
        }
        this.removeInputRefInputOverlap();
        try {
            this.setValidityInterval(validityRange);
        } catch (e) {
            throwErrorWithOrigin("Error serializing validity interval", e);
        }
        try {
            this.addAllRequiredSignatures(requiredSignatures);
        } catch (e) {
            throwErrorWithOrigin("Error serializing required signatures", e);
        }
        if (metadata.size > 0) {
            try {
                this.addMetadata(metadata);
            } catch (e) {
                throwErrorWithOrigin("Error serializing metadata", e);
            }
        }
        return this.txBody;
    };
    coreSerializeTx(txBuilderBody) {
        const bodyCore = this.coreSerializeTxBody(txBuilderBody);
        if (txBuilderBody.fee !== void 0) {
            this.txBody.setFee(BigInt(txBuilderBody.fee));
        }
        this.buildWitnessSet();
        return new Transaction(bodyCore, this.txWitnessSet, this.txAuxilliaryData).toCbor();
    }
    coreSerializeTxWithMockSignatures(txBuilderBody) {
        const bodyCore = this.coreSerializeTxBody(txBuilderBody);
        const mockWitSet = this.createMockedWitnessSet(txBuilderBody.expectedNumberKeyWitnesses, txBuilderBody.expectedByronAddressWitnesses);
        return new Transaction(bodyCore, mockWitSet, this.txAuxilliaryData).toCbor();
    }
    sanitizeOutputs = (outputs)=>{
        for(let i = 0; i < outputs.length; i++){
            let currentOutput = outputs[i];
            let lovelaceFound = false;
            for(let j = 0; j < currentOutput.amount.length; j++){
                let outputAmount = currentOutput.amount[j];
                if (outputAmount?.unit == "" || outputAmount?.unit == "lovelace") {
                    lovelaceFound = true;
                    if (outputAmount?.quantity == "0" || outputAmount?.quantity == "") {
                        outputAmount.unit = "lovelace";
                        outputAmount.quantity = "10000000";
                        let dummyCardanoOutput = this.toCardanoOutput(currentOutput);
                        let minUtxoValue = (160 + dummyCardanoOutput.toCbor().length / 2 + 1) * this.protocolParams.coinsPerUtxoSize;
                        outputAmount.quantity = minUtxoValue.toString();
                    }
                }
            }
            if (!lovelaceFound) {
                let currentAmount = {
                    unit: "lovelace",
                    quantity: "10000000"
                };
                currentOutput.amount.push(currentAmount);
                let dummyCardanoOutput = this.toCardanoOutput(currentOutput);
                let minUtxoValue = (160 + dummyCardanoOutput.toCbor().length / 2 + 1) * this.protocolParams.coinsPerUtxoSize;
                currentAmount.quantity = minUtxoValue.toString();
                if (!lovelaceFound) {
                    let currentAmount2 = {
                        unit: "lovelace",
                        quantity: "10000000"
                    };
                    currentOutput.amount.push(currentAmount2);
                    let dummyCardanoOutput2 = this.toCardanoOutput(currentOutput);
                    let minUtxoValue2 = (160 + dummyCardanoOutput2.toCbor().length / 2 + 1) * this.protocolParams.coinsPerUtxoSize;
                    currentAmount2.quantity = minUtxoValue2.toString();
                }
            }
        }
    };
    addAllInputs = (inputs)=>{
        for(let i = 0; i < inputs.length; i += 1){
            const currentTxIn = inputs[i];
            if (!currentTxIn) continue;
            switch(currentTxIn.type){
                case "PubKey":
                    this.addTxIn(currentTxIn);
                    break;
                case "Script":
                    this.addScriptTxIn(currentTxIn, i);
                    break;
                case "SimpleScript":
                    this.addSimpleScriptTxIn(currentTxIn);
            }
        }
    };
    addTxIn = (currentTxIn)=>{
        let cardanoTxIn = new TransactionInput(TransactionId(currentTxIn.txIn.txHash), BigInt(currentTxIn.txIn.txIndex));
        const inputs = this.txBody.inputs();
        const txInputsList = [
            ...inputs.values()
        ];
        if (txInputsList.find((input)=>{
            input.index() == cardanoTxIn.index() && input.transactionId == cardanoTxIn.transactionId;
        })) {
            throw new Error("Duplicate input added to tx body");
        }
        txInputsList.push(cardanoTxIn);
        inputs.setValues(txInputsList);
        const cardanoTxOut = new TransactionOutput(toCardanoAddress(currentTxIn.txIn.address), toValue(currentTxIn.txIn.amount));
        this.utxoContext.set(cardanoTxIn, cardanoTxOut);
        this.txBody.setInputs(inputs);
        if (currentTxIn.txIn.scriptSize) {
            this.refScriptSize += currentTxIn.txIn.scriptSize;
        }
    };
    addScriptTxIn = (currentTxIn, index)=>{
        this.addTxIn({
            type: "PubKey",
            txIn: currentTxIn.txIn
        });
        if (!currentTxIn.scriptTxIn.scriptSource) {
            throw new Error("A script input had no script source");
        }
        if (!currentTxIn.scriptTxIn.datumSource) {
            throw new Error("A script input had no datum source");
        }
        if (!currentTxIn.scriptTxIn.redeemer) {
            throw new Error("A script input had no redeemer");
        }
        if (currentTxIn.scriptTxIn.scriptSource.type === "Provided") {
            this.addProvidedPlutusScript(currentTxIn.scriptTxIn.scriptSource.script);
        } else if (currentTxIn.scriptTxIn.scriptSource.type === "Inline") {
            this.addScriptRef(currentTxIn.scriptTxIn.scriptSource);
        }
        if (currentTxIn.scriptTxIn.datumSource.type === "Provided") {
            this.datumsProvided.add(fromBuilderToPlutusData(currentTxIn.scriptTxIn.datumSource.data));
        } else if (currentTxIn.scriptTxIn.datumSource.type === "Inline") {
            this.addReferenceInput({
                txHash: currentTxIn.txIn.txHash,
                txIndex: currentTxIn.txIn.txIndex
            });
        }
        let exUnits = currentTxIn.scriptTxIn.redeemer.exUnits;
        let redeemers = this.txWitnessSet.redeemers() ?? Redeemers.fromCore([]);
        let redeemersList = [
            ...redeemers.values()
        ];
        redeemersList.push(new Redeemer(RedeemerTag.Spend, BigInt(index), fromBuilderToPlutusData(currentTxIn.scriptTxIn.redeemer.data), new ExUnits(BigInt(exUnits.mem), BigInt(exUnits.steps))));
        redeemers.setValues(redeemersList);
        this.txWitnessSet.setRedeemers(redeemers);
    };
    addSimpleScriptTxIn = (currentTxIn)=>{
        this.addTxIn({
            type: "PubKey",
            txIn: currentTxIn.txIn
        });
        if (!currentTxIn.simpleScriptTxIn.scriptSource) {
            throw new Error("A native script input had no script source");
        }
        if (currentTxIn.simpleScriptTxIn.scriptSource.type === "Provided") {
            this.scriptsProvided.add(Script.newNativeScript(NativeScript.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(currentTxIn.simpleScriptTxIn.scriptSource.scriptCode))).toCbor());
        } else if (currentTxIn.simpleScriptTxIn.scriptSource.type === "Inline") {
            this.addSimpleScriptRef(currentTxIn.simpleScriptTxIn.scriptSource);
        }
    };
    addAllOutputs = (outputs)=>{
        for(let i = 0; i < outputs.length; i++){
            this.addOutput(outputs[i]);
        }
    };
    addOutput = (output)=>{
        const currentOutputs = this.txBody.outputs();
        currentOutputs.push(this.toCardanoOutput(output));
        this.txBody.setOutputs(currentOutputs);
    };
    toCardanoOutput = (output)=>{
        let cardanoOutput = new TransactionOutput(toCardanoAddress(output.address), toValue(output.amount));
        if (output.datum?.type === "Hash") {
            cardanoOutput.setDatum(Datum.newDataHash(DatumHash(fromBuilderToPlutusData(output.datum.data).hash())));
        } else if (output.datum?.type === "Inline") {
            cardanoOutput.setDatum(Datum.newInlineData(fromBuilderToPlutusData(output.datum.data)));
        } else if (output.datum?.type === "Embedded") {
            const currentWitnessDatum = this.txWitnessSet.plutusData() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].PlutusData.fromCore);
            const currentWitnessDatumValues = [
                ...currentWitnessDatum.values()
            ];
            currentWitnessDatumValues.push(fromBuilderToPlutusData(output.datum.data));
            currentWitnessDatum.setValues(currentWitnessDatumValues);
            this.txWitnessSet.setPlutusData(currentWitnessDatum);
        }
        if (output.referenceScript) {
            switch(output.referenceScript.version){
                case "V1":
                    {
                        cardanoOutput.setScriptRef(Script.newPlutusV1Script(PlutusV1Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(output.referenceScript.code))));
                        break;
                    }
                case "V2":
                    {
                        cardanoOutput.setScriptRef(Script.newPlutusV2Script(PlutusV2Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(output.referenceScript.code))));
                        break;
                    }
                case "V3":
                    {
                        cardanoOutput.setScriptRef(Script.newPlutusV3Script(PlutusV3Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(output.referenceScript.code))));
                        break;
                    }
            }
        }
        return cardanoOutput;
    };
    addAllReferenceInputs = (refInputs)=>{
        for(let i = 0; i < refInputs.length; i++){
            this.addReferenceInput(refInputs[i]);
        }
    };
    addReferenceInput = (refInput)=>{
        let referenceInputs = this.txBody.referenceInputs() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], TransactionInput.fromCore);
        let referenceInputsList = [
            ...referenceInputs.values()
        ];
        if (referenceInputsList.some((input)=>input.transactionId().toString() === refInput.txHash && input.index().toString() === refInput.txIndex.toString())) return;
        referenceInputsList.push(new TransactionInput(TransactionId(refInput.txHash), BigInt(refInput.txIndex)));
        referenceInputs.setValues(referenceInputsList);
        if (refInput.scriptSize) {
            this.refScriptSize += refInput.scriptSize;
        }
        this.txBody.setReferenceInputs(referenceInputs);
    };
    addAllMints = (mints)=>{
        for(let i2 = 0; i2 < mints.length; i2++){
            this.addMint(mints[i2]);
        }
        let redeemers = this.txWitnessSet.redeemers() ?? Redeemers.fromCore([]);
        let redeemersList = [
            ...redeemers.values()
        ];
        let i = 0;
        this.mintRedeemers.forEach((redeemer)=>{
            const newRedeemer = new Redeemer(redeemer.tag(), BigInt(i), redeemer.data(), redeemer.exUnits());
            redeemersList.push(newRedeemer);
            redeemers.setValues(redeemersList);
            i++;
        });
        this.txWitnessSet.setRedeemers(redeemers);
    };
    addMint = (mint)=>{
        const currentMint = this.txBody.mint() ?? /* @__PURE__ */ new Map();
        for (const assetValue of mint.mintValue){
            const mintAssetId = `${mint.policyId}${assetValue.assetName}`;
            for (const asset of currentMint.keys()){
                if (asset.toString() == mintAssetId) {
                    throw new Error("The same asset is already in the mint field");
                }
            }
            currentMint.set(AssetId.fromParts(PolicyId(mint.policyId), AssetName(assetValue.assetName)), BigInt(assetValue.amount));
        }
        this.txBody.setMint(currentMint);
        if (mint.type === "Native") {
            if (!mint.scriptSource) throw new Error("Script source not provided for native script mint");
            const nativeScriptSource = mint.scriptSource;
            if (!nativeScriptSource) throw new Error("A script source for a native script was not a native script somehow");
            if (nativeScriptSource.type === "Provided") {
                this.scriptsProvided.add(Script.newNativeScript(NativeScript.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(nativeScriptSource.scriptCode))).toCbor());
            } else if (nativeScriptSource.type === "Inline") {
                this.addSimpleScriptRef(nativeScriptSource);
            }
        } else if (mint.type === "Plutus") {
            if (!mint.scriptSource) throw new Error("Script source not provided for plutus script mint");
            const plutusScriptSource = mint.scriptSource;
            if (!plutusScriptSource) {
                throw new Error("A script source for a plutus mint was not plutus script somehow");
            }
            if (!mint.redeemer) {
                throw new Error("A redeemer was not provided for a plutus mint");
            }
            const currentRedeemer = new Redeemer(RedeemerTag.Mint, BigInt(0), fromBuilderToPlutusData(mint.redeemer.data), new ExUnits(BigInt(mint.redeemer.exUnits.mem), BigInt(mint.redeemer.exUnits.steps)));
            if (this.mintRedeemers.has(mint.policyId)) {
                if (this.mintRedeemers.get(mint.policyId)?.toCbor() !== currentRedeemer.toCbor()) {
                    throw new Error("The same minting policy must have the same redeemer");
                }
            } else {
                this.mintRedeemers.set(mint.policyId, currentRedeemer);
            }
            if (plutusScriptSource.type === "Provided") {
                this.addProvidedPlutusScript(plutusScriptSource.script);
            } else if (plutusScriptSource.type === "Inline") {
                this.addScriptRef(plutusScriptSource);
            }
        }
    };
    addAllCerts = (certs)=>{
        for(let i = 0; i < certs.length; i++){
            this.addCert(certs[i], i);
        }
    };
    addCert = (cert, index)=>{
        const currentCerts = this.txBody.certs() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Certificate.fromCore);
        let currentCertsValues = [
            ...currentCerts.values()
        ];
        currentCertsValues.push(toCardanoCert(cert.certType));
        currentCerts.setValues(currentCertsValues);
        this.txBody.setCerts(currentCerts);
        if (cert.type === "SimpleScriptCertificate") {
            if (!cert.simpleScriptSource) throw new Error("Script source not provided for native script cert");
            const nativeScriptSource = cert.simpleScriptSource;
            if (!nativeScriptSource) throw new Error("A script source for a native script was not a native script somehow");
            if (nativeScriptSource.type === "Provided") {
                this.scriptsProvided.add(Script.newNativeScript(NativeScript.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(nativeScriptSource.scriptCode))).toCbor());
            } else if (nativeScriptSource.type === "Inline") {
                this.addSimpleScriptRef(nativeScriptSource);
            }
        } else if (cert.type === "ScriptCertificate") {
            if (!cert.scriptSource) throw new Error("Script source not provided for plutus script certificate");
            const plutusScriptSource = cert.scriptSource;
            if (!plutusScriptSource) {
                throw new Error("A script source for a plutus certificate was not plutus script somehow");
            }
            if (!cert.redeemer) {
                throw new Error("A redeemer was not provided for a plutus certificate");
            }
            let redeemers = this.txWitnessSet.redeemers() ?? Redeemers.fromCore([]);
            let redeemersList = [
                ...redeemers.values()
            ];
            redeemersList.push(new Redeemer(RedeemerTag.Cert, BigInt(index), fromBuilderToPlutusData(cert.redeemer.data), new ExUnits(BigInt(cert.redeemer.exUnits.mem), BigInt(cert.redeemer.exUnits.steps))));
            redeemers.setValues(redeemersList);
            this.txWitnessSet.setRedeemers(redeemers);
            if (plutusScriptSource.type === "Provided") {
                this.addProvidedPlutusScript(plutusScriptSource.script);
            } else if (plutusScriptSource.type === "Inline") {
                this.addScriptRef(plutusScriptSource);
            }
        }
    };
    addAllWithdrawals = (withdrawals)=>{
        for(let i = 0; i < withdrawals.length; i++){
            this.addWithdrawal(withdrawals[i], i);
        }
    };
    addWithdrawal = (withdrawal, index)=>{
        const currentWithdrawals = this.txBody.withdrawals() ?? /* @__PURE__ */ new Map();
        const address = toCardanoAddress(withdrawal.address);
        const rewardAddress = address.asReward();
        if (!rewardAddress) {
            throw new Error("Failed to parse reward address for withdrawal");
        }
        currentWithdrawals.set(RewardAccount.fromCredential(rewardAddress.getPaymentCredential(), address.getNetworkId()), BigInt(withdrawal.coin));
        this.txBody.setWithdrawals(currentWithdrawals);
        if (withdrawal.type === "SimpleScriptWithdrawal") {
            if (!withdrawal.scriptSource) throw new Error("Script source not provided for native script cert");
            const nativeScriptSource = withdrawal.scriptSource;
            if (!nativeScriptSource) throw new Error("A script source for a native script was not a native script somehow");
            if (nativeScriptSource.type === "Provided") {
                this.scriptsProvided.add(Script.newNativeScript(NativeScript.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(nativeScriptSource.scriptCode))).toCbor());
            } else if (nativeScriptSource.type === "Inline") {
                this.addSimpleScriptRef(nativeScriptSource);
            }
        } else if (withdrawal.type === "ScriptWithdrawal") {
            if (!withdrawal.scriptSource) throw new Error("Script source not provided for plutus script certificate");
            const plutusScriptSource = withdrawal.scriptSource;
            if (!plutusScriptSource) {
                throw new Error("A script source for a plutus certificate was not plutus script somehow");
            }
            if (!withdrawal.redeemer) {
                throw new Error("A redeemer was not provided for a plutus certificate");
            }
            let redeemers = this.txWitnessSet.redeemers() ?? Redeemers.fromCore([]);
            let redeemersList = [
                ...redeemers.values()
            ];
            redeemersList.push(new Redeemer(RedeemerTag.Reward, BigInt(index), fromBuilderToPlutusData(withdrawal.redeemer.data), new ExUnits(BigInt(withdrawal.redeemer.exUnits.mem), BigInt(withdrawal.redeemer.exUnits.steps))));
            redeemers.setValues(redeemersList);
            this.txWitnessSet.setRedeemers(redeemers);
            if (plutusScriptSource.type === "Provided") {
                this.addProvidedPlutusScript(plutusScriptSource.script);
            } else if (plutusScriptSource.type === "Inline") {
                this.addScriptRef(plutusScriptSource);
            }
        }
    };
    addAllCollateralInputs = (collaterals)=>{
        for(let i = 0; i < collaterals.length; i++){
            this.addCollateralInput(collaterals[i]);
        }
    };
    addCollateralInput = (collateral)=>{
        let cardanoTxIn = new TransactionInput(TransactionId(collateral.txIn.txHash), BigInt(collateral.txIn.txIndex));
        const collateralInputs = this.txBody.collateral() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], TransactionInput.fromCore);
        const collateralInputsList = [
            ...collateralInputs.values()
        ];
        if (collateralInputsList.find((input)=>{
            input.index() == cardanoTxIn.index() && input.transactionId == cardanoTxIn.transactionId;
        })) {
            throw new Error("Duplicate input added to tx body");
        }
        collateralInputsList.push(cardanoTxIn);
        collateralInputs.setValues(collateralInputsList);
        const cardanoTxOut = new TransactionOutput(toCardanoAddress(collateral.txIn.address), toValue(collateral.txIn.amount));
        this.utxoContext.set(cardanoTxIn, cardanoTxOut);
        this.txBody.setCollateral(collateralInputs);
    };
    addCollateralReturn = (totalCollateral, collaterals, collateralReturnAddress)=>{
        let collateralReturnValue = Value.fromCore({
            coins: -BigInt(totalCollateral)
        });
        for (const collateral of collaterals){
            collateralReturnValue = mergeValue(collateralReturnValue, toValue(collateral.txIn.amount));
        }
        const collateralReturn = new TransactionOutput(toCardanoAddress(collateralReturnAddress), collateralReturnValue);
        this.txBody.setCollateralReturn(collateralReturn);
    };
    setValidityInterval = (validity)=>{
        if (validity.invalidBefore) {
            this.txBody.setValidityStartInterval(Slot(validity.invalidBefore));
        }
        if (validity.invalidHereafter) {
            this.txBody.setTtl(Slot(validity.invalidHereafter));
        }
    };
    setFee = (fee)=>{
        this.txBody.setFee(BigInt(fee));
    };
    addAllRequiredSignatures = (requiredSignatures)=>{
        const requiredSigners = this.txBody.requiredSigners() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Hash.fromCore);
        let requiredSignerValues = [
            ...requiredSigners.values()
        ];
        for (const requiredSigner of requiredSignatures){
            requiredSignerValues.push(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Hash.fromCore(Ed25519KeyHashHex2(requiredSigner)));
        }
        requiredSigners.setValues(requiredSignerValues);
        this.txBody.setRequiredSigners(requiredSigners);
    };
    addMetadata = (metadata)=>{
        this.txAuxilliaryData.setMetadata(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].GeneralTransactionMetadata(toCardanoMetadataMap(metadata)));
    };
    createMockedWitnessSet = (requiredSignaturesCount, requiredByronSignatures)=>{
        this.buildWitnessSet();
        const clonedWitnessSet = TransactionWitnessSet.fromCbor(this.txWitnessSet.toCbor());
        const bootstrapWitnesses = this.mockBootstrapWitnesses(requiredByronSignatures);
        const vkeyWitnesses = this.mockVkeyWitnesses(requiredSignaturesCount);
        const bootstrapsSet = CborSet.fromCore([], BootstrapWitness.fromCore);
        bootstrapsSet.setValues(bootstrapWitnesses);
        clonedWitnessSet.setBootstraps(bootstrapsSet);
        const vkeysSet = CborSet.fromCore([], VkeyWitness.fromCore);
        vkeysSet.setValues(vkeyWitnesses);
        clonedWitnessSet.setVkeys(vkeysSet);
        return clonedWitnessSet;
    };
    buildWitnessSet = ()=>{
        let nativeScripts = this.txWitnessSet.nativeScripts() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], NativeScript.fromCore);
        let v1Scripts = this.txWitnessSet.plutusV1Scripts() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], PlutusV1Script.fromCore);
        let v2Scripts = this.txWitnessSet.plutusV2Scripts() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], PlutusV2Script.fromCore);
        let v3Scripts = this.txWitnessSet.plutusV3Scripts() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], PlutusV3Script.fromCore);
        this.scriptsProvided.forEach((scriptHex)=>{
            const script = Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(scriptHex));
            if (script.asNative() !== void 0) {
                let nativeScriptsList = [
                    ...nativeScripts.values()
                ];
                nativeScriptsList.push(script.asNative());
                nativeScripts.setValues(nativeScriptsList);
            } else if (script.asPlutusV1() !== void 0) {
                let v1ScriptsList = [
                    ...v1Scripts.values()
                ];
                v1ScriptsList.push(script.asPlutusV1());
                v1Scripts.setValues(v1ScriptsList);
            } else if (script.asPlutusV2() !== void 0) {
                let v2ScriptsList = [
                    ...v2Scripts.values()
                ];
                v2ScriptsList.push(script.asPlutusV2());
                v2Scripts.setValues(v2ScriptsList);
            } else if (script.asPlutusV3() !== void 0) {
                let v3ScriptsList = [
                    ...v3Scripts.values()
                ];
                v3ScriptsList.push(script.asPlutusV3());
                v3Scripts.setValues(v3ScriptsList);
            }
            this.txWitnessSet.setNativeScripts(nativeScripts);
            this.txWitnessSet.setPlutusV1Scripts(v1Scripts);
            this.txWitnessSet.setPlutusV2Scripts(v2Scripts);
            this.txWitnessSet.setPlutusV3Scripts(v3Scripts);
        });
        let datums = this.txWitnessSet.plutusData() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore([], PlutusData.fromCore);
        let datumsList = [
            ...datums.values()
        ];
        this.datumsProvided.forEach((datum)=>{
            datumsList.push(datum);
        });
        datums.setValues(datumsList);
        this.txWitnessSet.setPlutusData(datums);
        let costModelV1 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CostModel.newPlutusV1(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DEFAULT_V1_COST_MODEL_LIST"]);
        let costModelV2 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CostModel.newPlutusV2(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DEFAULT_V2_COST_MODEL_LIST"]);
        let costModelV3 = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CostModel.newPlutusV3(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$common$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DEFAULT_V3_COST_MODEL_LIST"]);
        let costModels = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].Costmdls();
        if (this.usedLanguages[PlutusLanguageVersion.V1]) {
            costModels.insert(costModelV1);
        }
        if (this.usedLanguages[PlutusLanguageVersion.V2]) {
            costModels.insert(costModelV2);
        }
        if (this.usedLanguages[PlutusLanguageVersion.V3]) {
            costModels.insert(costModelV3);
        }
        const redeemers = this.txWitnessSet.redeemers() ?? Redeemers.fromCore([]);
        let scriptDataHash = hashScriptData(costModels, redeemers, datums.size() > 0 ? datums : void 0);
        if (scriptDataHash) {
            this.txBody.setScriptDataHash(scriptDataHash);
        }
        let auxiliaryDataHash = computeAuxiliaryDataHash(this.txAuxilliaryData.toCore());
        if (auxiliaryDataHash) {
            this.txBody.setAuxiliaryDataHash(auxiliaryDataHash);
        }
    };
    removeInputRefInputOverlap = ()=>{
        let refInputsValues = [];
        const inputs = this.txBody.inputs()?.values();
        if (this.txBody.referenceInputs()) {
            const currentRefInputValues = this.txBody.referenceInputs().values();
            currentRefInputValues.forEach((refInput)=>{
                let found = false;
                for(let i = 0; i < inputs.length; i++){
                    if (refInput.toCbor() === inputs[i].toCbor()) {
                        found = true;
                    }
                }
                if (!found) {
                    refInputsValues.push(refInput);
                }
            });
            this.txBody.setReferenceInputs(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].CborSet.fromCore(refInputsValues.map((input)=>input.toCore()), TransactionInput.fromCore));
        }
    };
    removeBodyInputRefInputOverlap = (inputs, refInputs)=>{
        let finalRefInputs = [];
        for(let i = 0; i < refInputs.length; i++){
            let refInput = refInputs[i];
            if (!inputs.some((input)=>input.txIn.txHash === refInput.txHash && input.txIn.txIndex === refInput.txIndex)) {
                finalRefInputs.push(refInput);
            }
        }
        return finalRefInputs;
    };
    addScriptRef = (scriptSource)=>{
        if (scriptSource.type !== "Inline") {
            return;
        }
        if (!scriptSource.scriptSize) {
            throw new Error("A reference script was used without providing its size, this must be provided as fee calculations are based on it");
        }
        this.addReferenceInput({
            txHash: scriptSource.txHash,
            txIndex: scriptSource.txIndex,
            scriptSize: Number(scriptSource.scriptSize)
        });
        switch(scriptSource.version){
            case "V1":
                {
                    this.usedLanguages[PlutusLanguageVersion.V1] = true;
                    break;
                }
            case "V2":
                {
                    this.usedLanguages[PlutusLanguageVersion.V2] = true;
                    break;
                }
            case "V3":
                {
                    this.usedLanguages[PlutusLanguageVersion.V3] = true;
                    break;
                }
        }
    };
    addSimpleScriptRef = (simpleScriptSource)=>{
        if (simpleScriptSource.type !== "Inline") {
            return;
        }
        if (!simpleScriptSource.scriptSize) {
            throw new Error("A reference script was used without providing its size, this must be provided as fee calculations are based on it");
        }
        this.addReferenceInput({
            txHash: simpleScriptSource.txHash,
            txIndex: simpleScriptSource.txIndex,
            scriptSize: Number(simpleScriptSource.scriptSize)
        });
    };
    addProvidedPlutusScript = (script)=>{
        switch(script.version){
            case "V1":
                {
                    this.scriptsProvided.add(Script.newPlutusV1Script(PlutusV1Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(script.code))).toCbor());
                    this.usedLanguages[PlutusLanguageVersion.V1] = true;
                    break;
                }
            case "V2":
                {
                    this.scriptsProvided.add(Script.newPlutusV2Script(PlutusV2Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(script.code))).toCbor());
                    this.usedLanguages[PlutusLanguageVersion.V2] = true;
                    break;
                }
            case "V3":
                {
                    this.scriptsProvided.add(Script.newPlutusV3Script(PlutusV3Script.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(script.code))).toCbor());
                    this.usedLanguages[PlutusLanguageVersion.V3] = true;
                    break;
                }
        }
    };
    addAllVotes = (votes)=>{
        for(let i = 0; i < votes.length; i++){
            const vote = votes[i];
            switch(vote.type){
                case "BasicVote":
                    {
                        this.addBasicVote(vote);
                        break;
                    }
                case "ScriptVote":
                    {
                        this.addScriptVote(vote, i);
                        break;
                    }
                case "SimpleScriptVote":
                    {
                        this.addSimpleScriptVote(vote);
                        break;
                    }
            }
        }
    };
    addBasicVote = (basicVote)=>{
        const votes = this.txBody.votingProcedures() ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"].VotingProcedures.fromCore([]);
        votes.insert(toCardanoVoter(basicVote.vote.voter), toCardanoGovernanceActionId(basicVote.vote.govActionId), toCardanoVotingProcedure(basicVote.vote.votingProcedure));
        this.txBody.setVotingProcedures(votes);
    };
    addScriptVote = (vote, index)=>{
        if (!vote.scriptSource) throw new Error("Script source not provided for plutus script vote");
        const plutusScriptSource = vote.scriptSource;
        if (!plutusScriptSource) {
            throw new Error("A script source for a plutus certificate was not plutus script somehow");
        }
        if (!vote.redeemer) {
            throw new Error("A redeemer was not provided for a plutus vote");
        }
        let redeemers = this.txWitnessSet.redeemers() ?? Redeemers.fromCore([]);
        let redeemersList = [
            ...redeemers.values()
        ];
        redeemersList.push(new Redeemer(RedeemerTag.Voting, BigInt(index), fromBuilderToPlutusData(vote.redeemer.data), new ExUnits(BigInt(vote.redeemer.exUnits.mem), BigInt(vote.redeemer.exUnits.steps))));
        redeemers.setValues(redeemersList);
        this.txWitnessSet.setRedeemers(redeemers);
        if (plutusScriptSource.type === "Provided") {
            this.addProvidedPlutusScript(plutusScriptSource.script);
        } else if (plutusScriptSource.type === "Inline") {
            this.addScriptRef(plutusScriptSource);
        }
        this.addBasicVote({
            type: "BasicVote",
            vote: vote.vote
        });
    };
    addSimpleScriptVote = (vote)=>{
        if (!vote.simpleScriptSource) throw new Error("Script source not provided for native script vote");
        const nativeScriptSource = vote.simpleScriptSource;
        if (!nativeScriptSource) throw new Error("A script source for a native script was not a native script somehow");
        if (nativeScriptSource.type === "Provided") {
            this.scriptsProvided.add(Script.newNativeScript(NativeScript.fromCbor((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(nativeScriptSource.scriptCode))).toCbor());
        } else if (nativeScriptSource.type === "Inline") {
            this.addSimpleScriptRef(nativeScriptSource);
        }
        this.addBasicVote({
            type: "BasicVote",
            vote: vote.vote
        });
    };
    mockVkeyWitnesses = (numberOfRequiredWitnesses)=>{
        let vkeyWitnesses = [];
        for(let i = 0; i < numberOfRequiredWitnesses; i++){
            const numberInHex = this.numberToIntegerHex(i);
            const pubKeyHex = this.mockPubkey(numberInHex);
            const signature = this.mockSignature(numberInHex);
            vkeyWitnesses.push(new VkeyWitness(Ed25519PublicKeyHex2(pubKeyHex), Ed25519SignatureHex2(signature)));
        }
        return vkeyWitnesses;
    };
    mockPubkey(numberInHex) {
        return "0".repeat(VKEY_PUBKEY_SIZE_BYTES * 2 - numberInHex.length).concat(numberInHex);
    }
    mockSignature(numberInHex) {
        return "0".repeat(VKEY_SIGNATURE_SIZE_BYTES * 2 - numberInHex.length).concat(numberInHex);
    }
    mockChainCode = (numberInHex)=>{
        return "0".repeat(CHAIN_CODE_SIZE_BYTES * 2 - numberInHex.length).concat(numberInHex);
    };
    numberToIntegerHex = (number)=>{
        return BigInt(number).toString(16);
    };
    mockBootstrapWitnesses = (byronAddresses)=>{
        let bootstrapWitnesses = [];
        for(let i = 0; i < byronAddresses.length; i++){
            const address = Address.fromBytes(byronAddresses[i]).asByron();
            if (!address) {
                throw new Error(`Failed to parse byron address: ${byronAddresses[i]}`);
            }
            const numberInHex = this.numberToIntegerHex(i);
            const pubKeyHex = this.mockPubkey(numberInHex);
            const signature = this.mockSignature(numberInHex);
            const chainCode = this.mockChainCode(numberInHex);
            const attributes = address.getAttributes();
            bootstrapWitnesses.push(new BootstrapWitness(Ed25519PublicKeyHex2(pubKeyHex), Ed25519SignatureHex2(signature), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$primitives$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["HexBlob"])(chainCode), this.serializeByronAttributes(attributes)));
        }
        return bootstrapWitnesses;
    };
    serializeByronAttributes = (attributes)=>{
        const writer = new CborWriter();
        let mapSize = 0;
        if (attributes.magic) {
            mapSize++;
        }
        if (attributes.derivationPath) {
            mapSize++;
        }
        writer.writeStartMap(mapSize);
        if (attributes.derivationPath) {
            writer.writeInt(1);
            const encodedPathCbor = new CborWriter().writeByteString(__TURBOPACK__imported__module__$5b$externals$5d2f$buffer__$5b$external$5d$__$28$buffer$2c$__cjs$29$__["Buffer"].from(attributes.derivationPath, "hex")).encode();
            writer.writeByteString(encodedPathCbor);
        }
        if (attributes.magic) {
            writer.writeInt(2);
            const encodedMagicCbor = new CborWriter().writeInt(attributes.magic).encode();
            writer.writeByteString(encodedMagicCbor);
        }
        return writer.encodeAsHex();
    };
};
var throwErrorWithOrigin = (origin, error)=>{
    if (error instanceof Error) {
        throw new Error(`${origin}: ${error.message}`);
    } else if (typeof error === "string") {
        throw new Error(`${origin}: ${error}`);
    } else if (typeof error === "object") {
        throw new Error(`${origin}: ${JSON.stringify(error)}`);
    } else {
        throw new Error(`${origin}: ${String(error)}`);
    }
};
;
;
;
var supportedPlutusCoreVersions = [
    {
        version: [
            1,
            0,
            0
        ],
        language: "Plutus V1"
    },
    {
        version: [
            1,
            1,
            0
        ],
        language: "Plutus V3"
    }
];
var applyArgsToPlutusScript = (args, program, outputEncoding)=>{
    const purePlutusBytes = getPurePlutusBytes(program);
    const parsedProgram = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$uplc$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseUPLC"])(purePlutusBytes, "flat");
    const decodedArgs = args.map((arg)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$plutus$2d$data$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dataFromCbor"])(arg));
    let body = parsedProgram.body;
    for (const plutusData of decodedArgs){
        const argTerm = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$uplc$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UPLCConst"].data(plutusData);
        body = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$uplc$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Application"](body, argTerm);
    }
    const encodedProgram = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$uplc$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["UPLCProgram"](parsedProgram.version, body);
    const newPlutusScriptBytes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$uplc$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["encodeUPLC"])(encodedProgram).toBuffer().buffer;
    return applyEncoding(newPlutusScriptBytes, outputEncoding);
};
var normalizePlutusScript = (plutusScript, encoding)=>{
    const bytes = Buffer.from(plutusScript, "hex");
    const purePlutusBytes = getPurePlutusBytes(bytes);
    const normalizedBytes = applyEncoding(purePlutusBytes, encoding);
    return Buffer.from(normalizedBytes).toString("hex");
};
var hasSupportedPlutusVersion = (plutusScript)=>{
    if (plutusScript.length < 3) {
        return false;
    }
    const version = [
        plutusScript[0],
        plutusScript[1],
        plutusScript[2]
    ];
    return supportedPlutusCoreVersions.some((supportedVersion)=>{
        return supportedVersion.version[0] === version[0] && supportedVersion.version[1] === version[1] && supportedVersion.version[2] === version[2];
    });
};
var getPurePlutusBytes = (plutusScript)=>{
    let unwrappedScript = plutusScript;
    let length = 0;
    try {
        while(unwrappedScript.length >= 3 && length != unwrappedScript.length){
            length = unwrappedScript.length;
            if (hasSupportedPlutusVersion(unwrappedScript)) {
                return unwrappedScript;
            }
            const cbor = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].parse(unwrappedScript);
            if (cbor instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"]) {
                unwrappedScript = cbor.bytes;
            } else {
                break;
            }
        }
    } catch (error) {
        console.error("Error parsing Plutus script:", error);
    }
    if (hasSupportedPlutusVersion(unwrappedScript)) {
        return unwrappedScript;
    }
    throw new Error("Unsupported Plutus version or invalid Plutus script bytes");
};
var applyCborEncoding = (plutusScript)=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Cbor"].encode(new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$harmoniclabs$2f$cbor$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CborBytes"](plutusScript)).toBuffer();
};
var applyEncoding = (plutusScript, outputEncoding)=>{
    switch(outputEncoding){
        case "SingleCBOR":
            return applyCborEncoding(plutusScript);
        case "DoubleCBOR":
            return applyCborEncoding(applyCborEncoding(plutusScript));
        case "PurePlutusScriptBytes":
            return plutusScript;
        default:
            return applyCborEncoding(plutusScript);
    }
};
var applyParamsToScript = (rawScript, params, type = "Mesh")=>{
    let plutusParams = [];
    switch(type){
        case "JSON":
            params.forEach((param)=>{
                plutusParams.push(fromBuilderToPlutusData({
                    type: "JSON",
                    content: param
                }));
            });
            break;
        case "CBOR":
            params.forEach((param)=>{
                plutusParams.push(fromBuilderToPlutusData({
                    type: "CBOR",
                    content: param
                }));
            });
            break;
        case "Mesh":
            params.forEach((param)=>{
                plutusParams.push(fromBuilderToPlutusData({
                    type: "Mesh",
                    content: param
                }));
            });
            break;
    }
    const byteParams = plutusParams.map((param)=>{
        return Buffer.from(param.toCbor(), "hex");
    });
    const scriptHex = Buffer.from(applyArgsToPlutusScript(byteParams, Buffer.from(rawScript, "hex"), "DoubleCBOR")).toString("hex");
    return scriptHex;
};
;
;
;
;
}),
"[project]/node_modules/@meshsdk/core/node_modules/@meshsdk/core-cst/dist/index.js [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Address",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Address"],
    "AddressType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AddressType"],
    "AssetFingerprint",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AssetFingerprint"],
    "AssetId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AssetId"],
    "AssetName",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AssetName"],
    "AuxilliaryData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AuxilliaryData"],
    "BaseAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BaseAddress"],
    "Bip32PrivateKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Bip32PrivateKey"],
    "Bip32PrivateKeyHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Bip32PrivateKeyHex"],
    "Bip32PublicKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Bip32PublicKey"],
    "Bip32PublicKeyHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Bip32PublicKeyHex"],
    "BootstrapWitness",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["BootstrapWitness"],
    "Cardano",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__["Cardano"],
    "CardanoSDK",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__,
    "CardanoSDKSerializer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CardanoSDKSerializer"],
    "CardanoSDKUtil",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__,
    "CborSet",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CborSet"],
    "CborWriter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CborWriter"],
    "CertIndex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CertIndex"],
    "Certificate",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Certificate"],
    "CertificateType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CertificateType"],
    "ConstrPlutusData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ConstrPlutusData"],
    "CoseSign1",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CoseSign1"],
    "CostModel",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CostModel"],
    "Costmdls",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Costmdls"],
    "Credential",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Credential"],
    "CredentialType",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["CredentialType"],
    "Crypto",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__,
    "DRep",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DRep"],
    "DRepID",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DRepID"],
    "Datum",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Datum"],
    "DatumHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DatumHash"],
    "DatumKind",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["DatumKind"],
    "Ed25519KeyHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Ed25519KeyHash"],
    "Ed25519KeyHashHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Ed25519KeyHashHex"],
    "Ed25519PrivateExtendedKeyHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Ed25519PrivateExtendedKeyHex"],
    "Ed25519PrivateKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Ed25519PrivateKey"],
    "Ed25519PrivateNormalKeyHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Ed25519PrivateNormalKeyHex"],
    "Ed25519PublicKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Ed25519PublicKey"],
    "Ed25519PublicKeyHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Ed25519PublicKeyHex"],
    "Ed25519Signature",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Ed25519Signature"],
    "Ed25519SignatureHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Ed25519SignatureHex"],
    "EnterpriseAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["EnterpriseAddress"],
    "ExUnits",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ExUnits"],
    "Hash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Hash"],
    "Hash28ByteBase16",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Hash28ByteBase16"],
    "Hash32ByteBase16",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Hash32ByteBase16"],
    "HexBlob",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["HexBlob"],
    "MetadatumList",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["MetadatumList"],
    "MetadatumMap",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["MetadatumMap"],
    "NativeScript",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["NativeScript"],
    "NetworkId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["NetworkId"],
    "PaymentAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PaymentAddress"],
    "PlutusData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PlutusData"],
    "PlutusDataKind",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PlutusDataKind"],
    "PlutusLanguageVersion",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PlutusLanguageVersion"],
    "PlutusList",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PlutusList"],
    "PlutusMap",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PlutusMap"],
    "PlutusV1Script",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PlutusV1Script"],
    "PlutusV2Script",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PlutusV2Script"],
    "PlutusV3Script",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PlutusV3Script"],
    "PointerAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PointerAddress"],
    "PolicyId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PolicyId"],
    "PoolId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["PoolId"],
    "Redeemer",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Redeemer"],
    "RedeemerPurpose",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RedeemerPurpose"],
    "RedeemerTag",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RedeemerTag"],
    "Redeemers",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Redeemers"],
    "RequireAllOf",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RequireAllOf"],
    "RequireAnyOf",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RequireAnyOf"],
    "RequireNOf",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RequireNOf"],
    "RequireSignature",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RequireSignature"],
    "RequireTimeAfter",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RequireTimeAfter"],
    "RequireTimeBefore",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RequireTimeBefore"],
    "RewardAccount",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RewardAccount"],
    "RewardAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["RewardAddress"],
    "Script",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Script"],
    "ScriptHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ScriptHash"],
    "ScriptPubkey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ScriptPubkey"],
    "Serialization",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__["Serialization"],
    "Slot",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Slot"],
    "StakeCredentialStatus",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["StakeCredentialStatus"],
    "StakeDelegation",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["StakeDelegation"],
    "StakeRegistration",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["StakeRegistration"],
    "Transaction",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Transaction"],
    "TransactionBody",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TransactionBody"],
    "TransactionId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TransactionId"],
    "TransactionInput",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TransactionInput"],
    "TransactionMetadatum",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TransactionMetadatum"],
    "TransactionOutput",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TransactionOutput"],
    "TransactionUnspentOutput",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TransactionUnspentOutput"],
    "TransactionWitnessSet",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TransactionWitnessSet"],
    "TxCBOR",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TxCBOR"],
    "TxIndex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["TxIndex"],
    "Value",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["Value"],
    "VkeyWitness",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["VkeyWitness"],
    "VrfVkBech32",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["VrfVkBech32"],
    "addVKeyWitnessSetToTransaction",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addVKeyWitnessSetToTransaction"],
    "addrBech32ToPlutusDataHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addrBech32ToPlutusDataHex"],
    "addrBech32ToPlutusDataObj",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addrBech32ToPlutusDataObj"],
    "addressToBech32",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["addressToBech32"],
    "applyEncoding",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["applyEncoding"],
    "applyParamsToScript",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["applyParamsToScript"],
    "assetTypes",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["assetTypes"],
    "blake2b",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["blake2b"],
    "buildBaseAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildBaseAddress"],
    "buildBip32PrivateKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildBip32PrivateKey"],
    "buildDRepID",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildDRepID"],
    "buildEd25519PrivateKeyFromSecretKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildEd25519PrivateKeyFromSecretKey"],
    "buildEnterpriseAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildEnterpriseAddress"],
    "buildKeys",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildKeys"],
    "buildRewardAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildRewardAddress"],
    "buildScriptPubkey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["buildScriptPubkey"],
    "bytesToHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["bytesToHex"],
    "calculateFees",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["calculateFees"],
    "checkSignature",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["checkSignature"],
    "clampScalar",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["clampScalar"],
    "computeAuxiliaryDataHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["computeAuxiliaryDataHash"],
    "deserializeAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeAddress"],
    "deserializeBech32Address",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeBech32Address"],
    "deserializeDataHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeDataHash"],
    "deserializeEd25519KeyHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeEd25519KeyHash"],
    "deserializeNativeScript",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeNativeScript"],
    "deserializePlutusData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializePlutusData"],
    "deserializePlutusScript",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializePlutusScript"],
    "deserializeScriptHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeScriptHash"],
    "deserializeScriptRef",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeScriptRef"],
    "deserializeTx",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeTx"],
    "deserializeTxHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeTxHash"],
    "deserializeTxUnspentOutput",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeTxUnspentOutput"],
    "deserializeValue",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["deserializeValue"],
    "empty",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["empty"],
    "fromBuilderToPlutusData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fromBuilderToPlutusData"],
    "fromJsonToPlutusData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fromJsonToPlutusData"],
    "fromNativeScript",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fromNativeScript"],
    "fromPlutusDataToJson",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fromPlutusDataToJson"],
    "fromScriptRef",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fromScriptRef"],
    "fromTxUnspentOutput",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fromTxUnspentOutput"],
    "fromValue",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["fromValue"],
    "generateNonce",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateNonce"],
    "getCoseKeyFromPublicKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getCoseKeyFromPublicKey"],
    "getDRepIds",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getDRepIds"],
    "getPublicKeyFromCoseKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getPublicKeyFromCoseKey"],
    "hexToBech32",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["hexToBech32"],
    "hexToBytes",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["hexToBytes"],
    "keyHashToRewardAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["keyHashToRewardAddress"],
    "mergeValue",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["mergeValue"],
    "negateValue",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["negateValue"],
    "negatives",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["negatives"],
    "normalizePlutusScript",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["normalizePlutusScript"],
    "parseDatumCbor",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseDatumCbor"],
    "parseInlineDatum",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseInlineDatum"],
    "resolveDataHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolveDataHash"],
    "resolveEd25519KeyHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolveEd25519KeyHash"],
    "resolveNativeScriptAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolveNativeScriptAddress"],
    "resolveNativeScriptHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolveNativeScriptHash"],
    "resolvePaymentKeyHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolvePaymentKeyHash"],
    "resolvePlutusScriptAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolvePlutusScriptAddress"],
    "resolvePlutusScriptHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolvePlutusScriptHash"],
    "resolvePoolId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolvePoolId"],
    "resolvePrivateKey",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolvePrivateKey"],
    "resolveRewardAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolveRewardAddress"],
    "resolveScriptHashDRepId",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolveScriptHashDRepId"],
    "resolveScriptRef",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolveScriptRef"],
    "resolveStakeKeyHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolveStakeKeyHash"],
    "resolveTxHash",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolveTxHash"],
    "scriptHashToBech32",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["scriptHashToBech32"],
    "scriptHashToRewardAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["scriptHashToRewardAddress"],
    "serializeAddressObj",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["serializeAddressObj"],
    "serializePlutusAddressToBech32",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["serializePlutusAddressToBech32"],
    "serialzeAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["serialzeAddress"],
    "signData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["signData"],
    "subValue",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["subValue"],
    "toAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toAddress"],
    "toBaseAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toBaseAddress"],
    "toCardanoAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toCardanoAddress"],
    "toDRep",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toDRep"],
    "toEnterpriseAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toEnterpriseAddress"],
    "toNativeScript",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toNativeScript"],
    "toPlutusData",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toPlutusData"],
    "toRewardAddress",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toRewardAddress"],
    "toScriptRef",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toScriptRef"],
    "toTxUnspentOutput",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toTxUnspentOutput"],
    "toValue",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["toValue"],
    "utf8ToBytes",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["utf8ToBytes"],
    "utf8ToHex",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["utf8ToHex"],
    "v2ScriptToBech32",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__["v2ScriptToBech32"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$core$2d$cst$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/core/node_modules/@meshsdk/core-cst/dist/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Cardano$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Cardano$3e$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/core/dist/esm/Cardano/index.js [app-ssr] (ecmascript) <export * as Cardano>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$Serialization$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__Serialization$3e$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/core/dist/esm/Serialization/index.js [app-ssr] (ecmascript) <export * as Serialization>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$util$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/util/dist/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$crypto$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/crypto/dist/esm/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$cardano$2d$sdk$2f$core$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@cardano-sdk/core/dist/esm/index.js [app-ssr] (ecmascript)");
}),
];

//# sourceMappingURL=8e012_%40meshsdk_core-cst_dist_index_76952616.js.map