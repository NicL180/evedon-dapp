module.exports = [
"[project]/app/send/SendClient.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SendClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/react/dist/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/core/dist/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$transaction$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/core/node_modules/@meshsdk/transaction/dist/index.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
// ---------- helpers ----------
function adaToLovelace(ada) {
    const n = Number(ada);
    if (!Number.isFinite(n) || n <= 0) return null;
    return Math.round(n * 1_000_000).toString(); // 1 ADA = 1,000,000 lovelace
}
function networkName(id) {
    if (id === 1) return 'Mainnet';
    if (id === 0) return 'Testnet';
    return 'Unknown';
}
// Accept hex string OR Uint8Array OR number[] (some CIP-30 impls)
function toBytes(v) {
    if (typeof v === 'string') {
        const clean = v.startsWith('0x') ? v.slice(2) : v;
        const out = new Uint8Array(clean.length / 2);
        for(let i = 0; i < out.length; i++)out[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
        return out;
    }
    if (v instanceof Uint8Array) return v;
    if (Array.isArray(v)) return Uint8Array.from(v);
    if (v && typeof v === 'object' && typeof v.hex === 'string') {
        return toBytes(v.hex);
    }
    throw new Error('Unsupported UTxO byte format');
}
function SendClient() {
    const { connected, name, wallet } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useWallet"])(); // wallet is Mesh BrowserWallet wrapper
    const netId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useNetwork"])();
    const hookLovelace = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useLovelace"])(); // fallback display if live calc isn't ready yet
    // Live balance (from UTxOs) + refresh state
    const [liveLovelace, setLiveLovelace] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [refreshing, setRefreshing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // Form/UI state
    const [to, setTo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [ada, setAda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('');
    const [allowSubmit, setAllowSubmit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [message, setMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [txHash, setTxHash] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [signedCbor, setSignedCbor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const explorerBase = netId === 1 ? 'https://cardanoscan.io' : 'https://preprod.cardanoscan.io';
    const placeholder = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>netId === 1 ? 'addr1... (Mainnet address)' : 'addr_test1... (Testnet address)', [
        netId
    ]);
    // Human-readable balances
    const hookAdaText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (hookLovelace == null) return null;
        const n = typeof hookLovelace === 'string' ? Number(hookLovelace) : hookLovelace;
        return Number.isFinite(n) ? (n / 1_000_000).toFixed(6) : null;
    }, [
        hookLovelace
    ]);
    const liveAdaText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        if (liveLovelace == null) return null;
        return (Number(liveLovelace) / 1_000_000).toFixed(6);
    }, [
        liveLovelace
    ]);
    const displayAdaText = liveAdaText ?? hookAdaText;
    // ---------- LIVE BALANCE: supports CIP-30 (hex/bytes) and Mesh (objects) ----------
    async function computeLiveBalanceFromUtxos(apiOrWallet) {
        const utxos = await apiOrWallet.getUtxos();
        if (!utxos?.length) return 0n;
        // Path A: CIP-30 style (hex/bytes array)
        const first = utxos[0];
        if (typeof first === 'string' || first instanceof Uint8Array || Array.isArray(first) || first && typeof first === 'object' && typeof first.hex === 'string') {
            const CSL = await __turbopack_context__.A("[project]/node_modules/@emurgo/cardano-serialization-lib-browser/cardano_serialization_lib.js [app-ssr] (ecmascript, async loader)");
            let sum = 0n;
            for (const raw of utxos){
                const bytes = toBytes(raw);
                const utxo = CSL.TransactionUnspentOutput.from_bytes(bytes);
                const coin = BigInt(utxo.output().amount().coin().to_str());
                sum += coin;
            }
            return sum;
        }
        // Path B: Mesh BrowserWallet style (objects with output.amount[])
        let sum = 0n;
        for (const u of utxos){
            const amounts = u?.output?.amount;
            const q = BigInt(amounts?.find((a)=>a.unit === 'lovelace')?.quantity ?? '0');
            sum += q;
        }
        return sum;
    }
    async function refreshBalance() {
        if (!connected || !wallet) return;
        setRefreshing(true);
        try {
            const sum = await computeLiveBalanceFromUtxos(wallet);
            setLiveLovelace(sum);
        } catch (e) {
            console.error('[balance] refresh error', e);
        } finally{
            setRefreshing(false);
        }
    }
    // Initial + on wallet (dis)connect
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (connected && wallet) refreshBalance();
        else setLiveLovelace(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        connected,
        wallet
    ]);
    // Clear messages on form changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setMessage(null);
        setTxHash(null);
        setSignedCbor(null);
    }, [
        to,
        ada,
        allowSubmit,
        connected
    ]);
    // ---------- SEND ----------
    async function handleSend(e) {
        e.preventDefault();
        setMessage(null);
        setTxHash(null);
        setSignedCbor(null);
        if (!connected) return setMessage('Please connect a wallet (top-right) first.');
        if (!wallet) return setMessage('Wallet API unavailable. Try reconnecting your wallet.');
        if (!to || !ada) return setMessage('Enter a recipient address and an ADA amount.');
        const lovelaceOut = adaToLovelace(ada);
        if (!lovelaceOut) return setMessage('Amount must be a positive number.');
        // Quick address/network hint
        const isTestAddr = to.startsWith('addr_test');
        if (netId === 1 && isTestAddr) return setMessage('Recipient looks Testnet but wallet is on Mainnet.');
        if (netId === 0 && !isTestAddr) return setMessage('Recipient looks Mainnet but wallet is on Testnet.');
        // Pre-check with headroom (~0.3 ADA for fees)
        const have = Number(displayAdaText ?? '0');
        const want = Number(ada);
        if (Number.isFinite(have) && Number.isFinite(want) && want + 0.3 > have) {
            return setMessage(`Amount + fees likely exceeds your wallet balance (${have.toFixed(6)} ADA). ` + `Try a smaller amount or refresh/fund again.`);
        }
        setBusy(true);
        try {
            const tx = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$transaction$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Transaction"]({
                initiator: wallet
            });
            tx.sendLovelace(to, lovelaceOut);
            const unsigned = await tx.build();
            const signed = await wallet.signTx(unsigned);
            setSignedCbor(signed);
            if (!allowSubmit) {
                setMessage(`Built & signed successfully in SAFE mode. (Not submitted). Toggle "I understand" to enable submit.`);
                await refreshBalance(); // show it hasn't changed in safe mode
                return;
            }
            const hash = await wallet.submitTx(signed);
            setTxHash(hash);
            setMessage('✅ Submitted successfully.');
            // Refresh balance now and after a short delay to catch new UTxOs
            await refreshBalance();
            setTimeout(refreshBalance, 5_000);
            setTimeout(refreshBalance, 15_000);
        } catch (err) {
            console.error(err);
            setMessage(err?.message ?? 'Failed to build/sign/submit. Check the address, amount, and that your wallet has enough ADA.');
        } finally{
            setBusy(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            maxWidth: 760,
            margin: '2rem auto',
            padding: '1rem'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    border: '1px solid rgba(43,111,255,0.30)',
                    background: 'rgba(43,111,255,0.06)',
                    borderRadius: 14,
                    padding: '1.25rem'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        style: {
                            marginTop: 0
                        },
                        children: "Send ADA"
                    }, void 0, false, {
                        fileName: "[project]/app/send/SendClient.tsx",
                        lineNumber: 208,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            marginTop: 0,
                            opacity: 0.9,
                            display: 'flex',
                            gap: 8,
                            alignItems: 'center',
                            flexWrap: 'wrap'
                        },
                        children: [
                            "Network: ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: networkName(netId)
                            }, void 0, false, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 221,
                                columnNumber: 20
                            }, this),
                            " · Wallet:",
                            ' ',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: connected ? name ?? 'Wallet' : '—'
                            }, void 0, false, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 222,
                                columnNumber: 11
                            }, this),
                            displayAdaText != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    ' ',
                                    "· Balance: ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                        children: [
                                            displayAdaText,
                                            " ADA"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/send/SendClient.tsx",
                                        lineNumber: 226,
                                        columnNumber: 26
                                    }, this)
                                ]
                            }, void 0, true),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: refreshBalance,
                                disabled: !connected || refreshing,
                                style: {
                                    marginLeft: 'auto',
                                    padding: '6px 10px',
                                    borderRadius: 10,
                                    border: '1px solid rgba(127,179,255,0.35)',
                                    background: '#0a1020',
                                    color: '#7fb3ff',
                                    cursor: refreshing ? 'wait' : 'pointer'
                                },
                                title: "Refresh balance from UTxOs",
                                children: refreshing ? 'Refreshing…' : '↻ Refresh'
                            }, void 0, false, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 229,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/send/SendClient.tsx",
                        lineNumber: 211,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        onSubmit: handleSend,
                        style: {
                            display: 'grid',
                            gap: '0.75rem'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                style: {
                                    display: 'grid',
                                    gap: 6
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Recipient address"
                                    }, void 0, false, {
                                        fileName: "[project]/app/send/SendClient.tsx",
                                        lineNumber: 249,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: to,
                                        onChange: (e)=>setTo(e.target.value.trim()),
                                        placeholder: placeholder,
                                        spellCheck: false,
                                        style: {
                                            padding: '10px 12px',
                                            borderRadius: 10,
                                            border: '1px solid rgba(127,179,255,0.35)',
                                            background: '#0a1020',
                                            color: '#d6e7ff',
                                            fontFamily: 'monospace'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/send/SendClient.tsx",
                                        lineNumber: 250,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 248,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                style: {
                                    display: 'grid',
                                    gap: 6
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "Amount (ADA)"
                                    }, void 0, false, {
                                        fileName: "[project]/app/send/SendClient.tsx",
                                        lineNumber: 267,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        value: ada,
                                        onChange: (e)=>setAda(e.target.value),
                                        placeholder: "e.g., 1.0",
                                        inputMode: "decimal",
                                        style: {
                                            padding: '10px 12px',
                                            borderRadius: 10,
                                            border: '1px solid rgba(127,179,255,0.35)',
                                            background: '#0a1020',
                                            color: '#d6e7ff',
                                            fontFamily: 'monospace'
                                        }
                                    }, void 0, false, {
                                        fileName: "[project]/app/send/SendClient.tsx",
                                        lineNumber: 268,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 266,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                style: {
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: 8
                                },
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "checkbox",
                                        checked: allowSubmit,
                                        onChange: (e)=>setAllowSubmit(e.target.checked)
                                    }, void 0, false, {
                                        fileName: "[project]/app/send/SendClient.tsx",
                                        lineNumber: 285,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: [
                                            "I understand this will ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                                children: "broadcast"
                                            }, void 0, false, {
                                                fileName: "[project]/app/send/SendClient.tsx",
                                                lineNumber: 291,
                                                columnNumber: 38
                                            }, this),
                                            " on ",
                                            networkName(netId),
                                            " (remove safe mode)."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/send/SendClient.tsx",
                                        lineNumber: 290,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 284,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                disabled: busy,
                                style: {
                                    padding: '10px 14px',
                                    borderRadius: 12,
                                    border: '2px solid #2b6fff',
                                    background: busy ? '#132039' : '#0a1020',
                                    color: '#7fb3ff',
                                    fontWeight: 800,
                                    cursor: busy ? 'not-allowed' : 'pointer'
                                },
                                children: allowSubmit ? busy ? 'Submitting…' : 'Submit (real send)' : busy ? 'Building…' : 'Build (safe)'
                            }, void 0, false, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 295,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/send/SendClient.tsx",
                        lineNumber: 247,
                        columnNumber: 9
                    }, this),
                    message && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            marginTop: '1rem',
                            padding: '10px 12px',
                            borderRadius: 10,
                            border: '1px solid rgba(127,179,255,0.35)',
                            background: 'rgba(43,111,255,0.06)',
                            color: '#cfe5ff',
                            whiteSpace: 'pre-wrap'
                        },
                        children: message
                    }, void 0, false, {
                        fileName: "[project]/app/send/SendClient.tsx",
                        lineNumber: 313,
                        columnNumber: 11
                    }, this),
                    txHash && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        style: {
                            marginTop: '0.75rem'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: "Tx Hash:"
                            }, void 0, false, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 330,
                                columnNumber: 13
                            }, this),
                            " ",
                            txHash,
                            ' · ',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: `${explorerBase}/transaction/${txHash}`,
                                target: "_blank",
                                rel: "noreferrer",
                                style: {
                                    color: '#7fb3ff',
                                    textDecoration: 'underline'
                                },
                                children: "View on Cardanoscan"
                            }, void 0, false, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 332,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/send/SendClient.tsx",
                        lineNumber: 329,
                        columnNumber: 11
                    }, this),
                    signedCbor && !allowSubmit && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("details", {
                        style: {
                            marginTop: '0.75rem'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("summary", {
                                children: "View signed CBOR (safe mode)"
                            }, void 0, false, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 345,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("pre", {
                                style: {
                                    whiteSpace: 'pre-wrap',
                                    overflowX: 'auto',
                                    padding: '8px',
                                    background: '#07101f',
                                    borderRadius: 8,
                                    border: '1px solid rgba(127,179,255,0.25)',
                                    color: '#cfe5ff'
                                },
                                children: signedCbor
                            }, void 0, false, {
                                fileName: "[project]/app/send/SendClient.tsx",
                                lineNumber: 346,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/send/SendClient.tsx",
                        lineNumber: 344,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/send/SendClient.tsx",
                lineNumber: 200,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                style: {
                    opacity: 0.75,
                    marginTop: '0.75rem'
                },
                children: [
                    "Tip: Start with ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                        children: "1.0 ADA"
                    }, void 0, false, {
                        fileName: "[project]/app/send/SendClient.tsx",
                        lineNumber: 364,
                        columnNumber: 25
                    }, this),
                    " to leave room for fees/min-UTxO. Use the ↻ button if the balance looks stale."
                ]
            }, void 0, true, {
                fileName: "[project]/app/send/SendClient.tsx",
                lineNumber: 363,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/send/SendClient.tsx",
        lineNumber: 199,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=app_send_SendClient_tsx_c1f13e7c._.js.map