module.exports = [
"[project]/app/scripts/sig/ScriptSigClient.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ScriptSigClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/react/dist/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/core/dist/index.js [app-ssr] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$provider$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/provider/dist/index.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$transaction$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@meshsdk/core/node_modules/@meshsdk/transaction/dist/index.js [app-ssr] (ecmascript)");
'use client';
;
;
;
;
// ---------- helpers ----------
const hrp = (netId)=>netId === 1 ? 'addr' : 'addr_test';
const toHex = (u8)=>Array.from(u8).map((b)=>b.toString(16).padStart(2, '0')).join('');
function toBytes(v) {
    if (typeof v === 'string') {
        if (v.startsWith('addr')) throw new Error('BECH32_STRING');
        const clean = v.startsWith('0x') ? v.slice(2) : v;
        if (!/^[0-9a-fA-F]+$/.test(clean)) throw new Error('Not hex');
        const out = new Uint8Array(clean.length / 2);
        for(let i = 0; i < out.length; i++)out[i] = parseInt(clean.slice(i * 2, i * 2 + 2), 16);
        return out;
    }
    if (v instanceof Uint8Array) return v;
    if (Array.isArray(v)) return Uint8Array.from(v);
    if (v && typeof v === 'object' && typeof v.hex === 'string') return toBytes(v.hex);
    throw new Error('Unsupported address data');
}
const niceErr = (e)=>e?.info?.error?.message || e?.info?.message || e?.message || 'Failed to build/sign/submit.';
function ScriptSigClient() {
    const { connected, name, wallet } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useWallet"])(); // CIP-30
    const netId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$react$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useNetwork"])();
    const [baseBech, setBaseBech] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [keyHashHex, setKeyHashHex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [scriptCbor, setScriptCbor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [scriptAddr, setScriptAddr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [availableAda, setAvailableAda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [safeMaxAda, setSafeMaxAda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [amountAda, setAmountAda] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])('1.0'); // recommend >= 1.0 ADA
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    const [msg, setMsg] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [txHash, setTxHash] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const explorerBase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>netId === 1 ? 'https://cardanoscan.io' : 'https://preprod.cardanoscan.io', [
        netId
    ]);
    const cexplorerBase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>netId === 1 ? 'https://cexplorer.io' : 'https://preprod.cexplorer.io', [
        netId
    ]);
    // Use Blockfrost for UTxOs (avoid wallet privacy limits)
    const provider = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$provider$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["BlockfrostProvider"](("TURBOPACK compile-time value", "preprodQZsckZ9BaefNzLGS5k4NO8d2keCSNkea") || ''), []);
    // 1) Derive base address, key hash, native script, and script address
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let cancelled = false;
        (async ()=>{
            try {
                if (!connected || !wallet) return;
                const CSL = await __turbopack_context__.A("[project]/node_modules/@emurgo/cardano-serialization-lib-browser/cardano_serialization_lib.js [app-ssr] (ecmascript, async loader)");
                // read a wallet address (bech32 or bytes/hex)
                let raw = null;
                try {
                    raw = await wallet.getChangeAddress();
                } catch  {}
                if (!raw) {
                    const used = await wallet.getUsedAddresses().catch(()=>[]);
                    if (used?.length) raw = used[0];
                }
                if (!raw) return;
                let addr;
                if (typeof raw === 'string' && raw.startsWith('addr')) {
                    addr = CSL.Address.from_bech32(raw);
                } else {
                    addr = CSL.Address.from_bytes(toBytes(raw));
                }
                const bech = addr.to_bech32(hrp(netId));
                if (cancelled) return;
                setBaseBech(bech);
                // payment credential from Base | Enterprise | Pointer
                let cred = null;
                const base = CSL.BaseAddress.from_address(addr);
                if (base) cred = base.payment_cred();
                if (!cred) {
                    const ent = CSL.EnterpriseAddress.from_address(addr);
                    if (ent) cred = ent.payment_cred();
                }
                if (!cred) {
                    const ptr = CSL.PointerAddress.from_address(addr);
                    if (ptr) cred = ptr.payment_cred();
                }
                if (!cred) throw new Error('Unsupported address kind');
                const kh = cred.to_keyhash();
                const pkhHex = toHex(kh.to_bytes());
                setKeyHashHex(pkhHex);
                // native script (signature)
                const pub = CSL.ScriptPubkey.new(kh);
                const ns = CSL.NativeScript.new_script_pubkey(pub);
                setScriptCbor(toHex(ns.to_bytes()));
                // script address (enterprise via Credential API)
                const networkTag = netId === 1 ? 1 : 0;
                const scrCred = CSL.Credential.from_scripthash(ns.hash());
                const entAddr = CSL.EnterpriseAddress.new(networkTag, scrCred).to_address();
                setScriptAddr(entAddr.to_bech32(hrp(netId)));
            } catch (e) {
                console.error('[sig] init', e);
            }
        })();
        return ()=>{
            cancelled = true;
        };
    }, [
        connected,
        wallet,
        netId
    ]);
    // 2) Fetch wallet balance (via Blockfrost) and compute SAFE MAX
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        let cancelled = false;
        (async ()=>{
            try {
                if (!baseBech) return;
                const utxos = await provider.fetchAddressUTxOs(baseBech);
                const sum = utxos.reduce((acc, u)=>{
                    const q = Number(u.output.amount.find((a)=>a.unit === 'lovelace')?.quantity ?? '0');
                    return acc + q;
                }, 0);
                const ada = sum / 1_000_000;
                if (cancelled) return;
                setAvailableAda(ada);
                // SAFE MAX: leave 0.8 ADA or 10% buffer for fees/change/min-UTxO
                const buffer = Math.max(0.8, ada * 0.10);
                setSafeMaxAda(Number(Math.max(0, ada - buffer).toFixed(6)));
            } catch (e) {
                console.error('[sig] balance', e);
            }
        })();
        return ()=>{
            cancelled = true;
        };
    }, [
        baseBech,
        provider
    ]);
    // 3) Build & submit using EXPLICIT UTxOs from Blockfrost (not the wallet)
    async function lockFunds(e) {
        e.preventDefault();
        setMsg(null);
        setTxHash(null);
        if (!connected || !wallet) {
            setMsg('Connect your wallet first.');
            return;
        }
        if (!scriptAddr || !baseBech) {
            setMsg('Addresses not ready yet.');
            return;
        }
        const amt = Number(amountAda);
        if (!Number.isFinite(amt) || amt <= 0) {
            setMsg('Enter a positive ADA amount.');
            return;
        }
        if (amt < 1.0) {
            setMsg('Use ≥ 1.0 ADA to satisfy min-UTxO at the script address.');
            return;
        }
        if (safeMaxAda !== null && amt > safeMaxAda) {
            setMsg(`Amount too high. Safe max ~${safeMaxAda.toFixed(6)} ADA. Try the “Use max” button.`);
            return;
        }
        setBusy(true);
        try {
            const changeHex = await wallet.getChangeAddress();
            const want = Math.round(amt * 1_000_000);
            // Fetch UTxOs and pick enough to cover output + fee buffer (~1.5 ADA)
            const utxos = await provider.fetchAddressUTxOs(baseBech);
            const sorted = [
                ...utxos
            ].sort((a, b)=>Number(b.output.amount.find((x)=>x.unit === 'lovelace')?.quantity ?? '0') - Number(a.output.amount.find((x)=>x.unit === 'lovelace')?.quantity ?? '0'));
            const need = want + 1_500_000; // 1.5 ADA fee/change buffer
            let picked = [];
            let total = 0;
            for (const u of sorted){
                const q = Number(u.output.amount.find((x)=>x.unit === 'lovelace')?.quantity ?? '0');
                picked.push(u);
                total += q;
                if (total >= need) break;
            }
            if (total < need) {
                throw new Error('Not enough ADA in selected UTxOs. Try a smaller amount.');
            }
            // Build with explicit inputs
            const txb = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$meshsdk$2f$core$2f$node_modules$2f40$meshsdk$2f$transaction$2f$dist$2f$index$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MeshTxBuilder"]({
                fetcher: provider,
                verbose: true
            });
            txb.setNetwork('preprod');
            // add picked inputs
            for (const u of picked){
                txb.txIn(u.input.txHash, u.input.outputIndex, u.output.amount, u.output.address);
            }
            // output to script + change back to wallet
            txb.txOut(String(scriptAddr), [
                {
                    unit: 'lovelace',
                    quantity: String(want)
                }
            ]).changeAddress(changeHex);
            const unsigned = await txb.complete(); // no wallet selection needed now
            const signed = await wallet.signTx(unsigned);
            const hash = await wallet.submitTx(signed);
            setTxHash(hash);
            setMsg('✅ Submitted lock tx.');
            // refresh displayed balance (after brief indexing delay)
            setTimeout(async ()=>{
                try {
                    const list = await provider.fetchAddressUTxOs(baseBech);
                    const sum = list.reduce((acc, u)=>{
                        const q = Number(u.output.amount.find((a)=>a.unit === 'lovelace')?.quantity ?? '0');
                        return acc + q;
                    }, 0);
                    const ada = sum / 1_000_000;
                    setAvailableAda(ada);
                    const buffer = Math.max(0.8, ada * 0.10);
                    setSafeMaxAda(Number(Math.max(0, ada - buffer).toFixed(6)));
                } catch  {}
            }, 1500);
        } catch (err) {
            console.error('[lock] error', err);
            setMsg(niceErr(err));
        } finally{
            setBusy(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            maxWidth: 860,
            margin: '2rem auto',
            padding: '1rem'
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                children: "Native Script (Signature) — Lock tADA"
            }, void 0, false, {
                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                lineNumber: 228,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                style: {
                    opacity: 0.85
                },
                children: [
                    "Network: ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                        children: netId === 1 ? 'Mainnet' : 'Preprod Testnet'
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 230,
                        columnNumber: 18
                    }, this),
                    " · Wallet: ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                        children: connected ? name ?? 'Wallet' : '—'
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 230,
                        columnNumber: 81
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                lineNumber: 229,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    display: 'grid',
                    gap: 10,
                    border: '1px solid #345',
                    borderRadius: 12,
                    padding: 12
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: "Your base address:"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 234,
                                columnNumber: 14
                            }, this),
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                children: baseBech ?? '—'
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 234,
                                columnNumber: 40
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 234,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: "Payment key hash:"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 235,
                                columnNumber: 14
                            }, this),
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                children: keyHashHex ?? '—'
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 235,
                                columnNumber: 39
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 235,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: "Native script (CBOR hex):"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 236,
                                columnNumber: 14
                            }, this),
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                style: {
                                    wordBreak: 'break-all'
                                },
                                children: scriptCbor ?? '—'
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 236,
                                columnNumber: 47
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 236,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                children: "Script address:"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 237,
                                columnNumber: 14
                            }, this),
                            " ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                children: scriptAddr ?? '—'
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 237,
                                columnNumber: 37
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 237,
                        columnNumber: 9
                    }, this),
                    baseBech && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: `${explorerBase}/address/${baseBech}`,
                            target: "_blank",
                            rel: "noreferrer",
                            style: {
                                color: '#7fb3ff',
                                textDecoration: 'underline'
                            },
                            children: "View base address on explorer"
                        }, void 0, false, {
                            fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                            lineNumber: 240,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 239,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                lineNumber: 233,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                onSubmit: lockFunds,
                style: {
                    marginTop: 14,
                    display: 'grid',
                    gap: 10
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                        style: {
                            display: 'grid',
                            gap: 6
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Amount to lock (ADA)"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 249,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                value: amountAda,
                                onChange: (e)=>setAmountAda(e.target.value),
                                placeholder: "1.0",
                                inputMode: "decimal",
                                style: {
                                    padding: '10px 12px',
                                    border: '1px solid #567',
                                    borderRadius: 10,
                                    background: '#0a1020',
                                    color: '#d6e7ff'
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 250,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 248,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            fontSize: 13,
                            opacity: 0.85
                        },
                        children: [
                            availableAda === null ? 'Available: —' : `Available: ${availableAda.toFixed(6)} ADA`,
                            safeMaxAda !== null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    " · Safe max: ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("b", {
                                        children: [
                                            safeMaxAda.toFixed(6),
                                            " ADA"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                        lineNumber: 261,
                                        columnNumber: 50
                                    }, this)
                                ]
                            }, void 0, true),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: " · Tip: use ≥ 1.0 ADA for the script output."
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 262,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 259,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        style: {
                            display: 'flex',
                            gap: 10,
                            flexWrap: 'wrap'
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>safeMaxAda !== null && setAmountAda(safeMaxAda.toFixed(6)),
                                style: {
                                    padding: '6px 10px',
                                    borderRadius: 10,
                                    border: '1px solid #567',
                                    background: '#0a1020',
                                    color: '#d6e7ff'
                                },
                                children: "Use max"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 266,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                disabled: !scriptAddr || busy,
                                style: {
                                    padding: '10px 14px',
                                    borderRadius: 12,
                                    border: '2px solid #2b6fff',
                                    background: busy ? '#132039' : '#0a1020',
                                    color: '#7fb3ff',
                                    fontWeight: 800,
                                    cursor: busy ? 'not-allowed' : 'pointer'
                                },
                                children: busy ? 'Submitting…' : 'Lock ADA to Script'
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 274,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 265,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                lineNumber: 247,
                columnNumber: 7
            }, this),
            (msg || txHash) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    marginTop: '1rem',
                    padding: '10px 12px',
                    borderRadius: 10,
                    border: '1px solid rgba(127,179,255,0.35)',
                    background: 'rgba(43,111,255,0.06)',
                    color: '#cfe5ff',
                    whiteSpace: 'pre-wrap',
                    display: 'flex',
                    gap: 12,
                    alignItems: 'center',
                    flexWrap: 'wrap'
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: msg
                    }, void 0, false, {
                        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                        lineNumber: 308,
                        columnNumber: 11
                    }, this),
                    txHash && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("code", {
                                style: {
                                    opacity: 0.8
                                },
                                children: [
                                    txHash.slice(0, 10),
                                    "…",
                                    txHash.slice(-8)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 311,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: `${explorerBase}/transaction/${txHash}`,
                                target: "_blank",
                                rel: "noreferrer",
                                style: {
                                    color: '#7fb3ff',
                                    textDecoration: 'underline'
                                },
                                children: "Open on Cardanoscan"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 312,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: `${cexplorerBase}/tx/${txHash}`,
                                target: "_blank",
                                rel: "noreferrer",
                                style: {
                                    color: '#7fb3ff',
                                    textDecoration: 'underline'
                                },
                                children: "Open on Cexplorer"
                            }, void 0, false, {
                                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                                lineNumber: 315,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true)
                ]
            }, void 0, true, {
                fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
                lineNumber: 293,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/scripts/sig/ScriptSigClient.tsx",
        lineNumber: 227,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=app_scripts_sig_ScriptSigClient_tsx_575648b3._.js.map